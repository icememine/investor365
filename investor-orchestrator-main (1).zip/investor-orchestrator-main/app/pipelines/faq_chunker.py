# app/pipelines/faq_chunker.py
from __future__ import annotations
import os, hashlib
from pathlib import Path
import polars as pl

FAQ = "data/external/faq/faq.parquet"
OUT = "data/vector/faq_chunks.parquet"

def sha1(s: str) -> str:
    import hashlib as _h
    return _h.sha1(s.encode("utf-8")).hexdigest()

def main():
    if not os.path.exists(FAQ):
        raise SystemExit(f"Not found: {FAQ}")
    df = pl.read_parquet(FAQ)

    rows = []
    for i, r in enumerate(df.iter_rows(named=True)):
        q = str(r.get("question") or "").strip()
        a = str(r.get("answer") or "").strip()
        if not (q or a):
            continue
        text = f"Q: {q}\nA: {a}"
        doc_id = sha1(q + a)
        rows.append({
            "chunk_id": f"{doc_id}:0",
            "doc_id": doc_id,
            "source": "faq",
            "title": q[:80],
            "chunk_idx": 0,
            "text": text,
            "tags": r.get("sheet") or "",
        })

    if not rows:
        raise SystemExit("No rows generated from FAQ.")
    Path(OUT).parent.mkdir(parents=True, exist_ok=True)
    pl.DataFrame(rows).write_parquet(OUT)
    print(f"[OK] rows={len(rows)} -> {OUT}")

if __name__ == "__main__":
    main()
