# app/graph.py
from typing import Dict, Any
from langgraph.graph import StateGraph, END

# Agents & MCP
from app.agents.intent_router import route as route_intent
from app.pipelines.search_all import run as mcp_search
from app.agents.policy_agent import run as run_policy
from app.agents.sales_agent import run as run_sales
from app.agents.reports_agent import run as run_reports
from app.agents.pl_analyst import run as run_pl
from app.agents.synthesizer import run as run_synth

# -------------------------
# Node functions
# -------------------------

def node_router(state: Dict[str, Any]) -> Dict[str, Any]:
    """
    Nếu payload đã có 'targets' -> giữ nguyên; nếu chưa -> dùng Router LLM chọn targets.
    Luôn đảm bảo state có 'query' & 'targets'.
    """
    q = (state.get("query") or "").strip()
    if not q:
        state["targets"] = state.get("targets") or ["handbook", "faq", "salescripts", "reports"]
        return state

    # Nếu UI đã truyền targets -> không cần LLM route
    if state.get("targets"):
        return state

    routed = route_intent(q)
    state["query"] = routed.get("query", q)
    state["targets"] = routed.get("targets") or ["handbook", "faq", "salescripts", "reports"]
    return state


def node_retrieve(state: Dict[str, Any]) -> Dict[str, Any]:
    """
    Gọi MCP (search_all.run) để lấy hits + citations theo targets.
    """
    payload = {
        "query": state["query"],
        "sources": state.get("targets", []),
        "top_k": int(state.get("top_k", 6))
    }
    resp = mcp_search(payload)
    state["hits"] = resp.get("results", [])
    state["citations"] = resp.get("citations", [])
    return state


def node_policy(state: Dict[str, Any]) -> Dict[str, Any]:
    if any(s in state.get("targets", []) for s in ["handbook", "faq", "salescripts", "reports"]):
        out = run_policy(state["query"], state.get("hits", []))
        state.update(out)
    return state


def node_sales(state: Dict[str, Any]) -> Dict[str, Any]:
    if "salescripts" in state.get("targets", []):
        out = run_sales(state["query"], state.get("hits", []))
        state.update(out)
    return state


def node_reports(state: Dict[str, Any]) -> Dict[str, Any]:
    if "reports" in state.get("targets", []):
        out = run_reports(state["query"], state.get("hits", []))
        state.update(out)
    return state


def node_pl(state: Dict[str, Any]) -> Dict[str, Any]:
    if "pl_investor" in state.get("targets", []):
        out = run_pl(state["query"])
        state.update(out)
    return state


def node_synth(state: Dict[str, Any]) -> Dict[str, Any]:
    out = run_synth(
        state["query"],
        state.get("hits", []),
        policy_points=state.get("policy_points", ""),
        pitch_lines=state.get("pitch_lines", ""),
        report_numbers=state.get("report_numbers", ""),
        pl_findings=state.get("pl_findings", ""),
    )
    state.update(out)
    return state


# -------------------------
# Build graph (ENTRY = "router")
# -------------------------

def build_graph():
    g = StateGraph(dict)

    # Khai báo nodes
    g.add_node("router", node_router)
    g.add_node("retrieve", node_retrieve)
    g.add_node("policy", node_policy)
    g.add_node("sales", node_sales)
    g.add_node("reports", node_reports)
    g.add_node("pl", node_pl)
    g.add_node("synth", node_synth)

    # Entry point = tên node "router"
    g.set_entry_point("router")

    # Edges
    g.add_edge("router", "retrieve")
    g.add_edge("retrieve", "policy")
    g.add_edge("policy", "sales")
    g.add_edge("sales", "reports")
    g.add_edge("reports", "pl")
    g.add_edge("pl", "synth")
    g.add_edge("synth", END)

    return g.compile()

