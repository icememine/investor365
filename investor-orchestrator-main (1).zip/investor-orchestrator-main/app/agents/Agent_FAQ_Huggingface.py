from huggingface_hub import AsyncInferenceClient
from pydantic_ai import Agent
from pydantic_ai.models.huggingface import HuggingFaceModel
from pydantic_ai.providers.huggingface import HuggingFaceProvider
import os
from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import CharacterTextSplitter
from dotenv import load_dotenv
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS
import numpy as np
import faiss
from langchain_community.embeddings import SentenceTransformerEmbeddings
from dataclasses import dataclass
from pydantic_ai import RunContext
load_dotenv()

@dataclass
class Deps:
    vector_store: FAISS

# Define the model with the HuggingFace API key:
HF_TOKEN = os.getenv("HUGGINGFACEHUB_API_TOKEN")
model_name = 'Qwen/Qwen3-Next-80B-A3B-Instruct'
model = HuggingFaceModel(model_name, provider=HuggingFaceProvider(api_key=HF_TOKEN))

# Define system prompt for the agent
SYSTEM_PROMPT = (
"""
"Bạn là Customer Service Agent - một chuyên gia hỗ trợ khách hàng chuyên nghiệp của Dragon Capital. "
"Bạn chuyên trả lời các câu hỏi của khách hàng dựa trên thông tin từ nguồn sau:\n\n"
"1. **FAQ (Câu hỏi thường gặp)**: Chứa các câu hỏi và câu trả lời phổ biến từ nhà đầu tư\n"
"**Công cụ bạn cần sử dụng:**\n"
"- **retrieve**: Tìm kiếm trong cơ sở dữ liệu FAQ để trả lời các câu hỏi thường gặp\n"
"**Hướng dẫn trả lời:**\n"
"- Luôn trả lời bằng tiếng Việt một cách thân thiện và chuyên nghiệp\n"
"- Trích dẫn rõ ràng nguồn thông tin với format [source:title]\n"
"- Nếu không tìm thấy thông tin, hãy hướng dẫn khách hàng liên hệ bộ phận hỗ trợ\n\n"
"**Ví dụ câu trả lời tốt:**\n\n"
"Để đặt lệnh mua/bán trên app DragonX, bạn thực hiện theo các bước sau:\n"
"• **Bước 1**: Mở app DragonX → Chọn \"Đặt Lệnh\" ở thanh công cụ dưới cùng\n"
"• **Bước 2**: Chọn \"Mua\" hoặc \"Bán\" → Chọn sản phẩm quỹ muốn giao dịch\n"
"• **Bước 3**: Nhập số tiền đầu tư (mua) hoặc số lượng bán → Chọn phương thức thanh toán\n"
"• **Bước 4**: Nhập mã PIN để xác nhận lệnh\n"
"• **Cut-off time**: 14:30 hàng ngày (trước giờ này để được xử lý trong ngày)\n"
"[source:FAQ]"
"""
)

agent = Agent(
    model, 
    deps_type=Deps,
    system_prompt=SYSTEM_PROMPT
)

# Define the vectorstore tools:
@agent.tool
async def retrieve(context: RunContext[Deps], search_query: str) -> str:
    """Tìm kiếm trong cơ sở dữ liệu FAQ để trả lời các câu hỏi thường gặp
    Args:
        context: The call context
        search_query: The search query
    """
    INDEX_DIR = "./data/vector/faiss_faq_docling"
    MODEL_NAME = "intfloat/multilingual-e5-base"
    embeddings_model = SentenceTransformerEmbeddings(model_name=MODEL_NAME)
    loaded_vector_store = context.deps.vector_store.load_local(INDEX_DIR, embeddings_model, allow_dangerous_deserialization=True)
    k = 3
    similar_docs = loaded_vector_store.similarity_search(search_query, k=k)
    return "\n\n".join(
        f"# Documents:\n{doc.page_content}"
        for i, doc in enumerate(similar_docs))

# Load the vector store
INDEX_DIR = "./data/vector/faiss_faq_docling"
MODEL_NAME = "intfloat/multilingual-e5-base"
embeddings_model = SentenceTransformerEmbeddings(model_name=MODEL_NAME)
vector_store = FAISS.load_local(INDEX_DIR, embeddings_model, allow_dangerous_deserialization=True)

# The main function to run the agent:
async def run_agent(question: str):
    deps = Deps(
        vector_store=vector_store,
    )
    answer = await agent.run(question, deps=deps)
    return answer

import asyncio

async def main():
    query = "Rủi ro của quỹ mở là gì?"
    output = await run_agent(query)
    print(output.output)

if __name__ == "__main__":
    asyncio.run(main())
