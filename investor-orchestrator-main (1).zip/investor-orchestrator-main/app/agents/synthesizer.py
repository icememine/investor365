# app/agents/synthesizer.py
from typing import Dict, List
from app.llm import get_llm

SYS = (
"Bạn là Answer Synthesizer cho Sales/Marketing/CS. Tổng hợp câu trả lời NGẮN, theo bullet:\n"
"- Bước thực hiện (ở đâu, thao tác gì)\n"
"- Thời gian xử lý / cut-off\n"
"- Phí/điều kiện chính\n"
"- Số liệu hỗ trợ (nếu có)\n"
"Thêm citation ở cuối mỗi bullet dạng [source:title]."
)

def run(query: str, hits: List[Dict], policy_points: str = "", pitch_lines: str = "",
        report_numbers: str = "", pl_findings: str = "") -> Dict:
    ctx = []
    for h in hits[:6]:
        tag = f'[{h.get("source")}:{(h.get("title") or h.get("file_path") or h.get("url"))}]'
        ctx.append(f'{tag}\n{h.get("snippet","")}')
    sections = []
    if policy_points: sections.append("**Policy/Process**:\n" + policy_points)
    if pitch_lines: sections.append("**Sales Lines**:\n" + pitch_lines)
    if report_numbers: sections.append("**Reports**:\n" + report_numbers)
    if pl_findings: sections.append("**PL**:\n" + pl_findings)

    llm = get_llm()
    msg = [
        {"role":"system","content":SYS},
        {"role":"user","content":f"Câu hỏi: {query}\n\nTài liệu truy hồi:\n" + "\n\n---\n\n".join(ctx) + "\n\n" + "\n\n".join(sections)}
    ]
    content = llm.invoke(msg).content
    return {"answer": content}
