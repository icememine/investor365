# app/pipelines/report_chunker.py
from __future__ import annotations
import os, hashlib
from pathlib import Path
import polars as pl

REPORTS = "data/external/reports/reports.parquet"
OUT = "data/vector/report_chunks.parquet"
CHUNK_SIZE = 700
OVERLAP = 120

def sha1(s: str) -> str:
    import hashlib as _h
    return _h.sha1(s.encode("utf-8")).hexdigest()

def chunk_text(t: str, size=CHUNK_SIZE, overlap=OVERLAP):
    t = (t or "").strip()
    if not t:
        return []
    if len(t) <= size:
        return [t]
    out, i = [], 0
    while i < len(t):
        out.append(t[i:i+size])
        if i + size >= len(t):
            break
        i += size - overlap
    return out

def main():
    if not os.path.exists(REPORTS):
        raise SystemExit(f"Not found: {REPORTS}")
    df = pl.read_parquet(REPORTS).with_columns(
        pl.col("text").fill_null("").cast(pl.Utf8)
    ).filter(pl.col("text").str.len_chars() > 50)

    rows = []
    for r in df.iter_rows(named=True):
        doc_id = sha1(r["file_path"] or r["file_name"])
        chunks = chunk_text(r["text"])
        for idx, ch in enumerate(chunks):
            rows.append({
                "chunk_id": f"{doc_id}:{idx}",
                "doc_id": doc_id,
                "source": "report",
                "title": r.get("file_name") or "",
                "file_path": r.get("file_path") or "",
                "dir_name": r.get("dir_name") or "",
                "pages": r.get("pages"),
                "chunk_idx": idx,
                "text": ch,
                "tags": r.get("tags") or "[]",
                "fetched_at": r.get("fetched_at"),
            })

    if not rows:
        raise SystemExit("No chunks generated from reports.")
    Path(OUT).parent.mkdir(parents=True, exist_ok=True)
    pl.DataFrame(rows).write_parquet(OUT)
    print(f"[OK] chunks={len(rows)} -> {OUT}")

if __name__ == "__main__":
    main()
