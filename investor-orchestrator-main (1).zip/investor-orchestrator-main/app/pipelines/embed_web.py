# app/pipelines/web_chunker.py
from __future__ import annotations
import os, json, hashlib, uuid
from pathlib import Path
import polars as pl

ARTICLES = "data/external/web/articles.parquet"
OUT = "data/vector/web_chunks.parquet"

CHUNK_SIZE = 1000   # ký tự
OVERLAP    = 120

def sha1(s: str) -> str:
    return hashlib.sha1(s.encode("utf-8")).hexdigest()

def chunk_text(t: str, size=CHUNK_SIZE, overlap=OVERLAP):
    t = (t or "").strip()
    if not t:
        return []
    if len(t) <= size:
        return [t]
    out, i = [], 0
    while i < len(t):
        out.append(t[i:i+size])
        if i + size >= len(t): break
        i += size - overlap
    return out

def main():
    if not os.path.exists(ARTICLES):
        raise SystemExit(f"Not found: {ARTICLES}")
    df = pl.read_parquet(ARTICLES)
    # Lọc bản ghi có text đủ dài
    df = df.with_columns(pl.col("text").fill_null("").cast(pl.Utf8)).filter(pl.col("text").str.len_chars() > 200)

    rows = []
    for r in df.iter_rows(named=True):
        url = r["url"]
        doc_id = sha1(url)
        text = r["text"]
        chunks = chunk_text(text)
        for idx, ch in enumerate(chunks):
            rows.append({
                "chunk_id": f"{doc_id}:{idx}",
                "doc_id": doc_id,
                "source": "web",
                "title": r.get("title") or "",
                "url": url,
                "source_domain": r.get("source_domain") or "",
                "published_at": r.get("published_at"),
                "fetched_at": r.get("fetched_at"),
                "tags": r.get("tags") or "[]",
                "via": r.get("via") or "single",
                "chunk_idx": idx,
                "text": ch,
            })
    if not rows:
        raise SystemExit("No chunks produced. Check articles.parquet text field.")
    out_df = pl.DataFrame(rows)
    os.makedirs(Path(OUT).parent, exist_ok=True)
    out_df.write_parquet(OUT)
    print(f"[OK] chunks: {out_df.height} -> {OUT}")

if __name__ == "__main__":
    main()
