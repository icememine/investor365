from sentence_transformers import SentenceTransformer
modelPath = "app/embedding_models"
model = SentenceTransformer('BAAI/bge-m3')
model.save(modelPath)
modelPath = "app/embedding_models"
model = SentenceTransformer(modelPath)