# app/mcp_adapters/handbook.py
from __future__ import annotations
import os, json, re
from typing import List
from pathlib import Path

import fitz  # PyMuPDF
import pandas as pd
from .pl_investor import _safe_load_yaml

JSONL_OUT = "data/local/handbook.jsonl"
PARQUET_OUT = "data/local/handbook.parquet"
CFG_MCP = os.getenv("MCP_CONFIG", "config/mcp_config.yaml")

def _chunk(text: str, max_chars=1200) -> List[str]:
    text = re.sub(r"\s+", " ", text or "").strip()
    if not text:
        return []
    return [text[i:i+max_chars] for i in range(0, len(text), max_chars)]

def _extract_text_pymupdf(pdf_path: str) -> List[str]:
    """Trả về list text theo trang (mỗi phần tử là text của 1 page)."""
    out: List[str] = []
    with fitz.open(pdf_path) as doc:
        for page in doc:
            # 'text' cho layout-bám-dòng tốt hơn 'textpage' mặc định
            t = page.get_text("text") or ""
            out.append(t)
    return out

def build_handbook(pdf_path: str, jsonl_out: str = JSONL_OUT, parquet_out: str = PARQUET_OUT) -> dict:
    Path(os.path.dirname(jsonl_out)).mkdir(parents=True, exist_ok=True)
    Path(os.path.dirname(parquet_out)).mkdir(parents=True, exist_ok=True)

    pages_text = _extract_text_pymupdf(pdf_path)
    records = []
    total_chunks = 0
    for i, t in enumerate(pages_text, start=1):
        chs = _chunk(t, max_chars=1200)
        for j, ck in enumerate(chs, start=1):
            total_chunks += 1
            records.append({
                "doc": "handbook",
                "page": i,
                "chunk_id": f"{i}-{j}",
                "text": ck
            })

    df = pd.DataFrame(records)
    df.to_parquet(parquet_out, index=False)

    with open(jsonl_out, "w", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

    return {
        "ok": True,
        "pages": len(pages_text),
        "chunks": total_chunks,
        "jsonl": jsonl_out,
        "parquet": parquet_out
    }

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--path", default=None, help="PDF path, ví dụ data/local/handbook.pdf")
    ap.add_argument("--out", default=None, help="Parquet output, ví dụ data/local/handbook.parquet")
    ap.add_argument("--config", default=CFG_MCP)
    args = ap.parse_args()

    cfg = _safe_load_yaml(args.config, {})
    pdf_path = args.path or cfg.get("storage", {}).get("local", {}).get("handbook_pdf", "data/local/handbook.pdf")
    parquet_out = args.out or "data/local/handbook.parquet"

    print(json.dumps(build_handbook(pdf_path, parquet_out=parquet_out), ensure_ascii=False, indent=2))
