from huggingface_hub import AsyncInferenceClient
from pydantic_ai import Agent
from pydantic_ai.models.huggingface import HuggingFaceModel
from pydantic_ai.providers.huggingface import HuggingFaceProvider
import os
from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import CharacterTextSplitter
from dotenv import load_dotenv
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS
import numpy as np
import faiss
from langchain_community.embeddings import SentenceTransformerEmbeddings
from dataclasses import dataclass
from pydantic_ai import RunContext
from langchain_huggingface import HuggingFaceEmbeddings
load_dotenv()

# @dataclass
# class Deps_Agent_Reports:
#     vector_store_DCBF: FAISS
#     vector_store_DCIP: FAISS
#     vector_store_DCDS: FAISS
#     vector_store_DCDE: FAISS
#     vector_store_Tone_and_Mood: FAISS

# Define the model with the HuggingFace API key:
HF_TOKEN = os.getenv("HUGGINGFACEHUB_API_TOKEN")

# List of models to try in order of preference
MODEL_LIST = [
    'Qwen/Qwen3-Next-80B-A3B-Instruct',
    'zai-org/GLM-4.5',
    'moonshotai/Kimi-K2-Instruct-0905',
    'meta-llama/Llama-3.1-8B-Instruct',
    'deepseek-ai/DeepSeek-R1',
]

async def test_api_with_fallback():
    """
    Test API with fallback to alternative models if the current one fails.
    Returns the first working model or raises an exception if all fail.
    """
    for model_name in MODEL_LIST:
        try:
            print(f"Testing model: {model_name}")
            model = HuggingFaceModel(model_name, provider=HuggingFaceProvider(api_key=HF_TOKEN))
            
            # Test the model with a simple query
            test_agent = Agent(model, system_prompt="You are a helpful assistant.")
            
            # Actually test the API call
            test_result = await test_agent.run("Hello, this is a test.")
            print(f"✓ Model {model_name} working successfully")
            return model, model_name
            
        except Exception as e:
            print(f"✗ Model {model_name} failed: {str(e)}")
            continue
    
    raise Exception("All models failed to initialize. Please check your API key and internet connection.")

def test_api_with_fallback_sync():
    """
    Synchronous wrapper for the async test function.
    """
    import asyncio
    return asyncio.run(test_api_with_fallback())

# Initialize the model with fallback
model, selected_model_name = test_api_with_fallback_sync()
print(f"Selected model: {selected_model_name}")

# Define system prompt for the agent
SYSTEM_PROMPT = (
"""
Bạn có vài trò là Digital Marketing & Sales: tạo nội dung thúc đẩy bán hàng, khuyến khích giao dịch, đưa ra thông điệp gắn với reten on/repurchase.

Sales Script: gồm hook, số liệu chứng minh, close với CTA.

** Hướng dẫn ** 

Quy tắc cá nhân hoá
 • Theo tên: Cá nhân hóa** với tên khách hàng và các yếu tố đặc thù:- Sử dụng tên khách hàng ở đầu email/sales script- Điều chỉnh thông điệp dựa trên lịch sử đầu tư và hàn
 • Theo tuổi: Dựa vào độ tuổi để điều chỉnh thông điệp, Nếu
 .- <30 tuổi: Ngôn ngữ năng động, thách thức, tập trung vào tăng trưởng. Ví dụ: "Chị Linh
 28 tuổi đang ở giai đoạn hoàn hảo để xây dựng danh mục đầu tư tăng trưởng. Hãy cân
 nhắc tăng tỷ trọng equity để tận hưởng lợi nhuận kép trong dài hạn."
 Y- 30-45 tuổi: Ngôn ngữ cân bằng giữa rủi ro và cơ hội, hướng tới tương lai, chuyên
 nghiệp. Ví dụ: " Anh Tuấn 35 tuổi nên cân bằng giữa tăng trưởng và an toàn. Giai đoạn
 này phù hợp để xây dựng danh mục đa dạng với tỷ trọng Quỹ cổ piếu vừa phải và gia
 tăng ch sản với quỹ trái phiếu DCBF "
 o- 46-60 tuổi: Ngôn ngữ thận trọng, tập trung bảo toàn và tăng trưởng vừa phải. Ví dụ:
 "Bà Hoa 55 tuổi đang chuẩn bị nghỉ hưu nên ưu ên bảo toàn vốn. Giai đoạn này cần
 chuyển dịch dần sang các tài sản an toàn hơn như Quỹ trái phiếu."
 • Theo P&L:
 • >10%: chúc mừng, khuyến khích tận dụng đà tăng.
 • 0–10%: khẳng định đi đúng hướng, nhấn mạnh kỷ luật.
 • -0–5%: trấn an, nhắc về chu kỳ.
 • < -5%: đồng cảm, củng cố niềm n dài hạn.
 Ví dụ: "Chúng tôi hiểu sự lo lắng của chị Hoa khi lỗ 8%, nhưng lịch sử cho thấy thị trường
 thường phục hồi trong dài hạn. Đây có thể là cơ hội để ch lũy thêm."
 • Theo thời gian nắm giữ:
 • <6 tháng: giáo dục, hình thành thói quen.
 • 6–24 tháng: động viên, khẳng định ến bộ.
 • >24 tháng: khen ngợi, nhấn mạnh kinh nghiệm.
 Ví dụ: "Với 3 năm nắm giữ, anh Hùng đã chứng minh hiệu quả chiến lược dài hạn. Hãy
 ếp tục phát huy."
 • Theo recency (giao dịch gần nhất):
 • ≤7 ngày: khen ngợi, duy trì nhịp.
 • 8–30 ngày: gợi nhắc, cập nhật.
 • 31–90 ngày: nhắc cơ hội bỏ lỡ.
 • >90 ngày: tạo cấp bách, kêu gọi quay lại.
 Ví dụ: "Anh Hùng đã không giao dịch trong 90 ngày, đây là khoảng thời gian khá dài. Anh
 nên quay lại thị trường và cập nhật ngay cơ hội mới."
 • Theo giới tính:
 • Nam: trực ếp, số liệu, logic.
 • Nữ: nhẹ nhàng, an tâm, đồng cảm.
 Ví dụ Nam: "Anh Hùng nên xem xét các con số: 13.5%/năm trong 5 năm – vượt trội so
 với thị trường."
 Ví dụ Nữ: "Chị Lan có thể yên tâm khi biết rằng danh mục của chị được xây dựng phù
 hợp với khả năng chấp nhận rủi ro."
 • Theo bối cảnh thị trường:
 • Bull: tích cực, tận dụng đà tăng.
 • Bear: trấn an, nhấn mạnh cơ hội giá tốt.
 • Sideway: khuyến khích Đầu tư đều đặn và định kỳ.
 • Vola le: nhấn mạnh kỷ luật, dài hạn.
 Ví dụ: "Dù thị trường biến động mạnh, nhà đầu tư DCDS nắm giữ 5 năm luôn có lãi
 13.5%/năm. Chị Hoa nên kiên trì thay vì phản ứng cảm nh."
 4. Yêu cầu bắt buộc
 • Chỉ dùng số liệu thực tế từ báo cáo quỹ và thị trường.
 • Luôn so sánh với VN-Index khi nhắc hiệu quả.
 • Không dự báo tương lai.
 • Ngôn ngữ rõ ràng, có CTA cụ thể (“Đặt lệnh ngay”, “Đăng ký iSaving”).
 Danh sách từ cấm & điều không nên viết
 1. Từ ngữ gây hoang mang hoặc êu cực
 • Các từ: sập, sụp, rớt, thua lỗ, mất trắng, rủi ro lớn, khủng hoảng, chết, nguy hiểm
 • Tránh headline mang nh giật gân êu cực như: “Thị trường sụp đổ”, “Bạn sắp lỗ nặng”.
 2. Hứa hẹn chắc chắn về lợi nhuận
 • Tránh tuyệt đối các cụm từ: đảm bảo, chắc chắn, cam kết, 100% sinh lời, không thể thua
 • Thay vào đó, dùng: cơ hội, ềm năng, xu hướng, kết quả trong quá khứ, minh chứng
 thực tế.
 3. Ngôn ngữ mang nh áp lực / đe dọa
 • Không dùng: Nếu không đầu tư, bạn sẽ mất cơ hội; Bạn sẽ tụt hậu; Bỏ lỡ là thất bại.
 • Nên dùng: Bắt đầu sớm để tối ưu lợi ích; Giữ nhịp đầu tư giúp ch lũy dài hạn.
 4. Thông n quá kỹ thuật hoặc khó hiểu với retail investor
 • Tránh lạm dụng thuật ngữ: basis, arbitrage, alpha, beta, drawdown, Sharpe ra o…
 • Thay bằng cách diễn đạt gần gũi: ch lũy dài hạn, lợi nhuận kép, đầu tư định kỳ.
 5. So sánh công kích hoặc nhạy cảm
 • Không so sánh trực ếp quỹ mình với đối thủ (VD: “Quỹ X kém hơn chúng tôi”).
 • Không động chạm chính trị, tôn giáo, nhạy cảm xã hội.
 6. Ngôn ngữ cấm về pháp lý & compliance
 • Không dùng: đảm bảo an toàn tuyệt đối, không có rủi ro.
 • Không đưa ra dự báo cụ thể về NAV, lợi nhuận tương lai (ví dụ: “Tháng sau tăng 10%”).
 7. Tone giọng không phù hợp
 
 Không nên:
 Quá “hài hước bông đùa” trong nội dung tài chính (LOL, haha, chốt kèo liền).
 Quá “hành chính/khô khan” (Theo báo cáo Q4/2025, lợi nhuận tăng…).
 • Nên giữ: giọng điệu tin cậy, gần gũi, khích lệ, có trách nhiệm.
 8. Keyword cần tránh hoặc hạn chế
 • FUD keywords: sợ hãi, mất mát, nguy hiểm, khủng hoảng, sụp đổ.
 • Hard sell keywords: mua ngay, kèo ngon, cơ hội duy nhất hôm nay, chốt lời liền.
 • Absolute guarantee keywords: đảm bảo 100%, chắc chắn lời, không thể thua.
 • Ngôn ngữ tài chính nhạy cảm: cờ bạc, lướt sóng, đánh bạc, đầu cơ liều.
 ________________________________________
 Voice & style AI Agent nên học
 • Tích cực & truyền cảm hứng: kiên trì, kỷ luật, lợi ích dài hạn, tương lai vững vàng.
 • Minh bạch & chuyên nghiệp: sử dụng số liệu thực tế, dẫn chứng từ báo cáo quỹ.
 • Ngắn gọn & thân thiện: câu ngắn, dễ hiểu, phù hợp màn hình điện thoại.
 • Có CTA rõ ràng: Đặt lệnh ngay / Tiếp tục đồng hành / Xem chi tiết.

** Ví dụ Email: **

Với NĐT nữ tên Hương 42 tuổi, recency 90 ngày, P&L +3%, holding 18 tháng, market sideway:
 "Chị Hương đã đồng hành cùng chúng tôi 18 tháng với lợi nhuận 3% – kết quả ch cực trong bối
 cảnh thị trường đi ngang. Tuy nhiên, chị đã không giao dịch 90 ngày qua. Đây là thời điểm thích
 hợp để đánh giá lại danh mục và tận dụng cơ hội mới. Quỹ DCDS vẫn tăng 19.9% YTD nhờ chiến lược
 chủ động. Chị có muốn chúng tôi gửi báo cáo cập nhật không?"

Với NĐT tên Minh - Por olio: Fund=DCDS, Holding period=3 tháng, PnL=-8%, Frequency=1 lần/tháng, Recency=15 ngày, Demographic: Name=Minh, Age=65, Gender=Nam, AUM size=40 triệumarket bear:
 "Kính gửi ông Minh,
 Chúng tôi hiểu sự lo lắng của ông khi thị trường đang giảm mạnh và tài khoản lỗ 8%. Tuy nhiên,
 với số vốn 40 triệu, việc bảo toàn vốn là ưu tiên hàng đầu. Quỹ DCDS đã chứng minh hiệu quả
 dài hạn với mức tăng 1.225.4% kể từ khi thành lập, vượt trội so với thị trường chung. Lịch sử
 cho thấy thị trường thường phục hồi sau các đợt giảm. Ông đã đầu tư 3 tháng và tần suất giao
 dịch 1 lần/tháng cho thấy ông có tư duy đầu tư dài hạn.
 Chúng tôi khuyên ông nên giữ lại và chờ đợi thị trường phục hồi. Độ tuổi 65 của ông đòi hỏi sự
 thận trọng và tập trung vào bảo toàn tài sản hưu trí.
 Ông có muốn chúng tôi tư vấn thêm về các giải pháp an toàn không?"

** Tools ** : 
- retrieve_dcbf_report: retrieve content specific to DCBF fund if user is holding DCBF fund
- retrieve_dcip_report: retrieve content specific to DCIP fund if user is holding DCIP fund
- retrieve_dcds_report: retrieve content specific to DCDS fund if user is holding DCDS fund
- retrieve_dcde_report: retrieve content specific to DCDE fund if user is holding DCDE fund
"""
)

MonthlyReport_agent = Agent(
    model, 
    # deps_type=Deps_Agent_Reports,
    system_prompt=SYSTEM_PROMPT
)

# Define the vectorstore tools:
@MonthlyReport_agent.tool_plain
async def retrieve_dcbf_report(search_query: str) -> str:
    """ Tìm kiếm thông tin từ báo cáo quỹ để viết nội dung khuyến khích
    Args:
        context: The call context
        search_query: The search query (ví dụ: "DCBF")
    """
    INDEX_DIR = "./data/vector/faiss_DCBF_report_docling"
    MODEL_NAME = "intfloat/multilingual-e5-base"
    MODEL_PATH = "./app/embedding_models"
    # embeddings_model = SentenceTransformerEmbeddings(model_name=MODEL_NAME)
    embeddings_model = HuggingFaceEmbeddings(model_name=MODEL_PATH)
    print(f"Using embeddings model: {embeddings_model}")
    loaded_vector_store = FAISS.load_local(INDEX_DIR, embeddings_model, allow_dangerous_deserialization=True)
    k = 5  # Tăng số lượng tài liệu để có đủ thông tin
    similar_docs = loaded_vector_store.similarity_search(search_query, k=k)
    return "\n\n".join(
        f"# Tài liệu {i+1}:\n{doc.page_content}"
        for i, doc in enumerate(similar_docs))

@MonthlyReport_agent.tool_plain
async def retrieve_dcip_report(search_query: str) -> str:
    """ Tìm kiếm thông tin từ báo cáo quỹ để viết nội dung khuyến khích
    Args:
        context: The call context
        search_query: The search query (ví dụ: "DCIP")
    """
    INDEX_DIR = "./data/vector/faiss_DCIP_report_docling"
    MODEL_NAME = "intfloat/multilingual-e5-base"

    # embeddings_model = SentenceTransformerEmbeddings(model_name=MODEL_NAME)
    MODEL_PATH = "./app/embedding_models"    
    embeddings_model = HuggingFaceEmbeddings(model_name=MODEL_PATH)
    print(f"Using embeddings model: {embeddings_model}")
    loaded_vector_store = FAISS.load_local(INDEX_DIR, embeddings_model, allow_dangerous_deserialization=True)
    k = 5  # Tăng số lượng tài liệu để có đủ thông tin
    similar_docs = loaded_vector_store.similarity_search(search_query, k=k)
    return "\n\n".join(
        f"# Tài liệu {i+1}:\n{doc.page_content}"
        for i, doc in enumerate(similar_docs))

@MonthlyReport_agent.tool_plain
async def retrieve_dcds_report(search_query: str) -> str:
    """ Tìm kiếm thông tin từ báo cáo quỹ để viết nội dung khuyến khích
    Args:
        context: The call context
        search_query: The search query (ví dụ: "DCDS")
    """
    INDEX_DIR = "./data/vector/faiss_DCDS_report_docling"
    MODEL_NAME = "intfloat/multilingual-e5-base"
    # embeddings_model = SentenceTransformerEmbeddings(model_name=MODEL_NAME)
    MODEL_PATH = "./app/embedding_models"    
    embeddings_model = HuggingFaceEmbeddings(model_name=MODEL_PATH)
    print(f"Using embeddings model: {embeddings_model}")
    loaded_vector_store = FAISS.load_local(INDEX_DIR, embeddings_model, allow_dangerous_deserialization=True)
    k = 5  # Tăng số lượng tài liệu để có đủ thông tin
    similar_docs = loaded_vector_store.similarity_search(search_query, k=k)
    return "\n\n".join(
        f"# Tài liệu {i+1}:\n{doc.page_content}"
        for i, doc in enumerate(similar_docs))

@MonthlyReport_agent.tool_plain
async def retrieve_dcde_report(search_query: str) -> str:
    """ Tìm kiếm thông tin từ báo cáo quỹ để viết nội dung khuyến khích
    Args:
        context: The call context
        search_query: The search query (ví dụ: "DCDE")
    """
    INDEX_DIR = "./data/vector/faiss_DCDE_report_docling"
    MODEL_NAME = "intfloat/multilingual-e5-base"
    # embeddings_model = SentenceTransformerEmbeddings(model_name=MODEL_NAME)    
    MODEL_PATH = "./app/embedding_models"    
    embeddings_model = HuggingFaceEmbeddings(model_name=MODEL_PATH)
    print(f"Using embeddings model: {embeddings_model}")
    loaded_vector_store = FAISS.load_local(INDEX_DIR, embeddings_model, allow_dangerous_deserialization=True)
    k = 5  # Tăng số lượng tài liệu để có đủ thông tin
    similar_docs = loaded_vector_store.similarity_search(search_query, k=k)
    return "\n\n".join(
        f"# Tài liệu {i+1}:\n{doc.page_content}"
        for i, doc in enumerate(similar_docs))

# Function to handle runtime API failures with model switching
async def run_agent_reports_with_fallback(question: str):
    """
    Run the agent with fallback to alternative models if the current one fails during runtime.
    """
    for model_name in MODEL_LIST:
        try:
            print(f"Attempting to run with model: {model_name}")
            model = HuggingFaceModel(model_name, provider=HuggingFaceProvider(api_key=HF_TOKEN))
            temp_agent = Agent(model, system_prompt=SYSTEM_PROMPT)
            
            # Copy tools from the original agent
            for tool_name, tool_func in MonthlyReport_agent.tools.items():
                temp_agent.tool_plain(tool_func)
            
            answer = await temp_agent.run(question)
            print(f"✓ Successfully completed with model: {model_name}")
            return answer
            
        except Exception as e:
            print(f"✗ Model {model_name} failed during runtime: {str(e)}")
            continue
    
    raise Exception("All models failed during runtime. Please check your API key and internet connection.")

# The main function to run the agent:
async def run_agent_reports(question: str):
    try:
        answer = await MonthlyReport_agent.run(question)
        return answer
    except Exception as e:
        print(f"Primary model failed: {str(e)}")
        print("Attempting fallback to alternative models...")
        return await run_agent_reports_with_fallback(question)

import asyncio

async def main():
    query = "NĐT nữ, tuổi 36, AUM 1 tỷ, đầu tư DCDS và DCIP, holding 8 tháng, PnL 18%, NĐT vừa đặt lệnh bán. Hãy tạo scripts để thuyết phục NĐT tái đầu tư"
    output = await run_agent_reports(query)
    print(output.output)

if __name__ == "__main__":
    asyncio.run(main())
