# app/main.py
from fastapi import FastAPI, Body
from app.pipelines.search_all import run as mcp_search
from app.graph import build_graph
from fastapi.staticfiles import StaticFiles


app = FastAPI(title="Investor Orchestrator")

@app.post("/api/mcp/search")
def mcp_search_api(payload: dict = Body(...)):
    return mcp_search(payload)

_graph = build_graph()

@app.post("/api/graph/qa")
def graph_qa_api(payload: dict = Body(...)):
    state = {
        "query": payload["query"],
        "targets": payload.get("targets", []),
        "top_k": payload.get("top_k", 6),
        "hits": [], "citations": [],
        "policy_points": "", "pitch_lines": "", "report_numbers": "", "pl_findings": "",
        "answer": ""
    }
    final = _graph.invoke(state)
    return {"ok": True, "answer": final.get("answer",""), "citations": final.get("citations",[])}
# === UI tĩnh ===
app.mount("/ui", StaticFiles(directory="public", html=True), name="ui")  