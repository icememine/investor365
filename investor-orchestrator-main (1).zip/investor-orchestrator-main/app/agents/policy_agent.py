# app/agents/policy_agent.py
from typing import List, Dict
from app.llm import get_llm

SYS = (
"Bạn là Policy Agent. Từ các trích đoạn, trích RÕ:\n"
"- Ứng dụng/nơi thao tác (app/portal/form)\n"
"- Cut-off / thời gian xử lý\n"
"- Phí/điều kiện/ngoại lệ\n"
"- Các bước thực hiện (bullet ngắn)\n"
"Mỗi bullet kèm citation [source:title]."
)

def run(query: str, hits: List[Dict]) -> Dict:
    filtered = [h for h in hits if h.get("source") in {"handbook","faq","salescripts","reports"}]
    if not filtered:
        return {"policy_points": ""}
    ctx = []
    for h in filtered[:8]:
        tag = f'[{h.get("source")}:{(h.get("title") or h.get("file_path") or h.get("url"))}]'
        ctx.append(f'{tag}\n{h.get("snippet","")}')
    llm = get_llm()
    msg = [
        {"role":"system","content":SYS},
        {"role":"user","content":f"Câu hỏi: {query}\n\nTài liệu:\n" + "\n\n---\n\n".join(ctx)}
    ]
    content = llm.invoke(msg).content
    return {"policy_points": content}
