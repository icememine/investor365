# app/agents/intent_router.py
import json
from typing import Dict, List
from app.llm import get_llm

ALLOWED = ["handbook","faq","salescripts","reports","pl_investor","website"]

SYS = (
"Bạn là Router. Chọn các NGUỒN phù hợp cho câu hỏi.\n"
"NGUỒN HỢP LỆ: " + ", ".join(ALLOWED) + "\n"
"TRẢ VỀ JSON DUY NHẤT: {\"targets\": [...], \"query_rewrite\": \"...\"}\n"
"Không thêm giải thích."
)

TPL = (
"Câu hỏi: {query}\n"
"Hướng dẫn: Nếu là quy trình/chính sách/biểu phí → ưu tiên handbook, faq, salescripts, reports.\n"
"Nếu chứa dữ liệu khách/PL → thêm pl_investor.\n"
"Nếu nội dung web (sau này bật) → website."
)

def route(query: str) -> Dict:
    llm = get_llm()
    msg = [
        {"role":"system","content":SYS},
        {"role":"user","content":TPL.format(query=query)}
    ]
    raw = llm.invoke(msg).content
    try:
        data = json.loads(raw)
        targets_in = data.get("targets", [])
        q_rew = data.get("query_rewrite") or query
    except Exception:
        # fallback an toàn
        targets_in, q_rew = (["handbook","faq","salescripts","reports"], query)
    targets = [t for t in targets_in if t in ALLOWED]
    # unique, giữ thứ tự
    targets = list(dict.fromkeys(targets))
    if not targets:
        targets = ["handbook","faq","salescripts","reports"]
    return {"targets": targets, "query": q_rew}
