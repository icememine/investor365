from dotenv import load_dotenv
import os
import pandas as pd
from dataclasses import dataclass
from pydantic_ai.models.huggingface import HuggingFaceModel
from pydantic_ai.providers.huggingface import HuggingFaceProvider
from pydantic_ai import Agent, RunContext, ModelRetry
from pydantic import BaseModel, Field
import nest_asyncio
import asyncio
from datetime import date
# from pandas_to_pydantic import dataframe_to_pydantic
pd.set_option('display.max_columns', None)

nest_asyncio.apply()
load_dotenv(dotenv_path=r'.env')

HF_TOKEN = os.getenv("HUGGINGFACEHUB_API_TOKEN")
MODEL_LIST = [
    'Qwen/Qwen3-Next-80B-A3B-Instruct',
    'zai-org/GLM-4.5',
    'moonshotai/Kimi-K2-Instruct-0905',
    'meta-llama/Llama-3.1-8B-Instruct',
    'deepseek-ai/DeepSeek-R1',
]

async def test_api_with_fallback():
    """
    Test API with fallback to alternative models if the current one fails.
    Returns the first working model or raises an exception if all fail.
    """
    for model_name in MODEL_LIST:
        try:
            print(f"Testing model: {model_name}")
            model = HuggingFaceModel(model_name, provider=HuggingFaceProvider(api_key=HF_TOKEN))
            
            # Test the model with a simple query
            test_agent = Agent(model, system_prompt="You are a helpful assistant.")
            
            # Actually test the API call
            test_result = await test_agent.run("Hello, this is a test.")
            print(f"✓ Model {model_name} working successfully")
            return model, model_name
            
        except Exception as e:
            print(f"✗ Model {model_name} failed: {str(e)}")
            continue
    
    raise Exception("All models failed to initialize. Please check your API key and internet connection.")

def test_api_with_fallback_sync():
    """
    Synchronous wrapper for the async test function.
    """
    import asyncio
    return asyncio.run(test_api_with_fallback())

# Initialize the model with fallback
model, selected_model_name = test_api_with_fallback_sync()
print(f"Selected model: {selected_model_name}")

# @dataclass
# class Deps_PL_Investors:
#     df: pd.DataFrame

@dataclass
class CustomerID(BaseModel):
    CustomerID: str = Field(description="The Current Investor Data of the investor", max_length=10)

@dataclass
class FullInvestorData(BaseModel):
    InvestorID: str
    gender: str                 # "Male", "Female"
    dateofbirth: date           # dd/mm/yyyy
    Age_Group: str              # e.g., "b.30-45"
    Full_Name: str
    Current_Portfolio: str
    Current_AUM: float
    Total_Port_PL_Percent: float        # e.g., 52.0
    Total_Port_PL_Percent_range: str    # e.g., "a. <6 tháng"
    Max_Holding_Days: int
    Holding_Period_Range: str           # e.g., "a. <6 tháng"
    Months_from_1st_sub: int
    Frequency_Rate_Percent: float
    Recency_Days_All_Funds: int

pl_investors_agent = Agent(
    model,
    system_prompt="""You are an AI assistant that helps extract information from a pandas DataFrame.
    Be concise in your answers.
    Your tools = df_query, please create the query with the CustomerID basemodel
    """,
    # deps_type=Deps_PL_Investors,
    retries=10,
    output_type=FullInvestorData,
)

@pl_investors_agent.tool_plain
async def df_query(query: CustomerID) -> str:
    """A tool for extracting information from the `pandas.DataFrame`. Use this tool to interact with the DataFrame.
    """
    # Print the query for debugging purposes and fun :)
    print(f'Running query: `{query}`')
    investor_id = str(query)[-12:].replace("'", "")
    print(f"the investor id is: {investor_id}")
    try:
        Investors_data_Excel_file_path = r'./app/pipelines/Investor Portfolio PL data - 09.09.2025.xlsx'
        investors_data_df = pd.read_excel(Investors_data_Excel_file_path)
        current_investor_data = investors_data_df.loc[investors_data_df['InvestorID'] == investor_id]
        # current_investor_data = pd.eval(query, target=ctx.deps.df)
        print("the data extracted from dataframe is:")
        print(current_investor_data)
        return(str(current_investor_data))
    except Exception as e:
        #  On error, raise a `ModelRetry` exception with feedback for the agent.
        raise ModelRetry(f'query: `{query}` is not a valid query. Reason: `{e}`') from e

async def run_agent_pl_investors(question: str):
    answer = await pl_investors_agent.run(question)
    return answer

async def main():
    query = "Cho tôi thông tin về nhà đầu tư có ID là 999C018641"
    output = await run_agent_pl_investors(query)
    print(output.output)

if __name__ == "__main__":
    asyncio.run(main())
