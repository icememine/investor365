# app/pipelines/search_all.py
from __future__ import annotations
import argparse, os
from pathlib import Path
from typing import Dict, Any, List, Tuple

import faiss
import polars as pl
from sentence_transformers import SentenceTransformer
import yaml

DEFAULT_MODEL = "intfloat/multilingual-e5-base"
DEFAULT_K_EACH = 50
DEFAULT_TOP_N = 8

# -------- Config helpers --------

def load_with_env(path: str) -> dict:
    raw = os.path.expandvars(Path(path).read_text(encoding="utf-8"))
    return yaml.safe_load(raw) or {}

def _first_nonempty(*vals):
    for v in vals:
        if v:
            return v
    return None

def guess_chunks_path(name: str, cfg_item: dict) -> str:
    p = (cfg_item or {}).get("chunks")
    if p:
        return p
    return f"data/vector/{name}_chunks.parquet"

def build_sources(cfg: dict) -> Dict[str, dict]:
    """
    Đọc cfg['vectors'] và trả về map nguồn, tương thích nhiều key:
      - index
      - id_map | idmap
      - chunks | chunks_parquet
    """
    out: Dict[str, dict] = {}
    vectors = cfg.get("vectors", {}) or {}
    weights = (cfg.get("retrieval", {}) or {}).get("weights", {}) or {}

    for name, item in vectors.items():
        index = item.get("index")
        id_map = _first_nonempty(item.get("id_map"), item.get("idmap"))
        chunks = _first_nonempty(item.get("chunks"), item.get("chunks_parquet")) or guess_chunks_path(name, item)
        if not (index and id_map and chunks):
            continue
        out[name] = {
            "index": index,
            "idmap": id_map,
            "chunks": chunks,
            "weight": float(weights.get(name, 1.0)),
            "tag": name.upper()[:4],
        }
    return out

def apply_prefer_weights(sources: Dict[str, dict], prefer: str | None):
    if not prefer:
        return
    prefs = {x.strip() for x in prefer.split(",") if x.strip()}
    for n, v in sources.items():
        v["weight"] = float(v.get("weight", 1.0)) * (1.5 if n in prefs else 0.9)

# -------- IO helpers --------

def _safe_exists(p: str) -> bool:
    try:
        return os.path.exists(p)
    except Exception:
        return False

def load_bundle(name: str, cfg: dict, debug: bool = False) -> Tuple[faiss.Index, pl.DataFrame]:
    """
    Đọc Index + tạo bảng META đã JOIN sẵn:
      META[i] ứng với vector id i trong Index (O(1) tra cứu).
    Yêu cầu idmap có cột: doc_id, chunk_idx; chunks có: doc_id, chunk_idx, text (+title/file_path/url nếu có).
    """
    if not (_safe_exists(cfg["index"]) and _safe_exists(cfg["idmap"]) and _safe_exists(cfg["chunks"])):
        raise FileNotFoundError(f"missing artifact for '{name}'")

    index = faiss.read_index(cfg["index"])

    # idmap: phải cùng thứ tự với lúc add vectors vào index
    idmap = pl.read_parquet(cfg["idmap"])
    chunks = pl.read_parquet(cfg["chunks"])

    # Giảm rủi ro thiếu cột: tạo cột mặc định nếu cần
    for col, default in [("title", ""), ("file_path", ""), ("url", "")]:
        if col not in chunks.columns and col not in idmap.columns:
            idmap = idmap.with_columns(pl.lit(default).alias(col))

    # Lấy trường 'text' về từ chunks
    cols_from_chunks = [c for c in ["doc_id", "chunk_idx", "text"] if c in chunks.columns]
    if ("doc_id" in idmap.columns and "chunk_idx" in idmap.columns) and set(cols_from_chunks) >= {"doc_id", "chunk_idx", "text"}:
        meta = idmap.join(
            chunks.select(["doc_id", "chunk_idx", "text"]),
            on=["doc_id", "chunk_idx"],
            how="left",
        )
    else:
        # không đủ cột để join -> để text rỗng
        meta = idmap.with_columns(pl.lit("").alias("text"))

    if debug:
        print(f"[{name}] index.ntotal={index.ntotal}, idmap.rows={meta.height}")

    return index, meta

# -------- Retrieval core --------

_MODEL_CACHE: Dict[str, SentenceTransformer] = {}

def _get_model(model_name: str) -> SentenceTransformer:
    m = _MODEL_CACHE.get(model_name)
    if m is None:
        m = SentenceTransformer(model_name)
        _MODEL_CACHE[model_name] = m
    return m

def cap_per_source(items: List[dict], per_source: int) -> List[dict]:
    if per_source <= 0:
        return items
    cnt, out = {}, []
    for r in items:
        s = r["source"]
        if cnt.get(s, 0) < per_source:
            out.append(r)
            cnt[s] = cnt.get(s, 0) + 1
    return out

def search_all(query: str, model_name: str, k_each: int, top_n: int,
               per_source: int, sources_cfg: Dict[str, dict], include: List[str] | None,
               debug: bool = False) -> List[dict]:
    model = _get_model(model_name)
    # E5: prefix "query: "
    qv = model.encode(["query: " + query], normalize_embeddings=True).astype("float32")

    names = include or list(sources_cfg.keys())
    merged: List[dict] = []

    for n in names:
        cfg = sources_cfg.get(n)
        if not cfg:
            continue
        try:
            idx, meta = load_bundle(n, cfg, debug=debug)
        except Exception as e:
            if debug:
                print(f"[{n}] skip: {type(e).__name__}: {e}")
            continue

        if idx.ntotal == 0 or meta.height == 0:
            if debug:
                print(f"[{n}] empty index or meta")
            continue

        kk = min(k_each, idx.ntotal)
        D, I = idx.search(qv, kk)

        w = float(cfg.get("weight", 1.0))
        tag = cfg.get("tag", n.upper())

        # Lấy trực tiếp dòng meta theo vector-id
        for i, s in zip(I[0].tolist(), D[0].tolist()):
            if i < 0:
                continue
            try:
                row = meta.row(int(i), named=True)
            except Exception:
                # phòng khi index/idmap lệch
                row = {}
            snippet = (row.get("text") or "")[:240].replace("\n", " ")

            merged.append({
                "source": n,
                "tag": tag,
                "score": float(s),
                "wscore": float(s) * w,
                "title": row.get("title") or "",
                "chunk_idx": int(row.get("chunk_idx") or 0),
                "doc_id": row.get("doc_id") or "",
                "file_path": row.get("file_path") or "",
                "url": row.get("url") or "",
                "snippet": snippet,
            })

    merged.sort(key=lambda x: x["wscore"], reverse=True)
    merged = cap_per_source(merged, per_source)
    return merged[:top_n]

# -------- Public API (dùng cho agents/API) --------

def run(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    payload: {"query": str, "sources": [str], "top_k": int?, "k_each": int?, "per_source": int?, "config": str?, "model": str?, "prefer": str?, "debug": bool?}
    """
    query = payload["query"].strip()
    cfg_path = payload.get("config") or os.environ.get("CONFIG_PATH", "config/mcp_config.yaml")
    cfg = load_with_env(cfg_path)

    model_name = payload.get("model") or (cfg.get("retrieval", {}) or {}).get("embed_model", DEFAULT_MODEL)
    k_each = int(payload.get("k_each") or DEFAULT_K_EACH)
    top_n = int(payload.get("top_k") or DEFAULT_TOP_N)
    per_source = int(payload.get("per_source") or 4)
    include = payload.get("sources") or None
    prefer = payload.get("prefer") or ""
    debug = bool(payload.get("debug") or False)

    sources_cfg = build_sources(cfg)
    apply_prefer_weights(sources_cfg, prefer)

    results = search_all(
        query=query,
        model_name=model_name,
        k_each=k_each,
        top_n=top_n,
        per_source=per_source,
        sources_cfg=sources_cfg,
        include=include,
        debug=debug,
    )

    # citations ngắn gọn
    citations = [
        {"source": r["source"], "title": r["title"] or (r["file_path"] or r["url"]), "doc_id": r["doc_id"], "chunk_idx": r["chunk_idx"]}
        for r in results
    ]
    return {"ok": True, "query": query, "results": results, "citations": citations}

# -------- CLI (giữ style của bạn) --------

def main():
    ap = argparse.ArgumentParser(description="Meta-retriever đọc động từ config/mcp_config.yaml")
    ap.add_argument("--q", required=True)
    ap.add_argument("--config", default=os.environ.get("CONFIG_PATH", "config/mcp_config.yaml"))
    ap.add_argument("--k_each", type=int, default=DEFAULT_K_EACH)
    ap.add_argument("--top_n", type=int, default=DEFAULT_TOP_N)
    ap.add_argument("--per_source", type=int, default=4)
    ap.add_argument("--prefer", default="")
    ap.add_argument("--sources", default="")
    ap.add_argument("--model", default="")
    ap.add_argument("--debug", action="store_true")
    args = ap.parse_args()

    cfg = load_with_env(args.config)
    model_name = args.model or (cfg.get("retrieval", {}) or {}).get("embed_model", DEFAULT_MODEL)
    sources_cfg = build_sources(cfg)
    apply_prefer_weights(sources_cfg, args.prefer)
    include = [s.strip() for s in args.sources.split(",") if s.strip()] if args.sources else None

    results = search_all(
        query=args.q,
        model_name=model_name,
        k_each=args.k_each,
        top_n=args.top_n,
        per_source=args.per_source,
        sources_cfg=sources_cfg,
        include=include,
        debug=args.debug,
    )

    for i, r in enumerate(results, 1):
        title = r["title"] or r["file_path"] or r["url"]
        print(f"[{i}] {r['tag']}  {r['score']:.4f}  {title}  (chunk {r['chunk_idx']})")
        if r["url"]: print("    ", r["url"])
        if r["file_path"]: print("    ", r["file_path"])
        if r["snippet"]:
            sn = r["snippet"][:180] + ("..." if len(r["snippet"]) > 180 else "")
            print("     ", sn)

if __name__ == "__main__":
    main()
