def export_csv(data, path: str):
    return {"status": "stub", "rows": len(data)}

def export_md(text: str, path: str):
    return {"status": "stub", "chars": len(text)}
