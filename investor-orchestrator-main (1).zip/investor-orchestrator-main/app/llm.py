# app/llm.py
from typing import Any

def get_llm(model: str = "gpt-4o-mini", temperature: float = 0.2) -> Any:
    """
    Trả về ChatOpenAI, tự tương thích giữa langchain>=0.2 (langchain_openai)
    """
    try:
        from langchain_openai import ChatOpenAI
    except Exception:
        from langchain.chat_models import ChatOpenAI  # type: ignore
    return ChatOpenAI(model=model, temperature=temperature)
