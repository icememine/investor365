<!-- image -->

<!-- image -->

01 KHÁl NIÊM QUAN

02 THÔNG TIN SÁN

QUŸ DCDS QUŸ DCDE DCIP

## 03 ÚNG DUNG DRAGONX

NÂNG CÁP HAN MÚC BÁN BÁN PHUONG THÚC THANH TOÁN CHUONG TRINH ISAVING

<!-- image -->

04

<!-- image -->

<!-- image -->

## KEY CONCEPTS

## WHY SHOULD YOU INVEST IN THE FUND?

<!-- image -->

<!-- image -->

<!-- image -->

## LÀ Gì?

loai chúng khoán do Công

## NAV LÀ Gì? (NET ASSET VALUE)

<!-- image -->

NAV (Net Asset Value) là

NAV = Tông tài sán là giá tri tài sán ròng cúa 1

## TIÊN CUA TÔI DO AI

<!-- image -->

nghiêp bji Công ty quán các nguyên tWc hoat aông vói Úy Ban Chúng Khoán

<!-- image -->

## QUñ CÓ CAM KÉT

<!-- image -->

Theo quy @inh pháp luât nghiêp quán ly theo các nhuân cho nhà qâu tu

## THÔNG TIN

THÔNG TIN DCDS QUŸ QUŸ

THÔNG TIN DCDE QUŸ

QUŸ DCBF

THÔNG TIN QUŸ DCIP QUŸ

<!-- image -->

<!-- image -->

U

## THÔNG TIN QUŸ

## DCDS

DC Dynamic Securities Fund

20/5/2004

hoat aông

Loai quy

Danh muc

## Phí mua

1 - 365 ngày

366

730 ngày

Tù 731 ngày

## LICH MUA

<!-- image -->

## LICH BÁN

<!-- image -->

## Phí bán

## PHí CHUYÊN TIÊN

Do

GS quy quy dinh ngân

hàng

&lt;500 triêu

2500 triêu

6.600

220.000

## PHí BÁN

1,5%

0,59

Thup TNCN

PHI KHÁC

0,19

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Các hang muc thông tin

<!-- image -->

Xác nhân giao dich

01

<!-- image -->

Câp nhât thông tin

02

<!-- image -->

Câp nhât thông tin

03

<!-- image -->

Các nhu câu và câu hòi

(cãp xác nhûn s6 du/NAV;

04

<!-- image -->

U

<!-- image -->

## ÚNG DUNG DRAGONX

NÂNG CÁP HAN MÚC BÁN BÁN CHUONG TRINH iSAVING

<!-- image -->

<!-- image -->

01

Tái app và chon

<!-- image -->

02

<!-- image -->

<!-- image -->

03

<!-- image -->

<!-- image -->

04

<!-- image -->

## Cách 1

<!-- image -->

## Cách 2

<!-- image -->

Sau khi th5c hiên eKYC; trang thái tài khodn chuy n sang Có thê giao dich

<!-- image -->

U

<!-- image -->

<!-- image -->

<!-- image -->

- Nam.
- Phông nên khi chup hai mWt CMNDICCCD giông nhau.

<!-- image -->

U

01

Chon "Tài khoán"

<!-- image -->

02

Tai "Thông tin cá nhân" chon "Câp nhât"

<!-- image -->

DRAGON CAPITAL

Luu ]

- mWt sau, hình selfie và hình QR code

<!-- image -->

## NÂNG CÂP HAN MÚC BÁN

01

Chon "Han múc giao dich bán"

<!-- image -->

02

Chon "Nâng han múc"

<!-- image -->

<!-- image -->

yêu câu nâng han múc

<!-- image -->

01

thanh công cu

<!-- image -->

## 02 Mua

Chon "Mua" và sán phâm

<!-- image -->

02 Bán

Chon "Bán" và sán phâm

<!-- image -->

## MUA BÁN

## 03 Mua

<!-- image -->

03 Bán

Nhâp thông tin tri bán giá

<!-- image -->

<!-- image -->

04

<!-- image -->

<!-- image -->

- thông báo kh'p không thành công.

<!-- image -->

U

## PHUCNG THÚC THANH TOÁN

01

02

Chon thanh toán QR PAY bng

Ngân hàng

<!-- image -->

<!-- image -->

01

Chon thanh toán bxng Chuyên khoán ngân hàng

02

Sao chép thông tin và mj

<!-- image -->

<!-- image -->

tp?

<!-- image -->

## CHUONG TRINH iSAVING

<!-- image -->

<!-- image -->

01

thanh công cu

<!-- image -->

<!-- image -->

02

muón giao dich

<!-- image -->

03

Nhâp s6 tiên và chon

<!-- image -->

<!-- image -->

0

giao dich

<!-- image -->

<!-- image -->

<!-- image -->

## httpslldraqonx comvn

<!-- image -->

<!-- image -->

dragoncapitalcomvn

<!-- image -->

## Tru sv chính:

ty Quán ly quy Dragon Capital Viêt Nam Công

## Chi nhánh Hà Nôi:

Tâng

<!-- image -->

1800 1203

<!-- image -->

cskh@ dragoncapitalcom

wwwfacebook coml dragoncapitalvietnam

<!-- image -->

<!-- image -->

Zalo

<!-- image -->

tài liêu này sã không liêu này chí dành cho muc @ích thông tin và và liên quan. Hiêu lai. Nên nghiên cúu thân trong tài liêu này phái ràng hay phái quá

<!-- image -->