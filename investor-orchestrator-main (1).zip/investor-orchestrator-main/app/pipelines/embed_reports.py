# app/pipelines/embed_reports.py
from __future__ import annotations
import os
from pathlib import Path
import numpy as np
import polars as pl
import faiss
from sentence_transformers import SentenceTransformer

CHUNKS = "data/vector/report_chunks.parquet"
ID_MAP = "data/vector/report_id_map.parquet"
INDEX  = "data/vector/faiss_reports/index.faiss"
MODEL  = "intfloat/multilingual-e5-base"  # tốt cho tiếng Việt
PICKLE = "data/vector/faiss_reports/index.pkl"

def main():
    if not os.path.exists(CHUNKS):
        raise SystemExit(f"Not found: {CHUNKS}")
    df = pl.read_parquet(CHUNKS)

    texts = ["passage: " + t for t in df["text"].to_list()]
    model = SentenceTransformer(MODEL)
    emb = model.encode(texts, batch_size=64, show_progress_bar=True, normalize_embeddings=True)
    emb = emb.astype("float32")

    dim = emb.shape[1]
    index = faiss.IndexFlatIP(dim)  # cosine khi đã normalize
    index.add(emb)

    Path(INDEX).parent.mkdir(parents=True, exist_ok=True)
    faiss.write_index(index, INDEX)

    df.select([
        "chunk_id","doc_id","source","title","file_path","dir_name","pages","chunk_idx","fetched_at","tags"
    ]).write_parquet(ID_MAP)

    print(f"[OK] vectors={emb.shape[0]} dim={dim}")
    print(f"[OK] wrote {INDEX}")
    print(f"[OK] wrote {ID_MAP}")

if __name__ == "__main__":
    main()
