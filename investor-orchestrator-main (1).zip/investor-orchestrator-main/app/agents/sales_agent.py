# app/agents/sales_agent.py
from typing import List, Dict
from app.llm import get_llm

SYS = (
"Bạn là Sales Script Agent. Dựa vào sales scripts liên quan, tạo 4–6 câu thoại gọn:\n"
"- Giải thích quy trình rõ, tiếng Việt lịch sự\n"
"- Nêu thời gian xử lý/cut-off nếu có\n"
"- Nêu phí/điều kiện nếu có\n"
"- Kết thúc bằng CTA rõ ràng\n"
"Mỗi câu kèm citation [salescripts:title] nếu có."
)

def run(query: str, hits: List[Dict]) -> Dict:
    ss = [h for h in hits if h.get("source") == "salescripts"]
    if not ss:
        return {"pitch_lines": ""}
    ctx = []
    for h in ss[:6]:
        tag = f'[salescripts:{(h.get("title") or h.get("file_path"))}]'
        ctx.append(f'{tag}\n{h.get("snippet","")}')
    llm = get_llm()
    msg = [
        {"role":"system","content":SYS},
        {"role":"user","content":f"Ngữ cảnh: {query}\n\nSales scripts:\n" + "\n\n---\n\n".join(ctx)}
    ]
    content = llm.invoke(msg).content
    return {"pitch_lines": content}
