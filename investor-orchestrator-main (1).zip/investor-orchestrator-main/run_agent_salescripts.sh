#!/bin/bash

# Script to run agent_salescripts.py
# Make sure you're in the project root directory

echo "Starting Sales Scripts Agent..."
echo "================================"

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "Virtual environment not found. Creating one..."
    python -m venv venv
fi

# Activate virtual environment
echo "Activating virtual environment..."
source venv/bin/activate  # For Linux/Mac
# For Windows Git Bash, use: source venv/Scripts/activate

# Install/update requirements
echo "Installing requirements..."
pip install -r requirements.txt

# Set Python path to include the app directory
export PYTHONPATH="${PYTHONPATH}:$(pwd)/app"

# Run the agent
echo "Running agent_salescripts.py..."
echo "You will be prompted for your HuggingFace API token."
echo "================================"

python app/agents/agent_salescripts.py

echo "================================"
echo "Agent execution completed."

# Deactivate virtual environment
deactivate
