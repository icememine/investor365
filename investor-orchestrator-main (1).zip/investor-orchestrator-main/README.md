# Investor Orchestrator

> **Agentic AI System for Investor Retention & Customer Support**

A sophisticated multi-agent system designed for Dragon Capital to enhance investor retention through intelligent document search, intent routing, and automated response generation. The system combines vector search, LLM orchestration, and real-time web data to provide comprehensive support for sales, marketing, and customer service teams.

## 🚀 Features

### Core Capabilities
- **Multi-Source Document Search**: Vector-based search across FAQ, reports, sales scripts, and investor data
- **Intent-Aware Routing**: AI-powered intent classification for sales, marketing, and customer service scenarios
- **Real-Time Web Integration**: Live data from trusted financial sources via Perplexity API
- **Graph-Based Orchestration**: LangGraph-powered workflow for complex multi-step reasoning
- **Personalized Responses**: Context-aware answers tailored to specific investor needs

### Data Sources
- **FAQ Database**: Frequently asked questions and standard responses
- **Monthly Reports**: Historical performance data and market analysis
- **Sales Scripts**: Conversation templates and objection handling
- **Investor Data**: Personalized P/L, AUM, and portfolio information
- **Web Sources**: Real-time market data from trusted financial websites

## 🏗️ Architecture

### System Overview
A multi-agent AI system designed to help Sales, Marketing, and Customer Service teams at Dragon Capital by providing intelligent document search, intent routing, and automated response generation.

### Data Standardization Layer (MCP Adapters)
All data sources are standardized through MCP (Model Context Protocol) adapters and converted to vector embeddings for fast similarity search:

```
┌─────────────────────────────────────────────────────────────────┐
│                    DATA SOURCES (MCP Adapters)                  │
├─────────────────────────────────────────────────────────────────┤
│ 1.1 SalesScripts    │ 1.2 Monthly Reports │ 1.3 FAQ Database   │
│ • Conversation      │ • Performance data  │ • Standard responses│
│   templates         │ • Market analysis   │ • Common questions  │
│ • Objection         │ • KPI metrics       │ • Policy info       │
│   handling          │ • Historical data   │ • Procedures        │
├─────────────────────────────────────────────────────────────────┤
│ 1.4 DC Website      │ 1.5 PL Investors                         │
│ • Official content  │ • Personalized data                       │
│ • Real-time updates │ • P/L information                         │
│ • Market news       │ • AUM tracking                           │
│ • Company updates   │ • Portfolio holdings                      │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                    VECTOR DATABASE (FAISS)                      │
│ • Multilingual embeddings (intfloat/multilingual-e5-base)      │
│ • Fast similarity search                                       │
│ • Chunked document storage                                     │
│ • Metadata indexing                                            │
└─────────────────────────────────────────────────────────────────┘
```

### Agent Architecture
The system uses a sophisticated multi-agent workflow with **Graph Agent (2.7)** as the master orchestrator that oversees and coordinates all other agents:

```
┌─────────────────────────────────────────────────────────────────┐
│                        USER QUERY                               │
└─────────────────────┬───────────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────────┐
│ 2.7 GRAPH AGENT (MASTER ORCHESTRATOR)                          │
│ ┌─────────────────────────────────────────────────────────────┐ │
│ │ • Controls entire workflow execution                       │ │
│ │ • Manages all agent coordination                           │ │
│ │ • Handles parallel processing                              │ │
│ │ • Manages state transitions                                │ │
│ │ • Error handling & fallbacks                               │ │
│ │ • Resource allocation & optimization                       │ │
│ └─────────────────────────────────────────────────────────────┘ │
└─────────────────────┬───────────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────────┐
│ 2.1 INTENT ROUTER AGENT (Managed by Graph Agent)               │
│ • Analyzes user intent (Sales/Marketing/CS)                    │
│ • Determines appropriate data sources                          │
│ • Routes to specialized agents                                 │
│ • Handles sensitive data detection                             │
└─────────────────────┬───────────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────────┐
│                    SPECIALIZED AGENTS                           │
│                    (All managed by Graph Agent)                 │
├─────────────────────────────────────────────────────────────────┤
│ 2.2 SALES AGENT        │ 2.3 REPORTS AGENT                     │
│ • Learns from          │ • Learns from Monthly Reports          │
│   SalesScripts         │ • Generates performance insights      │
│ • Creates tailored     │ • Extracts KPI metrics                │
│   sales scripts        │ • Provides market analysis            │
│ • Handles objections   │ • Calculates growth rates             │
├─────────────────────────────────────────────────────────────────┤
│ 2.4 PL ANALYST         │ 2.5 POLICY AGENT                      │
│ • Learns from PL       │ • Learns from FAQ & Handbook          │
│   Investor data        │ • Extracts policy information         │
│ • Performs calculations│ • Provides procedural guidance        │
│ • Generates insights   │ • Handles compliance queries          │
│ • Personalizes data    │ • Explains terms & conditions         │
└─────────────────────┬───────────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────────┐
│ 2.6 SYNTHESIZER AGENT (Managed by Graph Agent)                 │
│ • Combines insights from all agents                            │
│ • Creates comprehensive responses                               │
│ • Maintains citation tracking                                  │
│ • Ensures consistency and accuracy                              │
└─────────────────────┬───────────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────────────┐
│                    FINAL RESPONSE                               │
│ • Structured answer with citations                              │
│ • Actionable recommendations                                    │
│ • Source attribution                                            │
└─────────────────────────────────────────────────────────────────┘
```

### Complete System Flow

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   Web UI        │    │   FastAPI        │    │   LangGraph     │
│   (Static)      │◄──►│   Server         │◄──►│   Orchestrator  │
│                 │    │   • REST API     │    │   • Agent Flow  │
│ • Query Input   │    │   • Authentication│   │   • State Mgmt  │
│ • Source Select │    │   • Rate Limiting│   │   • Error Handle │
│ • Results View  │    │   • Logging      │    │   • Parallel Exec│
└─────────────────┘    └──────────────────┘    └─────────────────┘
                                │                        │
                                ▼                        ▼
                       ┌──────────────────┐    ┌─────────────────┐
                       │   MCP Adapters   │    │   AI Agents     │
                       │   • Data Ingestion│   │   • Intent Router│
                       │   • Vectorization│   │   • Sales Agent  │
                       │   • Search       │   │   • Reports Agent│
                       │   • Caching      │   │   • PL Analyst   │
                       └──────────────────┘    │   • Policy Agent │
                                │              │   • Synthesizer  │
                                ▼              └─────────────────┘
                       ┌──────────────────┐
                       │   Vector Store   │
                       │   • FAISS Index  │
                       │   • Embeddings   │
                       │   • Chunk Storage│
                       │   • Metadata     │
                       └──────────────────┘
```

### Agent Workflow Details

#### **2.7 Graph Agent - Master Orchestrator (Central Controller)**
The Graph Agent is the **master controller** that oversees and coordinates all other agents:

- **🎯 Central Command**: Controls the entire workflow execution from start to finish
- **🔄 Agent Coordination**: Manages all agent interactions and data flow
- **⚡ Parallel Processing**: Orchestrates multiple agents working simultaneously
- **🛡️ Error Handling**: Manages failures and implements fallback strategies
- **📊 Resource Management**: Optimizes performance and resource allocation
- **🔀 State Management**: Maintains workflow state across all agent interactions
- **🎛️ Flow Control**: Determines which agents to activate based on intent analysis

#### **Specialized Agents (All Managed by Graph Agent)**

1. **2.1 Intent Router Agent**: 
   - **Managed by**: Graph Agent
   - Analyzes user queries using LLM
   - Classifies intent (Sales/Marketing/CS)
   - Determines required data sources
   - Handles sensitive data detection

2. **2.2 Sales Agent**: 
   - **Managed by**: Graph Agent
   - Learns from SalesScripts database
   - Generates tailored sales scripts based on intent
   - Handles customer objections
   - Creates personalized pitch content

3. **2.3 Reports Agent**: 
   - **Managed by**: Graph Agent
   - Learns from Monthly Reports
   - Extracts KPI metrics and performance data
   - Generates market analysis insights
   - Calculates growth rates and trends

4. **2.4 PL Analyst**: 
   - **Managed by**: Graph Agent
   - Learns from PL Investor data
   - Performs personalized calculations
   - Generates investor-specific insights
   - Handles AUM and portfolio analysis

5. **2.5 Policy Agent**: 
   - **Managed by**: Graph Agent
   - Learns from FAQ database
   - Extracts policy information
   - Provides procedural guidance
   - Handles compliance queries

6. **2.6 Synthesizer Agent**: 
   - **Managed by**: Graph Agent
   - Combines insights from all specialized agents
   - Creates comprehensive, actionable responses
   - Maintains proper citation tracking
   - Ensures response quality and consistency

#### **Graph Agent's Comprehensive Oversight**
The Graph Agent (2.7) serves as the **master controller** that encompasses and manages all other agents:

```
┌─────────────────────────────────────────────────────────────────┐
│                    GRAPH AGENT (2.7)                           │
│                 MASTER ORCHESTRATOR                            │
│ ┌─────────────────────────────────────────────────────────────┐ │
│ │  🎯 CENTRAL COMMAND CENTER                                 │ │
│ │  • Controls entire system workflow                         │ │
│ │  • Manages all agent lifecycles                            │ │
│ │  • Coordinates parallel execution                          │ │
│ │  • Handles error recovery                                  │ │
│ │  • Optimizes resource allocation                           │ │
│ └─────────────────────────────────────────────────────────────┘ │
│                                                                 │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────┐ │
│  │ 2.1 Intent  │  │ 2.2 Sales   │  │ 2.3 Reports │  │ 2.4 PL  │ │
│  │ Router      │  │ Agent       │  │ Agent       │  │ Analyst │ │
│  │             │  │             │  │             │  │         │ │
│  │ Managed by  │  │ Managed by  │  │ Managed by  │  │Managed  │ │
│  │ Graph Agent │  │ Graph Agent │  │ Graph Agent │  │by Graph │ │
│  └─────────────┘  └─────────────┘  └─────────────┘  └─────────┘ │
│                                                                 │
│  ┌─────────────┐  ┌─────────────┐                              │
│  │ 2.5 Policy  │  │ 2.6 Synth   │                              │
│  │ Agent       │  │ Agent       │                              │
│  │             │  │             │                              │
│  │ Managed by  │  │ Managed by  │                              │
│  │ Graph Agent │  │ Graph Agent │                              │
│  └─────────────┘  └─────────────┘                              │
└─────────────────────────────────────────────────────────────────┘
```

#### **Workflow Execution Flow**
```
User Query → Graph Agent (Master) → Intent Router → Graph Agent (Decision) → 
Specialized Agents (Parallel) → Graph Agent (Coordination) → Synthesizer → 
Graph Agent (Final Review) → Response
```

#### **Key Responsibilities of Graph Agent (2.7)**
- **🔄 Workflow Orchestration**: Manages the entire process from query to response
- **🎛️ Agent Activation**: Decides which agents to activate based on intent analysis
- **⚡ Parallel Coordination**: Runs multiple agents simultaneously for efficiency
- **🛡️ Quality Control**: Ensures all agent outputs meet quality standards
- **📊 Performance Monitoring**: Tracks agent performance and optimizes execution
- **🔀 State Management**: Maintains consistent state across all agent interactions
- **🚨 Error Handling**: Manages failures and implements recovery strategies
- **📈 Resource Optimization**: Allocates computational resources efficiently

## 📋 Prerequisites

- Python 3.8+
- OpenAI API Key
- Perplexity API Key (for web search)
- HuggingFace API Key (for model access)
- LangGraph (for workflow orchestration)
- PydanticAI (for agent framework)
- Git

## 🛠️ Installation

### 1. Clone Repository
```bash
git clone <repository-url>
cd investor-orchestrator
```

### 2. Create Virtual Environment
```bash
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Environment Setup
Create a `.env` file in the project root:
```bash
# Required API Keys
OPENAI_API_KEY=your_openai_api_key_here
PERPLEXITY_API_KEY=your_perplexity_api_key_here

# Optional Configuration
PPLX_MODEL=sonar  # Default Perplexity model
```

### 5. Data Preparation
Ensure your data files are in the correct directories:
- `data/external/faq/faq.parquet`
- `data/local/pl.parquet`
- `data/external/reports/`
- `data/external/salescripts/`

## 🚀 Quick Start

### Start the Server
```bash
python app/main.py
```

The server will start on `http://localhost:8000`

### Access the Web Interface
Open your browser and navigate to:
- **Main UI**: `http://localhost:8000/ui`
- **API Documentation**: `http://localhost:8000/docs`
- **Debug Endpoint**: `http://localhost:8000/api/debug/env`

### Test the System
1. Open the web interface at `http://localhost:8000/ui`
2. Enter a query like: "Soạn kịch bản giới thiệu quỹ DCDS cho khách hàng ưa thích rủi ro thấp"
3. Select data sources (faq, salescripts, reports)
4. Click "Run Graph QA" for full orchestration or "Run MCP Search" for direct search

## 📡 API Endpoints

### Graph QA (Full Orchestration)
```http
POST /api/graph/qa
Content-Type: application/json

{
  "query": "Your question here",
  "targets": ["faq", "salescripts", "reports"],
  "top_k": 6
}
```

### MCP Search (Direct Search)
```http
POST /api/mcp/search
Content-Type: application/json

{
  "query": "Your search query",
  "sources": ["faq", "salescripts", "reports"],
  "top_k": 6
}
```

### Environment Debug
```http
GET /api/debug/env
```

## 🎯 Web Application Features

### For Sales Team
The web application provides powerful tools to help sales teams close more deals:

- **🎯 Intelligent Sales Script Generation**: 
  - AI-powered script creation based on customer profile and product
  - Personalized objection handling responses
  - Dynamic pitch customization for different investor types

- **📊 Performance Analytics Integration**:
  - Real-time access to fund performance data
  - Historical comparison tools
  - KPI extraction from monthly reports

- **🔄 Cross-sell & Upsell Intelligence**:
  - Investor portfolio analysis for targeted recommendations
  - AUM-based opportunity identification
  - Risk profile matching for product suggestions

- **💬 Conversation Support**:
  - Real-time assistance during client calls
  - Policy clarification on-the-fly
  - Compliance guidance integration

### For Marketing Team
Comprehensive marketing support through intelligent content generation:

- **📝 Content Creation Engine**:
  - Automated social media post generation
  - Email marketing template creation
  - Market update content generation

- **🎯 Audience Segmentation Tools**:
  - Investor demographic analysis
  - Behavioral pattern identification
  - Targeted campaign audience selection

- **📈 Market Intelligence**:
  - Real-time market sentiment analysis
  - Competitor performance tracking
  - Industry trend identification

- **📊 Campaign Performance**:
  - ROI tracking and analysis
  - A/B testing recommendations
  - Content optimization suggestions

### For Customer Service Team
Enhanced customer support capabilities with AI assistance:

- **🔧 Technical Troubleshooting**:
  - Step-by-step issue resolution guides
  - App and website problem diagnosis
  - Automated solution recommendations

- **📚 Knowledge Base Integration**:
  - Instant access to FAQ database
  - Policy and procedure lookup
  - Real-time policy consultation

- **💡 Concept Explanation Tools**:
  - Complex financial concept simplification
  - Investor education content generation
  - Multi-language support capabilities

- **⚡ Response Time Optimization**:
  - Instant policy clarification
  - Automated response generation
  - Escalation pathway guidance

## 🎯 Use Cases by Team

### Sales Team Use Cases
- **"Soạn kịch bản giới thiệu quỹ DCDS cho khách hàng ưa thích rủi ro thấp"**
- **"Khách hàng chê phí quản lý của quỹ DCBCF cao, tôi nên trả lời thế nào?"**
- **"So sánh quỹ DCBCF của mình với quỹ VEOF của VinaCapital"**
- **"Lọc danh sách các NĐT có AUM trên 500 triệu nhưng chưa nắm giữ DCBCF"**

### Marketing Team Use Cases
- **"Viết một bài đăng Facebook ngắn gọn về lợi ích của đầu tư dài hạn"**
- **"Tạo email marketing cho chiến dịch quỹ mới"**
- **"Phân tích xu hướng thị trường tháng này"**
- **"Soạn thông báo về thay đổi chính sách quỹ"**

### Customer Service Use Cases
- **"Khách hàng báo lỗi không đặt được lệnh MUA trên app, cần kiểm tra gì?"**
- **"Giải thích cho người mới về lợi suất T+2.5 là gì"**
- **"Hướng dẫn khách hàng báo mất mật khẩu"**
- **"Xử lý phàn nàn về hiệu suất quỹ tháng này"**

## ⚙️ Configuration

### Data Processing Pipeline
The system processes data through a standardized pipeline:

```
Raw Data Sources → MCP Adapters → Chunking → Embedding → Vector Storage
```

#### 1. Data Ingestion (MCP Adapters)
- **SalesScripts**: PDF documents → Text extraction → Conversation templates
- **Monthly Reports**: Excel/PDF → Performance data → KPI metrics
- **FAQ Database**: Excel/CSV → Question-answer pairs → Standard responses
- **DC Website**: Web scraping → Content extraction → Real-time updates
- **PL Investors**: Parquet files → Data processing → Personalized insights

#### 2. Data Standardization
- **Chunking**: Documents split into semantic chunks (512-1024 tokens)
- **Metadata**: Source, title, page number, section tracking
- **Language Detection**: Automatic Vietnamese/English detection
- **Quality Filtering**: Remove duplicates and low-quality content

#### 3. Vector Embedding
- **Model**: `intfloat/multilingual-e5-base` (multilingual support)
- **Dimension**: 768-dimensional vectors
- **Storage**: FAISS index for fast similarity search
- **Update Strategy**: Incremental updates for new documents

### MCP Configuration (`config/mcp_config.yaml`)
- **Website Sources**: Configured trusted domains for web search
- **Vector Storage**: FAISS index paths and chunk configurations
- **Retrieval Parameters**: Search weights and result limits
- **Embedding Model**: `intfloat/multilingual-e5-base`

### State Contract (`config/state_contract.yaml`)
Defines the data structure for agent communication and state management.

## 🔧 Development

### Project Structure
```
investor-orchestrator/
├── app/
│   ├── agents/           # AI agents (router, policy, sales, etc.)
│   ├── mcp_adapters/     # Data source adapters
│   ├── pipelines/        # Data processing and search pipelines
│   ├── graph.py          # LangGraph orchestration
│   ├── llm.py           # LLM configuration
│   └── main.py          # FastAPI server
├── config/              # Configuration files
├── data/               # Data storage
│   ├── external/       # External data sources
│   ├── local/          # Local data files
│   └── vector/         # Vector indices and embeddings
├── public/             # Static web interface
└── requirements.txt    # Python dependencies
```

### Adding New Data Sources
1. Create a new adapter in `app/mcp_adapters/`
2. Add embedding pipeline in `app/pipelines/`
3. Update `config/mcp_config.yaml`
4. Rebuild vector indices

### Customizing Agents
1. Modify agent logic in `app/agents/`
2. Update intent routing in `app/agents/intent_router.py`
3. Adjust graph workflow in `app/graph.py`

## 🧪 Testing

### Manual Testing
Use the web interface at `http://localhost:8000/ui` to test:
- Different query types
- Various data source combinations
- Intent routing accuracy
- Response quality

### API Testing
```bash
# Test Graph QA
curl -X POST "http://localhost:8000/api/graph/qa" \
  -H "Content-Type: application/json" \
  -d '{"query": "Soạn kịch bản bán hàng cho quỹ DCDS", "targets": ["faq", "salescripts"]}'

# Test MCP Search
curl -X POST "http://localhost:8000/api/mcp/search" \
  -H "Content-Type: application/json" \
  -d '{"query": "phí quản lý quỹ", "sources": ["faq", "reports"]}'
```

## 🔒 Security & Privacy

- **Sensitive Data Handling**: Investor data is marked as sensitive and requires special handling
- **API Key Management**: Store API keys in environment variables
- **Data Access Control**: Implement proper access controls for investor data
- **Audit Trail**: All queries and responses are logged for compliance

## 📊 Performance

- **Vector Search**: FAISS-based similarity search for fast retrieval
- **Caching**: Embeddings and indices are cached for performance
- **Parallel Processing**: Multiple data sources searched concurrently
- **Response Time**: Typical response time < 3 seconds for complex queries

## 🐛 Troubleshooting

### Common Issues

1. **API Key Errors**
   - Verify `.env` file exists and contains valid API keys
   - Check `http://localhost:8000/api/debug/env` for key status

2. **Data Not Found**
   - Ensure data files exist in correct directories
   - Run embedding pipelines to generate vector indices

3. **Slow Performance**
   - Check if vector indices are properly built
   - Verify network connectivity for web search

4. **Import Errors**
   - Ensure virtual environment is activated
   - Run `pip install -r requirements.txt` to install dependencies

### Logs
Check the `logs/` directory for detailed error messages and system logs.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is proprietary software developed for Dragon Capital.

## 📞 Support

For technical support or questions:
- Check the troubleshooting section above
- Review the API documentation at `/docs`
- Contact the development team

---

**Built with ❤️ for Dragon Capital's investor retention initiatives**

<!-- synced: 2025-09-09 03:29:47 UTC -->
