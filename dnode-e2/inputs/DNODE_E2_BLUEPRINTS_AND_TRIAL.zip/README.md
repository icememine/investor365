# DNode E2 — three blueprints and cross-model trial

1. Send candidate.zip to Claude. It includes all three updated blueprints, the new architecture, AI instructions, public challenge cases, response template, shared-library contract and the actual frozen E1 author kit.
2. Ask Claude to complete Phase A using START_HERE.md. Keep its first answer before corrections.
3. Read reviewer/ASTRA_TRIAL.md for Astra’s completed answers and explicit design decisions. Do not include this in Claude’s first packet.
4. Compare using reviewer/REVIEW_PROTOCOL.md. Astra’s trial is non-blind. Neither participant should claim human acceptance without observing it.

Existing Astra runtime rerun: 26 checks passed; 0 failed; 7 independent generated campaigns. This is regression evidence for the existing implementation, not validation of new E2 design proposals. No new apps were built and Claude was not run here.

Architecture version: 211020261208. Blueprint experiment: E2.1. Human acceptance pending. Runtime metadata schema for E2 decision records remains unimplemented.
