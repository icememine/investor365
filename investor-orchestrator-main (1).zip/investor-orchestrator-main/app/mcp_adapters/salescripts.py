# app/mcp_adapters/salescripts.py
from __future__ import annotations
import os, argparse, datetime as dt
from pathlib import Path
import polars as pl
import fitz  # pymupdf

def extract_text_from_pdf(path: str) -> str:
    doc = fitz.open(path)
    texts = []
    for page in doc:
        texts.append(page.get_text("text"))
    doc.close()
    return "\n".join(texts)

def main():
    p = argparse.ArgumentParser(description="Extract Sales Scripts PDF -> Parquet")
    p.add_argument("--folder", default="data/external/salescripts")
    p.add_argument("--out", default="data/external/salescripts/salescripts.parquet")
    args = p.parse_args()

    folder = Path(args.folder)
    rows = []
    for f in folder.glob("*.pdf"):
        try:
            text = extract_text_from_pdf(str(f))
            rows.append({
                "file_name": f.name,
                "file_path": str(f),
                "dir_name": f.parent.name,
                "text": text,
                "fetched_at": dt.datetime.utcnow().isoformat(),
            })
            print(f"[OK] parsed {f}")
        except Exception as e:
            print(f"[ERR] {f}: {e}")

    if not rows:
        print("[WARN] No sales scripts parsed.")
        return

    df = pl.DataFrame(rows)
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    df.write_parquet(args.out)
    print(f"[OK] wrote {args.out}, rows={len(rows)}")

if __name__ == "__main__":
    main()
