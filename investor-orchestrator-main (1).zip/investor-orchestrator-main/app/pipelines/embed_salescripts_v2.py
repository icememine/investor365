from docling.document_converter import DocumentConverter
from langchain_community.document_loaders import TextLoader
from langchain.text_splitter import CharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain.vectorstores import FAISS
import os
from dotenv import load_dotenv
# Load environment variables
load_dotenv()

# Define paths
pdf_path = "app/pipelines/Sale Script_Thang 7-2025 (1) (1).pdf"
output_path = "./Sale_script.md"
db_path = "./data/vector/faiss_Sale_script_docling"
model_name  = "dangvantuan/vietnamese-embedding"

# Step 1: Convert PDF to Markdo1wn
converter = DocumentConverter()
result = converter.convert(pdf_path)
with open(output_path, "w", encoding="utf-8") as f:
    f.write(result.document.export_to_markdown())
# Step 2: Load into LangChain
loader = TextLoader(output_path, encoding="utf-8")
documents = loader.load()
text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
docs = text_splitter.split_documents(documents)
# Step 3: Create vector store
embeddings = HuggingFaceEmbeddings(model_name=model_name)
faiss_vector_database = FAISS.from_documents(docs, embeddings)
faiss_vector_database.save_local(db_path)