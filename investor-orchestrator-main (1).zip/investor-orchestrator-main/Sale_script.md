<!-- image -->

## KỊCH BẢN TƯ VẤN QUỸ CỔ PHIẾU- CẬP NHẬT THÁNG 7/2025

## 1. Kinh tế vĩ mô:

Việt Nam đã đạt được một thỏa thuận thuế quan sơ bộ với Hoa Kỳ về mức thuế 20%, thấp hơn nhiều so với mức 30-55% mà các nước cùng khu vực phải đối mặt. Dù vẫn chờ công bố chính thức, thỏa thuận góp phần giảm thiểu rủi ro lớn nhất cho nền kinh tế trong năm 2025 và duy trì vị thế cạnh tranh của Việt Nam trong chuỗi cung ứng toàn cầu. Tác động lên GDP Việt Nam được đánh giá là không đáng kể. Trong khi đó, dòng vốn FDI vẫn duy trì ổn định, phản ánh niềm tin của nhà đầu tư nước ngoài.

Ổn định vĩ mô được duy trì - GDP 6 tháng đầu năm tăng 7,5% (cao nhất trong 10 năm), CPI giữ ở mức 3,3% thấp hơn so với chỉ tiêu đề ra, FDI đăng ký tăng mạnh lên 21,5 tỷ USD (+32,6% YoY), giải ngân đạt 11,7 tỷ USD (+8,1%), chủ yếu vào sản xuất và bất động sản.

## Với nền tảng vĩ mô vững chắc giúp Việt Nam chống chịu tốt với các cú sốc bên ngoài.

1. Cải cách thể chế tiếp tục được thúc đẩy, tháo gỡ xung đột pháp lý cho nhiều dự án, tinh giản thủ tục hành chính. Chuyển mình mạnh mẽ trong phát triển hạ tầng. Tuyến đường sắt cao tốc Bắc - Nam dài 1.541 km đang ở giai đoạn hoàn thiện thủ tục sẽ rút ngắn thời gian di chuyển Hà Nội - TP .HCM còn dưới 6 tiếng.
2. Tăng trưởng đột phá lấy công nghệ làm trung tâm. Dịch chuyển cơ cấu kinh tế sang các lĩnh vực có giá trị gia tăng cao như bán dẫn, AI, công nghệ sinh học, năng lượng sạch.
3. Kinh tế tư nhân đóng vai trò chủ đạo trong chu kỳ mới, dẫn đầu trong nhiều lĩnh vực như đường sắt, năng lượng sạch, sản xuất tiên tiến và blockchain. Nghị quyết 68 bãi bỏ hình sự hóa vi phạm dân sự - kinh tế, khuyến khích tư nhân tham gia đầu tư công.

## 2. Thị trường Chứng khoán

1. Thị trường chuẩn bị được nâng hạng - nhiều khả năng được FTSE Russell nâng lên nhóm thị trường mới nổi ngay từ tháng 9/2025; MSCI có thể theo sau đó trong 1824 tháng . Nâng hạng thường mang lại dòng vốn ngoại lớn, tăng thanh khoản và giảm chi phí vốn.
2. Dự báo lợi nhuận của Doanh nghiệp tích cực. Lợi nhuận của nhóm 80 cổ phiếu hàng đầu dự kiến tăng 14% trong năm 2025 và 18% năm 2026. Thanh khoản thị trường cải thiện đáng kể với giá trị giao dịch trung bình mỗi ngày dao động 30.000

<!-- image -->

## KỊCH BẢN TƯ VẤN QUỸ CỔ PHIẾU- CẬP NHẬT THÁNG 7/2025

tỷ đồng. Dòng vốn ngoại có dấu hiệu quay trở lại. Định giá doanh nghiệp hấp dẫn nhưng vẫn biến động P/E: 11,6 lần (top 80 cổ phiếu).

3. Quỹ cổ phiếu do DCVFM quản lý: Chiến lược đầu tư linh hoạt và hiệu suất dẫn đầu:
1. Chiến lược đầu tư linh hoạt và chủ động cơ cấu tài sản: Quỹ DCDS đang dẫn đầu hiệu suất nhờ: (i) Nắm giữ cổ phiếu chất lượng đúng thời điểm (ii) Chiến lược quản lý chủ động, linh hoạt. (iii) Khả năng chọn lọc cổ phiếu vượt trội so với mặt bằng chung;
2. Thành quả bước đầu: Lợi nhuận luỹ kế 2 năm của DCDS đạt +50% hiện đang là quỹ có kết quả đầu tư tốt nhất trên thị trường. Từ giai đoạn điều chỉnh của thị trường vào ngày 9/4 đến 30/6/2025, quỹ DCDS đã tăng gần 30%.
3. Chiến lược tiếp theo: tiếp tục duy trì sự linh hoạt, tăng tỷ trọng tiền mặt khi cần thiết và giải ngân chọn lọc. Tập trung vào cổ phiếu có nền tảng nội tại tốt, hưởng lợi từ chuyển dịch kinh tế dài hạn.

## KHUYẾN NGHỊ:

Với những chính sách vĩ mô thuận lợi cùng sự phục hồi của thị trường chứng khoán, TTCK Việt Nam đang đứng trước cơ hội lớn để tăng trưởng mạnh mẽ trong thời gian tới. Biến động ngắn hạn là cơ hội: giai đoạn hiện tại phù hợp để phân bổ từng phần, đặc biệt trong các nhịp điều chỉnh. Nhà đầu tư cần cân nhắc kỹ lưỡng và theo dõi sát sao diễn biến thị trường để đưa ra quyết định đầu tư hợp lý.

- Đối với những nhà đầu tư (NĐT) hiện đang nắm giữ cổ phiếu, khuyến nghị tiếp tục nắm giữ và có thể tăng giải ngân trong những phiên thị trường điều chỉnh.
- Đối với NĐT mới, nên giải ngân trong những phiên thị trường điều chỉnh trong giai đoạn tới.
- Thời gian đầu tư khuyến nghị: từ 12 - 18 tháng trở lên, với lợi nhuận kỳ vọng 18 20%/năm trở lên.