@echo off
REM Script to run agent_salescripts.py on Windows
REM Make sure you're in the project root directory

echo Starting Sales Scripts Agent...
echo ================================

REM Check if virtual environment exists
if not exist "venv" (
    echo Virtual environment not found. Creating one...
    python -m venv venv
)

REM Activate virtual environment
echo Activating virtual environment...
call venv\Scripts\activate.bat

REM Install/update requirements
echo Installing requirements...
pip install -r requirements.txt

REM Set Python path to include the app directory
set PYTHONPATH=%PYTHONPATH%;%CD%\app

REM Run the agent
echo Running agent_salescripts.py...
echo You will be prompted for your HuggingFace API token.
echo ================================

python app\agents\agent_salescripts.py

echo ================================
echo Agent execution completed.

REM Deactivate virtual environment
call deactivate

pause
