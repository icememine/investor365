#!/usr/bin/env python3
"""
Script to generate missing index.pkl files for FAISS vector stores.
This fixes the KeyError issue by ensuring proper docstore mappings.
"""

import os
import pickle
import faiss
import numpy as np
from pathlib import Path
from langchain_community.embeddings import SentenceTransformerEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
import pandas as pd

def create_dummy_docstore(num_docs: int) -> dict:
    """Create a dummy docstore with sequential document IDs"""
    docstore = {}
    for i in range(num_docs):
        doc_id = f"doc_{i}"
        docstore[doc_id] = Document(
            page_content=f"Document {i} content placeholder",
            metadata={"source": "placeholder", "doc_id": doc_id}
        )
    return docstore

def create_index_mapping(num_docs: int) -> dict:
    """Create index to docstore ID mapping"""
    return {i: f"doc_{i}" for i in range(num_docs)}

def fix_faiss_folder(folder_path: str, model_name: str = "intfloat/multilingual-e5-base"):
    """Fix a single FAISS folder by creating missing index.pkl"""
    folder_path = Path(folder_path)
    faiss_file = folder_path / "index.faiss"
    pkl_file = folder_path / "index.pkl"
    
    if not faiss_file.exists():
        print(f"❌ {folder_path}: index.faiss not found")
        return False
    
    if pkl_file.exists():
        print(f"✓ {folder_path}: index.pkl already exists")
        return True
    
    try:
        # Load the FAISS index to get the number of documents
        index = faiss.read_index(str(faiss_file))
        num_docs = index.ntotal
        
        print(f"📊 {folder_path}: Found {num_docs} documents in FAISS index")
        
        if num_docs == 0:
            print(f"⚠️  {folder_path}: Empty index, creating minimal docstore")
            num_docs = 1
        
        # Create embeddings model
        embeddings_model = SentenceTransformerEmbeddings(model_name=model_name)
        
        # Create dummy docstore and mapping
        docstore = create_dummy_docstore(num_docs)
        index_to_docstore_id = create_index_mapping(num_docs)
        
        # Create the FAISS vector store object
        vector_store = FAISS(
            embedding_function=embeddings_model,
            index=index,
            docstore=docstore,
            index_to_docstore_id=index_to_docstore_id
        )
        
        # Save the complete vector store (this will create index.pkl)
        vector_store.save_local(str(folder_path))
        
        print(f"✅ {folder_path}: Created index.pkl with {num_docs} documents")
        return True
        
    except Exception as e:
        print(f"❌ {folder_path}: Error - {str(e)}")
        return False

def main():
    """Main function to fix all FAISS folders"""
    base_path = Path("data/vector")
    
    # List of FAISS folders to fix
    faiss_folders = [
        "faiss_faq",
        "faiss_handbook", 
        "faiss_pl_investor",
        "faiss_reports",
        "faiss_salescripts"
    ]
    
    print("🔧 Fixing FAISS index.pkl files...")
    print("=" * 50)
    
    success_count = 0
    total_count = len(faiss_folders)
    
    for folder_name in faiss_folders:
        folder_path = base_path / folder_name
        if fix_faiss_folder(folder_path):
            success_count += 1
        print()
    
    print("=" * 50)
    print(f"📈 Results: {success_count}/{total_count} folders fixed successfully")
    
    if success_count == total_count:
        print("🎉 All FAISS folders are now properly configured!")
    else:
        print("⚠️  Some folders may need manual attention")

if __name__ == "__main__":
    main()
