#!/usr/bin/env python3
"""
Proper fix for FAISS docstore issues - creates correct InMemoryDocstore objects
"""

import os
import pickle
import faiss
import pandas as pd
from pathlib import Path
from langchain_community.embeddings import SentenceTransformerEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from langchain_core.stores import InMemoryDocstore

def fix_faiss_docstore(folder_path: str, model_name: str = "intfloat/multilingual-e5-base"):
    """Fix a single FAISS folder by creating proper InMemoryDocstore"""
    folder_path = Path(folder_path)
    faiss_file = folder_path / "index.faiss"
    pkl_file = folder_path / "index.pkl"
    
    if not faiss_file.exists():
        print(f"❌ {folder_path}: index.faiss not found")
        return False
    
    try:
        # Load the FAISS index to get the number of documents
        index = faiss.read_index(str(faiss_file))
        num_docs = index.ntotal
        
        print(f"📊 {folder_path}: Found {num_docs} documents in FAISS index")
        
        if num_docs == 0:
            print(f"⚠️  {folder_path}: Empty index, creating minimal docstore")
            num_docs = 1
        
        # Create embeddings model
        embeddings_model = SentenceTransformerEmbeddings(model_name=model_name)
        
        # Try to load existing pkl to see what's wrong
        existing_docstore = None
        existing_mapping = None
        
        if pkl_file.exists():
            try:
                with open(pkl_file, 'rb') as f:
                    pkl_data = pickle.load(f)
                    if hasattr(pkl_data, 'docstore'):
                        existing_docstore = pkl_data.docstore
                    if hasattr(pkl_data, 'index_to_docstore_id'):
                        existing_mapping = pkl_data.index_to_docstore_id
            except Exception as e:
                print(f"⚠️  {folder_path}: Could not load existing pkl: {e}")
        
        # Create proper InMemoryDocstore
        docstore = InMemoryDocstore()
        index_to_docstore_id = {}
        
        # Try to find corresponding parquet files for real content
        folder_name = folder_path.name
        base_path = folder_path.parent
        chunks_file = base_path / f"{folder_name.replace('faiss_', '')}_chunks.parquet"
        
        if chunks_file.exists():
            print(f"📄 {folder_path}: Found chunks file: {chunks_file}")
            try:
                df = pd.read_parquet(chunks_file)
                print(f"📊 {folder_path}: Loaded {len(df)} chunks from parquet")
                
                # Create proper documents from parquet data
                for idx, row in df.iterrows():
                    if idx < num_docs:  # Ensure we don't exceed FAISS index size
                        doc_id = f"doc_{idx}"
                        content = str(row.get('text', row.get('content', f'Document {idx}')))
                        metadata = {
                            'source': row.get('source', folder_name),
                            'doc_id': doc_id,
                            'index': idx
                        }
                        
                        # Add any additional metadata from parquet
                        for col in df.columns:
                            if col not in ['text', 'content']:
                                metadata[col] = row[col]
                        
                        # Create document and add to proper docstore
                        doc = Document(page_content=content, metadata=metadata)
                        docstore.add({doc_id: doc})
                        index_to_docstore_id[idx] = doc_id
                
                print(f"✅ {folder_path}: Created proper docstore with {len(docstore._dict)} documents from parquet")
                
            except Exception as e:
                print(f"⚠️  {folder_path}: Error reading parquet, using dummy data: {e}")
                # Fallback to dummy data with proper docstore
                for i in range(num_docs):
                    doc_id = f"doc_{i}"
                    doc = Document(
                        page_content=f"Document {i} content from {folder_name}",
                        metadata={"source": folder_name, "doc_id": doc_id, "index": i}
                    )
                    docstore.add({doc_id: doc})
                    index_to_docstore_id[i] = doc_id
        else:
            print(f"⚠️  {folder_path}: No chunks parquet found, using dummy data")
            # Create dummy docstore with proper InMemoryDocstore
            for i in range(num_docs):
                doc_id = f"doc_{i}"
                doc = Document(
                    page_content=f"Document {i} content from {folder_name}",
                    metadata={"source": folder_name, "doc_id": doc_id, "index": i}
                )
                docstore.add({doc_id: doc})
                index_to_docstore_id[i] = doc_id
        
        # Create the FAISS vector store object with proper docstore
        vector_store = FAISS(
            embedding_function=embeddings_model,
            index=index,
            docstore=docstore,  # This is now a proper InMemoryDocstore
            index_to_docstore_id=index_to_docstore_id
        )
        
        # Save the complete vector store (this will create proper index.pkl)
        vector_store.save_local(str(folder_path))
        
        print(f"✅ {folder_path}: Successfully created proper index.pkl with InMemoryDocstore")
        return True
        
    except Exception as e:
        print(f"❌ {folder_path}: Error - {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Main function to fix all FAISS docstores properly"""
    base_path = Path("data/vector")
    
    # List of FAISS folders to fix
    faiss_folders = [
        "faiss_faq",
        "faiss_handbook", 
        "faiss_pl_investor",
        "faiss_reports",
        "faiss_salescripts"
    ]
    
    print("🔧 Properly fixing FAISS docstores with InMemoryDocstore...")
    print("=" * 60)
    
    success_count = 0
    total_count = len(faiss_folders)
    
    for folder_name in faiss_folders:
        folder_path = base_path / folder_name
        if fix_faiss_docstore(folder_path):
            success_count += 1
        print()
    
    print("=" * 60)
    print(f"📈 Results: {success_count}/{total_count} docstores fixed properly")
    
    if success_count == total_count:
        print("🎉 All FAISS docstores now use proper InMemoryDocstore!")
        print("💡 The 'dict' object has no attribute 'search' error should be resolved.")
    else:
        print("⚠️  Some docstores may need manual attention")

if __name__ == "__main__":
    main()
