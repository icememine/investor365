import os
import numpy as np
import faiss

# --- LangChain Imports ---
# Make sure to install the necessary packages:
# pip install langchain faiss-cpu sentence-transformers
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import SentenceTransformerEmbeddings

# --- Configuration ---
# We'll create a new index and folder for this LangChain example
INDEX_DIR = "faiss_salescripts.index"
MODEL_NAME = "all-MiniLM-L6-v2" # A popular, fast, and free sentence-transformer model

# --- Step 1: Create and Save a Dummy FAISS Index with Text Data ---
# To perform a meaningful natural language search, we need text associated with our vectors.
# LangChain's FAISS wrapper handles the creation of vectors from text and building the index.
# In your real use case, you would load your existing index, but you MUST use the
# same embedding model that was used to create it.

def create_and_save_langchain_index():
    """
    Creates a FAISS index from a list of texts using LangChain.
    """
    print(f"--- Creating a new FAISS index for LangChain at '{INDEX_DIR}' ---")
    
    # Sample text data. In a real application, this would be your documents.
    documents = [
        "The cat sat on the mat.",
        "The dog chased the squirrel.",
        "Paris is the capital of France.",
        "The Eiffel Tower is a famous landmark in Paris.",
        "Apples are a type of fruit that grow on trees.",
        "Quantum computing is a complex field of study."
    ]
    
    # Initialize the embedding model
    print(f"Loading embedding model: '{MODEL_NAME}'")
    # This model will run locally on your CPU
    embeddings = SentenceTransformerEmbeddings(model_name=MODEL_NAME)
    
    # Use LangChain's FAISS class to automatically create embeddings and build the index
    # This is the most common and convenient way to create a vector store.
    print("Creating vector store from documents...")
    vector_store = FAISS.from_texts(documents, embeddings)
    
    # Save the index and the document mappings to disk
    print(f"Saving index to local directory: '{INDEX_DIR}'")
    vector_store.save_local(INDEX_DIR)
    
    return vector_store

# Check if the LangChain index directory already exists. If not, create it.
if not os.path.exists(INDEX_DIR):
    vector_store = create_and_save_langchain_index()
else:
    print(f"Index directory '{INDEX_DIR}' already exists. Skipping creation.")

# --- Step 2: Load the FAISS Index and Embedding Model ---
print(f"\n--- Loading index and embeddings from '{INDEX_DIR}' ---")
# You MUST use the same embedding model you used to create the index
embeddings_model = SentenceTransformerEmbeddings(model_name=MODEL_NAME)
try:
    loaded_vector_store = FAISS.load_local(INDEX_DIR, embeddings_model, allow_dangerous_deserialization=True)
    print("Vector store loaded successfully.")
except Exception as e:
    print(f"Error loading vector store: {e}")
    exit()


query = "What is a famous place in France?"
print(f"\n--- Performing search for query: '{query}' ---")
k = 2
similar_docs = loaded_vector_store.similarity_search(query, k=k)
print(f"Top {k} most similar documents:")
for i, doc in enumerate(similar_docs):
    print(f"{i+1}. Content: '{doc.page_content}'")

