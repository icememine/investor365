#!/usr/bin/env python3
"""
Test script to verify FAISS docstore fix works properly
"""

import os
from pathlib import Path
from langchain_community.embeddings import SentenceTransformerEmbeddings
from langchain_community.vectorstores import FAISS

def test_faiss_folder(folder_path: str):
    """Test if a FAISS folder works properly"""
    folder_path = Path(folder_path)
    
    if not folder_path.exists():
        print(f"❌ {folder_path}: Folder does not exist")
        return False
    
    faiss_file = folder_path / "index.faiss"
    pkl_file = folder_path / "index.pkl"
    
    if not faiss_file.exists():
        print(f"❌ {folder_path}: index.faiss not found")
        return False
    
    if not pkl_file.exists():
        print(f"❌ {folder_path}: index.pkl not found")
        return False
    
    try:
        # Try to load the vector store
        embeddings_model = SentenceTransformerEmbeddings(model_name="intfloat/multilingual-e5-base")
        vector_store = FAISS.load_local(str(folder_path), embeddings_model, allow_dangerous_deserialization=True)
        
        print(f"✅ {folder_path}: Successfully loaded vector store")
        print(f"   📊 Total documents: {vector_store.index.ntotal}")
        print(f"   🗂️  Docstore type: {type(vector_store.docstore)}")
        
        # Test a simple search
        try:
            results = vector_store.similarity_search("test query", k=1)
            print(f"   🔍 Search test: SUCCESS (found {len(results)} results)")
            return True
        except Exception as e:
            print(f"   🔍 Search test: FAILED - {e}")
            return False
            
    except Exception as e:
        print(f"❌ {folder_path}: Error loading - {e}")
        return False

def main():
    """Test all FAISS folders"""
    base_path = Path("data/vector")
    
    faiss_folders = [
        "faiss_faq",
        "faiss_handbook", 
        "faiss_pl_investor",
        "faiss_reports",
        "faiss_salescripts"
    ]
    
    print("🧪 Testing FAISS folders...")
    print("=" * 50)
    
    success_count = 0
    total_count = len(faiss_folders)
    
    for folder_name in faiss_folders:
        folder_path = base_path / folder_name
        if test_faiss_folder(folder_path):
            success_count += 1
        print()
    
    print("=" * 50)
    print(f"📈 Test Results: {success_count}/{total_count} folders working properly")
    
    if success_count == total_count:
        print("🎉 All FAISS folders are working correctly!")
    else:
        print("⚠️  Some folders need fixing. Run fix_faiss_docstore_proper.py")

if __name__ == "__main__":
    main()
