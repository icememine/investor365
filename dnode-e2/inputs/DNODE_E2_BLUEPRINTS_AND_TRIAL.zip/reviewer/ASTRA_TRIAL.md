# Astra — E2 Phase A submission and existing-runtime regression

Date: 21 October 2026. Architecture: 211020261208. Participant: current Codex/Astra session; exact backend model version is not independently verified here. Prior exposure: designed these blueprints, implemented the earlier Astra reference and inspected Fable reports. **This is non-blind, author-exposed evidence.** It cannot establish independent transfer or rank models fairly against a fresh Claude session.

No new E2 application implementation was built in this turn. Phase A answers below are predictions/design decisions. The existing E1 runtime regression was actually executed separately. New E2 blueprint records are not runtime-certified.

## BP-SHOP

### Purpose and classification

Help a customer buy with a correct price and an understandable payment outcome, while giving an operator a safe inventory import. The important human outcome is knowing what happened and what to do next.

D-S1/S2/S3 are inherited experiment choices, fixed in this trial: reservation timing, physical-unsold snapshot meaning and simulation. They are not necessities of all shops. S02–S07 impose behavioral requirements. A-S1 requires checking the host's actual contention scope. D-S4/S5 delegate presentation. Human acceptance remains unresolved.

### My decisions

**AS-D1, chosen/constrained:** at 390 CSS pixels, use one-column product cards and a full-width review button; at 1280 pixels, use a product area and 360-pixel order summary. Minimum primary control height 48 CSS pixels. Reason: keep price and next action readily visible (S01/S08). Assumption: readable font and normal viewport scaling; long translations may reflow. Tradeoff: more scrolling on mobile. Responsibility: host presentation only. Validation: first-time purchase task at both viewports; still pending. Successor may change spacing/layout if the same acceptance succeeds.

**AS-D2, chosen/constrained:** uncertain orders show a persistent amount/order reference, plain uncertainty text and one recovery action; no fresh-payment action for that instruction. Use status icon plus text, not color alone. Reason: prevent a lost response from creating a second payment (S03/S05/S07/S08). Tradeoff: recovery may remain unresolved while inquiry is unavailable. Responsibility: status projection plus host UI; operation identity stays in DNode state. Validate by lost-reply/reload/repeated-recovery traces and human status reading. Wording may change; payment meaning is fixed.

### Four-field definition: recovery

Domain: a valid persisted pending/unknown order with immutable instruction and reservation. Relationship: inquiry retrieves the existing operation's status; confirmed consumes the owned reservation once, definite decline releases it once, unknown retains it. Failures: malformed state faults; changed intent conflicts; unavailable inquiry leaves unknown. Execution: restore identity, dispatch authorized inquiry, atomically apply only permitted terminal transition; repeated terminal notification is idempotent. Never infer failure from elapsed time.

### Challenge predictions

- S-T1: H=3, R=1, A=2. Snapshot replaces physical unsold stock; it is not added to it and is not already net available.
- S-T2: preserve the same instruction and reservation while unknown. Both recovery actions inquire/continue that operation. On confirmed reconciliation, consume once, not once per reply. At most one charge for the instruction.
- S-T3: changed amount under the same key conflicts. A deliberate second identical purchase gets a new key and a new reservation/payment process.
- S-T4: atomic read/check/reserve at the authoritative state boundary serializes contenders. One succeeds and the other observes unavailable stock. A sequential sold-out UI case does not establish this.
- S-T5: text "2" fails integer shape validation at that node; not stock refusal. A declared UI/input adapter may parse strict text before calling the typed node, retaining its own validation rules.

### Continuation S-C1

Revise AS-D2 wording to: **“Chưa xác nhận được kết quả thanh toán. Đơn hàng của bạn vẫn được giữ. Hãy kiểm tra lại trạng thái trước khi thực hiện thanh toán khác.”** Recovery label: **“Kiểm tra trạng thái thanh toán”**. Show amount/reference beside this text. Do not say “chưa bị trừ tiền” or “thanh toán thất bại”. Translation/layout may change; identity, inquiry semantics and held reservation remain fixed. Vietnamese comprehension and small-screen layout need new human checks; transaction regression remains required.

### Obligation mapping

| IDs | Responsibility | Evidence/status |
|---|---|---|
| S01,S08 | AS-D1/AS-D2 presentation | E2 human tasks pending |
| S02 | cart/domain/price nodes | Existing regression passed as a group; new UI adapter not implemented |
| S03 | operation binding and terminal transitions | Existing simulator checks; no production guarantee |
| S04 | host transaction boundary plus reservation rule | Existing simulated-lock check; actual broader deployment scope unresolved |
| S05,S07 | persisted identity and inquiry recovery | Existing lost-response/reload-related logic checks; E2 UI flow pending |
| S06 | release and snapshot compatibility | Existing regression; new records not independently certified |

Handoff: preserve D-S1–S3; inherit AS-D1/AS-D2 as explicit proposals pending implementation/acceptance. Inspect the kit's shop/profile boundaries before changing code. Verify contention scope and test Vietnamese recovery without coaching. Release status: incomplete.

## BP-GAME

### Purpose and classification

Provide immediately understandable, responsive Breakout. G03/G05 are computational requirements; G01/G06 need people. D-G1 is a fixed experiment choice. D-G3 fixes this comparison at 60 ticks/sec and five catch-up ticks, although other games may choose differently. D-G4/G5 permit geometry, control and feedback decisions. Device behavior under A-G1 remains to be measured.

### My decisions

**AG-D1, chosen/review-required:** logical field 4800×6400; ball represented for collision by a 120×120 axis-aligned box (rendered as a circle), paddle 900×100 at y=5900, 30 bricks at x=150+c×760, y=500+r×230, each 700×180, for c=0…5 and r=0…4. Physics uses four ordered microsteps per tick; per-microstep velocity components limited to ±40 logical units. For equal-time contacts in the declared discrete policy, resolve walls, then paddle, then lowest intact brick ID; score/remove at most that selected brick per microstep. Axis reflection uses previous non-overlapping side; ambiguous overlap reflects vertical velocity. Reason: deterministic, inspectable collision decisions for G03/G05. Tradeoff: box corners differ from circular physics; microsteps alone do not prove all tunneling cases absent. Validation: boundary/corner/high-speed independent cases and human fairness. This is my proposed policy, not a claim that existing code matches every coordinate. A successor must not silently alter it after evidence is bound.

**AG-D2, chosen/constrained:** pointer drag anywhere in a transparent playfield overlay controls paddle center by relative horizontal movement; first touch records an offset without jumping the paddle. Clamp center to [450,4350]. Pointer-up retains position. Keyboard arrows move 60 units per microstep while held. Explicit launch/pause buttons are at least 48 CSS pixels. Reason: G01/G02/G06, supporting one-handed control without covering the paddle. Tradeoff: movement accumulates from the initial touch rather than mapping absolutely to the screen. Validation: touch/keyboard task and event replay; not yet performed. No collision/scoring change is authorized by this control choice.

### Four-field definition: pause

Domain: valid state and ordered pause/resume/frame events. Relationship: gameplay projection is unchanged by paused ticks. Failures: malformed events fail validation; unavailable pointer bridge is a profile gap. Execution: pause flag/menu may update, simulation does not; host discards paused elapsed backlog; resume only advances subsequent ticks under five-tick cap.

### Challenge predictions

- G-T1: caps three and five can produce different states after a delayed frame; not generally equivalent. Both may meet broad playability goals. E2 fixes five, 60 Hz and excess-backlog discard.
- G-T2: ball, bricks, score, lives and gameplay paddle state remain frozen across paused ticks; menu/control state may change. Thirty seconds of paused time is discarded, not simulated on resume.
- G-T3: use AG-D1's lowest-ID rule after prior wall/paddle handling. This is my choice under D-G4, not an inherited universal law. Test an exact corner contact with two intact bricks, then reverse storage order while preserving IDs; result should remain stable.
- G-T4: policy agreement does not establish enjoyment. Need first-time control, readability, frustration and fairness observations on actual devices.
- G-T5: renderer cannot repair the authoritative ball state. Correct the rendering defect, or explicitly revise game logic with new evidence if the state rule is wrong.

### Continuation G-C1

AG-D2 is the proposed touch improvement: relative drag with preserved initial offset, no jump on first contact, retain position on release. Record playfield-to-logical scaling from actual element bounds; pointer capture keeps drag active within the session, and cancellation releases control. Prevent page scrolling only for the gameplay gesture surface. Keep collision, score, lives, launch and timing identities unchanged. Rerun input traces and obtain real touch feedback before calling it improved.

### Obligation mapping

| IDs | Responsibility | Evidence/status |
|---|---|---|
| G01,G02,G06 | input bridge, controls, render/audio | E2 implementation and human/device tests pending |
| G03 | AG-D1 physics and phase nodes | New policy cases pending; old regression does not validate these new choices |
| G04 | pause/restart state plus host schedule | Existing reference regression passed; E2 binding comparison still needed |
| G05 | deterministic transition and replay records | Existing reference regression passed; AG-D1/AG-D2 replay pending |

Handoff: inherit fixed D-G1–G3; AG-D1/AG-D2 are proposed choices, not already certified mechanics. Implement and pin them or explicitly revise before generating traces. Keep rendering generic. Do not claim microstep count by itself proves collision completeness. Release incomplete.

## BP-BATCH

### Purpose and classification

Give an operator a trustworthy whole snapshot and a clear path to fix bad source data. D-B1–B4 are fixed experiment policies. A-B1 is a host guarantee to verify. D-B5 delegates report presentation. Partial acceptance is not existing freedom because it changes replacement-snapshot meaning.

### My decisions

**AB-D1, chosen/constrained:** the result header always states either “Accepted — new snapshot ready” or “Rejected — no new snapshot published”. Display current run identity and separately label any prior output “Previous successful snapshot”. Reason: prevent stale output being mistaken for this run (B03/B05/B06). Tradeoff: more metadata, kept compact. Responsibility: report presenter backed by explicit publication status. Validate with valid→invalid run sequence and operator interpretation; pending for E2.

**AB-D2, chosen/constrained:** errors group by logical record number, then field, showing raw field value and specific rule. Duplicate errors list every participating record. Preview preserves names, including line breaks, without interpreting them as markup. Reason: actionable correction (B02/B03/B06). Tradeoff: long names/messages require expandable rows. Responsibility: DNode diagnostic records plus host escaped rendering. Validation: multiline and duplicate fixtures, then an unaided correction task. A successor may change visual grouping while preserving locations and meaning.

### Four-field definition: publication

Domain: accepted nonempty unique supplier snapshot under declared numeric/text rules. Relationship: sort by SKU and encode using pinned export format; only complete accepted snapshot becomes new output. Failures: any invalid record rejects current snapshot; report says rejected; host write failure leaves prior output under its atomic guarantee. Execution: decode/parse/validate, stage complete bytes, atomic snapshot replace. Snapshot/report pair is not assumed atomic unless separately supported; bind the report to the run/output identity.

### Challenge predictions

- B-T1: one PEN record, NAME exactly "Blue, fine", price 20000, quantity 3; leading zeroes normalize. Output field spelling/bytes follow the pinned export encoding, not guessed JSON names.
- B-T2: " 20000" is numeric grammar rejection at PRICE_VND. 9007199254740992 is out-of-range field rejection before bounded conversion. Both reject the snapshot with located diagnostics; neither silently trims or rounds.
- B-T3: duplicate rejects entire snapshot even if identical; no new accepted snapshot. Report all duplicate record indices. Deduplication is not permitted.
- B-T4: quoted newline stays inside the same field/record. Logical data-record indexing determines locations, not physical line count.
- B-T5: retain previous output; current report explicitly rejected/no new publication. Never present old bytes as this run's accepted result. AB-D1 makes the distinction visible.

### Continuation B-C1

Do not enable partial acceptance under this blueprint. Propose a new explicit import mode with a new meaning contract: either an independently complete replacement snapshot or a patch whose omissions mean “unchanged”. A patch needs separate identity/schema, conflict/deletion rules and shop support; a subset of a rejected replacement cannot silently become a complete snapshot. Review shared supplier root, reservation compatibility, report semantics, publication guarantees and dependent certificates. Preserve current whole-file path until the extension is explicitly adopted and tested.

### Obligation mapping

| IDs | Responsibility | Evidence/status |
|---|---|---|
| B01,B02 | pinned CSV lexer and supplier root | Existing regression passed; new independent fixtures remain useful |
| B03 | domain/range/duplicate validation | Existing regression plus E2 public predictions; no hidden test claim |
| B04 | canonical export, pinned transformer | Existing semantics; E2 output identity binding needs verification |
| B05 | host staged atomic replacement and limits | Existing single-file check; not a multi-file transaction guarantee |
| B06 | AB-D1/AB-D2 report | Human correction task pending |

Handoff: preserve D-B1–B4, implement explicit current/prior status and record locations, verify A-B1, and treat partial acceptance as a separately reviewed extension. Release incomplete.

## Actual regression execution

Command: `node tests/run.mjs` in the existing Astra E1 repository.

Observed stdout: `26 checks passed; 0 failed; 7 independent generated campaigns`.

This rerun covers the existing reference implementation, not newly proposed AG-D1/AG-D2 geometry/input behavior or E2 decision-record enforcement. No human acceptance was performed. No Claude execution was performed in this session. The result is computational regression evidence plus a non-blind Phase A submission, not a completed cross-model study.
