# app/mcp_adapters/website.py
from __future__ import annotations
import os, re, sys, json, argparse, hashlib, time
import datetime as dt
from pathlib import Path
from typing import List, Dict, Any, Optional
from urllib.parse import urlparse, urljoin, urldefrag

import httpx
import polars as pl
import yaml  # pyyaml

# -------- Optional extractors --------
try:
    import trafilatura
except Exception:
    trafilatura = None

try:
    from readability import Document
except Exception:
    Document = None

try:
    from langdetect import detect
except Exception:
    def detect(_): return ""

# -------- Optional JS rendering --------
PLAYWRIGHT_AVAILABLE = False
try:
    from playwright.sync_api import sync_playwright
    PLAYWRIGHT_AVAILABLE = True
except Exception:
    pass

USER_AGENT = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36 MCPBot/1.2"
)

APP_DIR = Path(__file__).resolve().parents[1]
DATA_ROOT = (APP_DIR / ".." / "data").resolve()
WEB_DIR = DATA_ROOT / "external" / "web"
PARQUET_PATH = WEB_DIR / "articles.parquet"
WEB_DIR.mkdir(parents=True, exist_ok=True)

# ===================== utils =====================
def _load_yaml(path: str | os.PathLike) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}

def _norm_url(u: str) -> str:
    # chuẩn hoá + bỏ fragment
    u, _frag = urldefrag(u or "")
    p = urlparse(u)
    scheme = p.scheme or "https"
    netloc = p.netloc.lower()
    path = re.sub(r"/+", "/", p.path or "/")
    q = f"?{p.query}" if p.query else ""
    return f"{scheme}://{netloc}{path}{q}"

def _sha1(s: str) -> str:
    return hashlib.sha1(s.encode("utf-8")).hexdigest()

def _domain(u: str) -> str:
    return urlparse(u).netloc.lower()

def _safe_detect(text: str) -> str:
    try:
        t = (text or "").strip()
        if len(t) < 20:
            return ""
        return detect(t)
    except Exception:
        return ""

def _allowed(url: str, allowlist: List[str]) -> bool:
    u = _norm_url(url)
    return any(u.startswith(prefix.rstrip("/")) for prefix in allowlist)

def _fetch_httpx(u: str, timeout: int = 25) -> tuple[int, str, int]:
    with httpx.Client(timeout=timeout, headers={"User-Agent": USER_AGENT}) as c:
        r = c.get(u, follow_redirects=True)
        return r.status_code, r.text, len(r.content)

def _fetch_playwright(u: str, timeout: int = 25) -> tuple[int, str, int]:
    if not PLAYWRIGHT_AVAILABLE:
        raise RuntimeError("Playwright not installed. `pip install playwright && python -m playwright install chromium`")
    to_ms = timeout * 1000
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page(user_agent=USER_AGENT)
        page.goto(u, timeout=to_ms, wait_until="networkidle")
        html = page.content()
        browser.close()
        return 200, html, len(html.encode("utf-8"))

def _fetch(u: str, timeout: int = 25, render_js: bool = False) -> tuple[int, str, int]:
    if render_js:
        try:
            return _fetch_playwright(u, timeout=timeout)
        except Exception:
            # fallback httpx nếu playwright lỗi
            return _fetch_httpx(u, timeout=timeout)
    return _fetch_httpx(u, timeout=timeout)

def _extract_text(html: str, url: str) -> Dict[str, Any]:
    # trafilatura ưu tiên
    if trafilatura:
        try:
            text = trafilatura.extract(html, include_comments=False, include_tables=False, url=url)
            meta = trafilatura.extract_metadata(html, url=url) or {}
            if text:
                return {
                    "title": (meta.get("title") or "").strip(),
                    "text": text.strip(),
                    "summary": meta.get("description") or "",
                    "authors": meta.get("authors") or [],
                    "published_at": meta.get("date") or None,
                }
        except Exception:
            pass
    # readability fallback
    if Document:
        try:
            doc = Document(html)
            title = doc.short_title() or ""
            content = doc.summary() or ""
            text = re.sub("<[^<]+?>", " ", content)
            return {"title": title, "text": text}
        except Exception:
            pass
    # last resort
    plain = re.sub(r"<[^>]+>", " ", html)
    return {"title": "", "text": plain[:2000]}

def _existing_hashes() -> set[str]:
    if not PARQUET_PATH.exists():
        return set()
    try:
        df = pl.read_parquet(str(PARQUET_PATH), columns=["url_hash"])
        return set(df["url_hash"].to_list())
    except Exception:
        return set()

def _append_rows(rows: List[Dict[str, Any]]) -> str:
    if not rows:
        return str(PARQUET_PATH)
    df_new = pl.DataFrame(rows)
    if PARQUET_PATH.exists():
        df_old = pl.read_parquet(str(PARQUET_PATH))
        df_all = pl.concat([df_old, df_new], how="vertical_relaxed")
        df_all = df_all.sort(["url_hash", "fetched_at"]).unique(keep="last", subset=["url_hash"])
        df_all.write_parquet(str(PARQUET_PATH))
    else:
        df_new.write_parquet(str(PARQUET_PATH))
    return str(PARQUET_PATH)

# ===================== core =====================
def ingest_url(url: str, tags: Optional[List[str]] = None, render_js: bool = False, timeout: int = 25) -> Dict[str, Any]:
    u = _norm_url(url)
    status, html, clen = _fetch(u, timeout=timeout, render_js=render_js)
    if status >= 400:
        raise RuntimeError(f"HTTP {status} for {u}")
    ext = _extract_text(html, u)
    title = ext.get("title") or ""
    text = ext.get("text") or ""
    summary = ext.get("summary") or ""
    authors = ext.get("authors") or []
    published_at = ext.get("published_at") or None
    lang = _safe_detect(text)

    row = {
        "url": u,
        "url_norm": u,
        "url_hash": _sha1(u),
        "source_domain": _domain(u),
        "title": title,
        "authors": json.dumps(authors),
        "published_at": published_at,
        "fetched_at": dt.datetime.utcnow().isoformat(),
        "summary": summary,
        "text": text,
        "lang": lang,
        "tags": json.dumps(tags or []),
        "via": "single",
        "http_status": status,
        "content_length": clen,
    }
    _append_rows([row])
    return {"title": title, "url": u, "lang": lang}

def crawl(seed: str, allowlist: List[str], max_pages: int, tags: Optional[List[str]] = None,
          delay: float = 0.0, render_js: bool = False, timeout: int = 25):
    """
    Crawl toàn bộ domain trong allowlist.
    - max_pages:
        > 0 : giới hạn theo số trang
        == 0: KHÔNG GIỚI HẠN (thực sự không cap)
        ==-1: KHÔNG GIỚI HẠN (tương đương 0)
    """
    from collections import deque
    visited, q = set(), deque([_norm_url(seed)])
    seen_hashes = _existing_hashes()
    added = 0
    unlimited = (max_pages <= 0)

    while q:
        # nếu có giới hạn dừng khi đạt ngưỡng
        if (not unlimited) and added >= max_pages:
            break

        u = q.popleft()
        if u in visited:
            continue
        visited.add(u)
        if not _allowed(u, allowlist):
            continue

        try:
            status, html, clen = _fetch(u, timeout=timeout, render_js=render_js)
        except Exception:
            continue
        if status >= 400:
            continue

        ext = _extract_text(html, u)
        text = ext.get("text") or ""
        url_hash = _sha1(u)
        if url_hash not in seen_hashes:
            row = {
                "url": u, "url_norm": u, "url_hash": url_hash, "source_domain": _domain(u),
                "title": ext.get("title") or "", "authors": json.dumps(ext.get("authors") or []),
                "published_at": ext.get("published_at") or None, "fetched_at": dt.datetime.utcnow().isoformat(),
                "summary": ext.get("summary") or "", "text": text, "lang": _safe_detect(text),
                "tags": json.dumps(tags or []), "via": "crawl", "http_status": status, "content_length": clen
            }
            _append_rows([row])
            seen_hashes.add(url_hash)
            added += 1

        # discover same-site links
        for href in re.findall(r'href=["\'](.*?)["\']', html):
            if href.startswith("#") or href.startswith("mailto:") or href.startswith("javascript:"):
                continue
            nxt = _norm_url(urljoin(u, href))
            if (nxt not in visited) and _allowed(nxt, allowlist):
                q.append(nxt)

        # bỏ delay nếu không muốn chờ
        if delay > 0:
            time.sleep(delay)

# ===================== CLI =====================
def main():
    p = argparse.ArgumentParser(description="Website MCP: ingest or crawl within allowlist")
    p.add_argument("--config", default="config/mcp.yaml", help="YAML config path (for allowlist)")
    p.add_argument("--timeout", type=int, default=25, help="HTTP timeout (seconds)")
    p.add_argument("--render-js", action="store_true", help="Render JS with Playwright (if installed)")
    sub = p.add_subparsers(dest="cmd", required=True)

    s1 = sub.add_parser("ingest", help="Ingest a single URL")
    s1.add_argument("--url", required=True)
    s1.add_argument("--tags", nargs="*", default=[])

    s2 = sub.add_parser("crawl", help="Crawl within allowlist")
    s2.add_argument("--seed", required=True)
    s2.add_argument("--max", type=int, default=120, help="Max pages; 0 or -1 = unlimited")
    s2.add_argument("--delay", type=float, default=0.0, help="Delay (seconds) between requests")
    s2.add_argument("--tags", nargs="*", default=[])

    args = p.parse_args()
    cfg = {}
    if os.path.exists(args.config):
        cfg = _load_yaml(args.config)
    allowlist = (cfg.get("website", {}) or {}).get("allow", []) or []

    if args.cmd == "ingest":
        if allowlist and not _allowed(args.url, allowlist):
            raise SystemExit(f"URL not in allowlist: {args.url}")
        out = ingest_url(args.url, tags=args.tags, render_js=args.render_js, timeout=args.timeout)
        print(json.dumps({"ok": True, "parquet": str(PARQUET_PATH), **out}, ensure_ascii=False))
    elif args.cmd == "crawl":
        if allowlist and not _allowed(args.seed, allowlist):
            raise SystemExit(f"Seed not in allowlist: {args.seed}")
        crawl(args.seed, allowlist=allowlist, max_pages=args.max, tags=args.tags,
              delay=args.delay, render_js=args.render_js, timeout=args.timeout)
        pages_note = "unlimited" if args.max <= 0 else f"≤{args.max}"
        print(json.dumps({"ok": True, "parquet": str(PARQUET_PATH), "pages_written": pages_note}, ensure_ascii=False))

if __name__ == "__main__":
    main()
