# app/agents/reports_agent.py
from typing import List, Dict
from app.llm import get_llm

SYS = (
"Bạn là Reports Agent. Từ báo cáo tháng, trích 3–5 số liệu/kết luận hỗ trợ tư vấn.\n"
"Ưu tiên KPI, MoM/YoY, hiệu suất quỹ, thời gian xử lý, phí.\n"
"Trả lời bullet ngắn, kèm citation [reports:title]."
)

def run(query: str, hits: List[Dict]) -> Dict:
    rr = [h for h in hits if h.get("source") == "reports"]
    if not rr:
        return {"report_numbers": ""}
    ctx = []
    for h in rr[:6]:
        tag = f'[reports:{(h.get("title") or h.get("file_path"))}]'
        ctx.append(f'{tag}\n{h.get("snippet","")}')
    llm = get_llm()
    msg = [
        {"role":"system","content":SYS},
        {"role":"user","content":f"Chủ đề: {query}\n\nBáo cáo:\n" + "\n\n---\n\n".join(ctx)}
    ]
    content = llm.invoke(msg).content
    return {"report_numbers": content}
