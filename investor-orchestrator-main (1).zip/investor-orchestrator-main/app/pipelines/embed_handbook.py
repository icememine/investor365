from __future__ import annotations
import os, re, faiss, polars as pl
from pathlib import Path
from sentence_transformers import SentenceTransformer   

CHUNKS_SRC = "data/local/handbook.parquet"        # parquet do adapter tạo (có cột text, chunk_id)
CHUNKS_OUT = "data/vector/handbook_chunks.parquet"
ID_MAP      = "data/vector/handbook_id_map.parquet"
INDEX       = "data/vector/faiss_handbook/index.faiss"
MODEL       = "intfloat/multilingual-e5-base"
PICKLE      = "data/vector/faiss_handbook/index.pkl"

def parse_chunk_idx(cid: str, fallback: int) -> int:
    # cid dạng "page-idx" -> quy chiếu ổn định theo trang
    m = re.match(r"^(\d+)-(\d+)$", str(cid or ""))
    if not m:
        return fallback
    page, idx = int(m.group(1)), int(m.group(2))
    return page * 1000 + idx  # đảm bảo tăng dần theo trang

def main():
    if not os.path.exists(CHUNKS_SRC):
        raise SystemExit(f"Not found: {CHUNKS_SRC}")

    src = pl.read_parquet(CHUNKS_SRC).with_columns(
        pl.col("text").fill_null("").cast(pl.Utf8),
        pl.col("chunk_id").fill_null("").cast(pl.Utf8),
    )
    if src.height == 0:
        raise SystemExit("No data in handbook parquet (text empty).")

    # Chuẩn hoá schema + chunk_idx đúng
    rows = []
    for i, r in enumerate(src.iter_rows(named=True)):
        cid = r.get("chunk_id") or str(i)
        cidx = parse_chunk_idx(cid, i)
        rows.append({
            "chunk_id": cid,
            "doc_id": "handbook",
            "source": "handbook",
            "title": "Dragon Capital Handbook",
            "file_path": "data/local/handbook.pdf",
            "chunk_idx": cidx,
            "text": r.get("text") or ""
        })
    df = pl.DataFrame(rows)

    # Ghi chunks chuẩn hoá
    Path(CHUNKS_OUT).parent.mkdir(parents=True, exist_ok=True)
    df.write_parquet(CHUNKS_OUT)

    # Embed
    enc = SentenceTransformer(MODEL)
    vecs = enc.encode(
        ["passage: " + t for t in df["text"].to_list()],
        batch_size=32, show_progress_bar=True, normalize_embeddings=True
    ).astype("float32")

    ix = faiss.IndexFlatIP(vecs.shape[1])
    ix.add(vecs)
    Path(INDEX).parent.mkdir(parents=True, exist_ok=True)
    faiss.write_index(ix, INDEX)

    # id_map
    df.select(["chunk_id","doc_id","source","title","file_path","chunk_idx"]).write_parquet(ID_MAP)
    print(f"[OK] vectors={vecs.shape[0]} -> {INDEX}")
    print(f"[OK] id_map -> {ID_MAP}")
    print(f"[OK] chunks -> {CHUNKS_OUT}")

if __name__ == "__main__":
    main()
