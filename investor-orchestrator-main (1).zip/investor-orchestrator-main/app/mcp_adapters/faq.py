# app/mcp_adapters/faq.py
from __future__ import annotations
import os, sys, json, unicodedata, argparse
from pathlib import Path
from typing import Dict, List, Tuple
import pandas as pd

# ===================== helpers =====================

def _fold(s: str) -> str:
    """
    Chuẩn hoá tên cột: bỏ dấu, lower, gộp khoảng trắng -> underscore.
    Dùng để dò cột Q/A tiếng Việt (có/không dấu).
    """
    s = str(s or "").strip()
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode("ascii")
    s = s.lower().strip()
    s = "_".join(s.split())
    return s

def _read_tabular_auto(path: str):
    """
    Đọc đa định dạng: .xlsx/.xlsm/.xls/.xlsb/.csv/.parquet
    Trả về dict[sheet_name] -> pandas.DataFrame
    """
    p = Path(path)
    ext = p.suffix.lower()

    if ext in (".xlsx", ".xlsm"):
        return pd.read_excel(p, sheet_name=None, engine="openpyxl")
    if ext == ".xls":
        return pd.read_excel(p, sheet_name=None, engine="xlrd")
    if ext == ".xlsb":
        return pd.read_excel(p, sheet_name=None, engine="pyxlsb")
    if ext == ".csv":
        return {"Sheet1": pd.read_csv(p)}
    if ext == ".parquet":
        return {"Sheet1": pd.read_parquet(p)}
    raise ValueError(f"Unsupported file extension: {ext}")

# Những biến thể tên cột hay gặp
QUESTION_KEYS = {
    "question", "q",
    "cau_hoi", "cau_hoi?", "cauhoi", "cau__hoi",
    "tu_van_san_pham", "tu_van", "tu_van_sp", "tu_van_sanpham",
    "tuvan_san_pham", "tuvan", "tuvan_sp",
    # fallback phổ biến
    "cau_ho_",
}
ANSWER_KEYS = {
    "answer", "answers", "a",
    "tra_loi", "traloi", "cau_tra_loi", "cau_tra_loi?",
    "cau_tra_loi_", "tra_loi_", "tra__loi"
}

def _pick_cols(df: pd.DataFrame) -> Tuple[str | None, str | None]:
    """
    Chọn cột question/answer theo mapping đã chuẩn hoá (_fold).
    Sẽ cố gắng bắt các biến thể tiếng Việt có dấu.
    """
    folded_to_raw = {_fold(c): c for c in df.columns}

    qcol = next((folded_to_raw[k] for k in folded_to_raw if k in QUESTION_KEYS), None)
    acol = next((folded_to_raw[k] for k in folded_to_raw if k in ANSWER_KEYS), None)

    # Fallback thêm theo pattern
    if not qcol:
        for raw in df.columns:
            f = _fold(raw)
            if f.startswith("cau_hoi") or f == "tu_van_san_pham":
                qcol = raw; break
    if not acol:
        for raw in df.columns:
            f = _fold(raw)
            if f.startswith("cau_tra_loi") or f.startswith("tra_loi") or f == "answers":
                acol = raw; break

    return qcol, acol

# ===================== core build =====================

def build_faq(input_path: str) -> List[Dict[str, str]]:
    """
    Parse toàn bộ sheet -> list[{question, answer, sheet}]
    - An toàn với tên cột có dấu/khoảng trắng: rename 2 cột về 'q'/'a' trước khi iterate
    - Loại dòng trống/NA và dedup
    """
    sheets = _read_tabular_auto(input_path)
    rows: List[Dict[str, str]] = []

    for sheet_name, df in sheets.items():
        if df is None or df.empty:
            continue

        qcol, acol = _pick_cols(df)
        if not qcol or not acol:
            # skip sheet không xác định được cột
            continue

        # Chỉ giữ 2 cột cần thiết và đổi tên an toàn
        df2 = df[[qcol, acol]].dropna(how="any").copy()
        df2.columns = ["q", "a"]  # tránh lỗi itertuples với tên cột unicode/space

        # Chuẩn hoá chuỗi
        df2["q"] = df2["q"].astype(str).str.strip()
        df2["a"] = df2["a"].astype(str).str.strip()
        df2 = df2[(df2["q"] != "") & (df2["a"] != "")]

        # Iterate an toàn (name=None -> tuple)
        for q, a in df2[["q", "a"]].itertuples(index=False, name=None):
            rows.append({"question": q, "answer": a, "sheet": str(sheet_name)})

    # Dedup
    if rows:
        rows = (
            pd.DataFrame(rows)
            .drop_duplicates(subset=["question", "answer"])
            .to_dict(orient="records")
        )
    return rows

def write_parquet(rows: List[Dict[str, str]], out_path: str) -> str:
    import polars as pl
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    pl.DataFrame(rows).write_parquet(out_path)
    return out_path

# ===================== CLI =====================

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Build FAQ dataset from Excel/CSV/Parquet")
    parser.add_argument("--path", required=True, help="Input file (e.g., data/external/faq/faq.xlsx)")
    parser.add_argument("--out", default="data/external/faq/faq.parquet", help="Output parquet path")
    args = parser.parse_args()

    if not os.path.exists(args.path):
        print(f"[ERR] Not found: {args.path}", file=sys.stderr)
        sys.exit(1)

    rows = build_faq(args.path)
    print(f"[OK] Parsed rows: {len(rows)}")
    if rows:
        outp = write_parquet(rows, args.out)
        print(f"[OK] Wrote: {outp}")
    else:
        print("[WARN] No rows parsed — check your columns (question/answer).")
