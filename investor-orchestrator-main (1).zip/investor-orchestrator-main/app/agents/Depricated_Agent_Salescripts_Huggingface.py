from huggingface_hub import AsyncInferenceClient
from pydantic_ai import Agent
from pydantic_ai.models.huggingface import HuggingFaceModel
from pydantic_ai.providers.huggingface import HuggingFaceProvider
import os
from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import CharacterTextSplitter
from dotenv import load_dotenv
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS
import numpy as np
import faiss
from langchain_community.embeddings import SentenceTransformerEmbeddings
from dataclasses import dataclass
from pydantic_ai import RunContext
load_dotenv()

@dataclass
class Deps:
    vector_store: FAISS

# Define the model with the HuggingFace API key:
HF_TOKEN = os.getenv("HUGGINGFACEHUB_API_TOKEN")
model_name = 'Qwen/Qwen3-Next-80B-A3B-Instruct'
model = HuggingFaceModel(model_name, provider=HuggingFaceProvider(api_key=HF_TOKEN))

# Define system prompt for the agent
SYSTEM_PROMPT = (
"""
Bạn là một Sale Manager tại Dragon Capital Việt Nam với 20 năm kinh nghiệm trong quản lý quỹ.
Bạn am hiểu:
Tâm lý & hành vi NĐT cá nhân: mới tham gia, đang lãi, đang lỗ, chuẩn bị bán, hoặc muốn mua thêm. </System>
<Context> Bạn đang hỗ trợ một người dùng (tức nhân viên AMDD/PO Marketing) trong việc: 
- Chăm sóc KH mới tham gia quỹ (giải thích đơn giản, tạo niềm tin, khuyến khích giữ quỹ lâu dài). 
- Tư vấn theo tình huống giao dịch: khi KH mua, khi bán, khi đang lãi, khi đang lỗ. 
- Đưa ra nội dung cá nhân hóa để gửi qua app push, Zalo ZNS, email hoặc tư vấn trực tiếp. 
- Kết hợp marketing & tư vấn đầu tư: thông điệp phải vừa đúng về mặt tài chính, vừa gần gũi, dễ hiểu.
Phản hồi theo tình huống:
KH mới: giải thích lợi thế quỹ, nhấn mạnh kỷ luật đầu tư, gợi ý DCA/iSaving.
KH lãi: khen ngợi sự kiên trì, khuyến khích giữ lâu dài để tối ưu lợi nhuận kép.
KH lỗ: an ủi, đưa dẫn chứng về quỹ vượt trội trong trung dài hạn, gợi ý giữ hoặc gia tăng tích lũy.
KH bán: nhấn mạnh tầm nhìn dài hạn, đưa dữ liệu so sánh nếu giữ thêm 1–2 năm.
KH mua thêm: khuyến khích gia tăng đầu tư định kỳ, dùng cơ hội điều chỉnh thị trường.
Trình bày kết quả:
Tóm tắt NAV & hiệu suất: bảng dữ liệu mới nhất.
Tình huống KH: phân tích riêng cho tình huống đó.
Thông điệp gợi ý: mẫu push/email ngắn gọn, cá nhân hóa theo KH.
Chiến lược khuyến nghị: giữ, mua thêm, hoặc phân bổ sang quỹ khác (nếu phù hợp).
Nguyên tắc bắt buộc:
Không giả định.
Nội dung phải đơn giản, dễ hiểu, truyền cảm hứng với KH cá nhân.
Luôn đưa ra thông điệp song song: (1) tài chính chính xác, (2) marketing thân thiện.
</Instructions> 
<Output Format> 
1. Phân tích tình huống KH: Lãi, lỗ, mới, bán, mua thêm. 
2. Thông điệp Gợi ý: Push/Email cá nhân hóa (ngắn gọn). 
3. Khuyến nghị Đầu tư: Chiến lược hành động (giữ, mua thêm, DCA…).
</Output Format>

Công cụ: dùng Retrieve để lấy thông tin từ Sales Scripts và tư vấn dựa trên Sales Scripts
"""
)

salescripts_agent = Agent(
    model, 
    deps_type=Deps,
    system_prompt=SYSTEM_PROMPT
)

# Define the vectorstore tools:
@salescripts_agent.tool
async def retrieve(context: RunContext[Deps], search_query: str) -> str:
    """Retrieve sale scripts
    Args:
        context: The call context
        search_query: The search query
    """
    INDEX_DIR = "./data/vector/faiss_Sale_script_docling"
    MODEL_NAME = "intfloat/multilingual-e5-base"
    embeddings_model = SentenceTransformerEmbeddings(model_name=MODEL_NAME)
    loaded_vector_store = context.deps.vector_store.load_local(INDEX_DIR, embeddings_model, allow_dangerous_deserialization=True)
    k = 3
    similar_docs = loaded_vector_store.similarity_search(search_query, k=k)
    return "\n\n".join(
        f"# Documents:\n{doc.page_content}"
        for i, doc in enumerate(similar_docs))

# Load the vector store
INDEX_DIR = "./data/vector/faiss_Sale_script_docling"
MODEL_NAME = "intfloat/multilingual-e5-base"
embeddings_model = SentenceTransformerEmbeddings(model_name=MODEL_NAME)
vector_store = FAISS.load_local(INDEX_DIR, embeddings_model, allow_dangerous_deserialization=True)

# The main function to run the agent:
async def run_agent(question: str):
    deps = Deps(
        vector_store=vector_store,
    )
    answer = await salescripts_agent.run(question, deps=deps)
    return answer

import asyncio

async def main():
    query = "Thuyết phục Nhà đầu tư đa dạng hóa danh mục sang DCDS. NĐT nam, mới tham gia quỹ 3 tuần, hiện đầu tư DCIP 100 triệu "
    output = await run_agent(query)
    print(output.output)

if __name__ == "__main__":
    asyncio.run(main())
