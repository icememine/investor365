from langgraph.graph import StateGraph, END

def build_graph():
    sg = StateGraph(dict)

    # stub nodes
    sg.add_node("intent_router", lambda s: {**s, "intent": "STUB"})
    sg.add_node("entity_extractor", lambda s: {**s, "entities": {"fund": "DCDS"}})
    sg.add_node("task_decomposer", lambda s: {**s, "plan": {"subtasks": ["RAG","Write"]}})
    sg.add_node("retriever", lambda s: {**s, "facts": ["stub fact"]})
    sg.add_node("writer", lambda s: {**s, "outputs": {"qna": "stub answer"}})

    # edges
    sg.set_entry_point("intent_router")
    sg.add_edge("intent_router", "entity_extractor")
    sg.add_edge("entity_extractor", "task_decomposer")
    sg.add_edge("task_decomposer", "retriever")
    sg.add_edge("retriever", "writer")
    sg.add_edge("writer", END)

    return sg.compile()
