# app/pipelines/download_reports_from_page.py
from __future__ import annotations
import os, re, argparse, time
from pathlib import Path
from urllib.parse import urljoin, urldefrag

import httpx

# optional playwright render (JS-heavy pages)
PLAYWRIGHT = False
try:
    from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout
    PLAYWRIGHT = True
except Exception:
    PLAYWRIGHT = False

UA = ("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36")

def fetch_html_with_playwright(url: str, timeout: int) -> str:
    if not PLAYWRIGHT:
        raise RuntimeError("Playwright not available")
    to_ms = timeout * 1000
    with sync_playwright() as p:
        browser = p.chromium.launch()  # headless by default
        page = browser.new_page(user_agent=UA)
        try:
            # Bước 1: vào trang, chờ 'load'
            page.goto(url, timeout=to_ms, wait_until="load")
            # Bước 2: thử 'networkidle' (nếu thất bại -> bỏ qua, dùng content hiện tại)
            try:
                page.wait_for_load_state("networkidle", timeout=to_ms // 2)
            except PWTimeout:
                pass
            # Cuộn nhẹ để kích hoạt lazy load (nếu có)
            try:
                page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
                page.wait_for_timeout(300)
            except Exception:
                pass
            html = page.content()
            return html
        finally:
            browser.close()

def fetch_html(url: str, timeout: int = 45, render_js: bool = False) -> str:
    # render_js=True -> thử Playwright trước, lỗi thì fallback httpx
    if render_js:
        try:
            return fetch_html_with_playwright(url, timeout=timeout)
        except Exception as e:
            print(f"[WARN] Playwright failed ({e}). Falling back to httpx.")
    with httpx.Client(timeout=timeout, headers={"User-Agent": UA}) as c:
        r = c.get(url, follow_redirects=True)
        r.raise_for_status()
        return r.text

def find_pdf_links(html: str, base: str) -> list[str]:
    hrefs = re.findall(r'href=["\'](.*?)["\']', html, flags=re.I)
    urls = []
    for h in hrefs:
        if not h or h.startswith("#") or h.startswith("mailto:") or h.startswith("javascript:"):
            continue
        u = urljoin(base, h)
        u, _frag = urldefrag(u)
        if u.lower().endswith(".pdf"):
            urls.append(u)
    # dedup giữ thứ tự
    seen, out = set(), []
    for u in urls:
        if u not in seen:
            seen.add(u); out.append(u)
    return out

def sanitize_name(u: str) -> str:
    name = u.split("/")[-1] or "report.pdf"
    name = re.sub(r"[^A-Za-z0-9._\- ]+", "_", name)
    return name or "report.pdf"

def download_file(url: str, outdir: Path, timeout: int = 60) -> str:
    outdir.mkdir(parents=True, exist_ok=True)
    fname = sanitize_name(url)
    path = outdir / fname
    with httpx.stream("GET", url, timeout=timeout, headers={"User-Agent": UA}, follow_redirects=True) as r:
        r.raise_for_status()
        with open(path, "wb") as f:
            for chunk in r.iter_bytes():
                f.write(chunk)
    return str(path)

def main():
    ap = argparse.ArgumentParser(description="Download all PDF links from a page")
    ap.add_argument("--url", required=True)
    ap.add_argument("--outdir", default="data/external/reports")
    ap.add_argument("--timeout", type=int, default=60)
    ap.add_argument("--render-js", action="store_true", help="Try Playwright first, then fallback to httpx")
    args = ap.parse_args()

    html = fetch_html(args.url, timeout=args.timeout, render_js=args.render_js)
    pdfs = find_pdf_links(html, args.url)
    if not pdfs:
        print("[WARN] No PDF links found on page.")
        return
    print(f"[INFO] Found {len(pdfs)} PDFs")

    saved = []
    for i, u in enumerate(pdfs, 1):
        try:
            p = download_file(u, Path(args.outdir), timeout=args.timeout)
            saved.append(p)
            print(f"[{i}/{len(pdfs)}] OK {p}")
            time.sleep(0.1)  # gentle
        except Exception as e:
            print(f"[ERR] {u}: {e}")
    print(f"[DONE] Saved {len(saved)} files to {args.outdir}")

if __name__ == "__main__":
    main()
