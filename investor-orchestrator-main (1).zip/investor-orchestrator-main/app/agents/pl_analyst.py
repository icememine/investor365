# app/agents/pl_analyst.py
import os
from typing import Dict, List
import polars as pl

PL_PATH = os.environ.get("PL_PARQUET_PATH", "data/parquet/pl.parquet")

# Lọc rất nhẹ dựa vào vài field văn bản để minh họa demo
TEXT_FIELDS = ["Full Name","Partners","channel","Current Portfolio","Total Port PL % range"]

def run(query: str) -> Dict:
    if not os.path.exists(PL_PATH):
        return {"pl_findings": ""}
    try:
        df = pl.read_parquet(PL_PATH)
    except Exception:
        return {"pl_findings": ""}

    fields = [c for c in TEXT_FIELDS if c in df.columns]
    if not fields:
        return {"pl_findings": ""}

    q = query.lower().split()
    def match(row: dict) -> bool:
        hay = " ".join(str(row.get(f,"")) for f in fields).lower()
        return all(w in hay for w in q if len(w) > 2)

    rows: List[dict] = []
    for r in df.iter_rows(named=True):
        if match(r):
            rows.append(r)
        if len(rows) >= 5:
            break

    if not rows:
        return {"pl_findings": ""}

    headers_pref = ["Full Name","Current Portfolio","current_aum","Total Port PL %","holding_class"]
    headers = [h for h in headers_pref if h in df.columns]
    lines = []
    for r in rows:
        vals = [str(r.get(h,"")) for h in headers]
        lines.append(" | ".join(vals))
    return {"pl_findings": "PL matches:\n" + "\n".join(lines)}