# app/pipelines/web_chunker.py
from __future__ import annotations
import os, hashlib
import polars as pl
from pathlib import Path

ARTICLES = "data/external/web/articles.parquet"
OUT = "data/vector/web_chunks.parquet"

CHUNK_SIZE = 1000
OVERLAP = 120
MIN_BODY_LEN = 50   # hạ ngưỡng để không bỏ sót text ngắn

def sha1(s: str) -> str:
    return hashlib.sha1(s.encode()).hexdigest()

def chunks(t: str, size=CHUNK_SIZE, overlap=OVERLAP):
    t = (t or "").strip()
    if not t:
        return []
    if len(t) <= size:
        return [t]
    out, i = [], 0
    while i < len(t):
        out.append(t[i:i+size])
        if i + size >= len(t):
            break
        i += size - overlap
    return out

def main():
    if not os.path.exists(ARTICLES):
        raise SystemExit(f"Not found: {ARTICLES}")

    df = pl.read_parquet(ARTICLES).with_columns([
        pl.col("text").fill_null("").cast(pl.Utf8),
        pl.col("summary").fill_null("").cast(pl.Utf8),
        pl.col("title").fill_null("").cast(pl.Utf8),
    ])

    # Ưu tiên text → summary → title
    df = df.with_columns(
        pl.when(pl.col("text").str.len_chars() > 0).then(pl.col("text"))
          .when(pl.col("summary").str.len_chars() > 0).then(pl.col("summary"))
          .otherwise(pl.col("title")).alias("body")
    ).filter(pl.col("body").str.len_chars() >= MIN_BODY_LEN)

    if df.is_empty():
        raise SystemExit("No chunks produced. Body field empty/too short. Try crawl news pages or lower MIN_BODY_LEN.")

    rows = []
    for r in df.iter_rows(named=True):
        url = r["url"]
        doc = sha1(url)
        for idx, ch in enumerate(chunks(r["body"])):
            rows.append({
                "chunk_id": f"{doc}:{idx}",
                "doc_id": doc,
                "source": "web",
                "title": r.get("title") or "",
                "url": url,
                "source_domain": r.get("source_domain") or "",
                "published_at": r.get("published_at"),
                "fetched_at": r.get("fetched_at"),
                "tags": r.get("tags") or "[]",
                "via": r.get("via") or "single",
                "chunk_idx": idx,
                "text": ch,
            })

    Path(OUT).parent.mkdir(parents=True, exist_ok=True)
    pl.DataFrame(rows).write_parquet(OUT)
    print(f"[OK] chunks={len(rows)} -> {OUT}")

if __name__ == "__main__":
    main()
