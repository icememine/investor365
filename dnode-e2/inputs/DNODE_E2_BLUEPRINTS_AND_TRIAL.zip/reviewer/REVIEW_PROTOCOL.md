# Reviewer protocol — keep separate from the first candidate response

Send only candidate.zip to Claude initially. Do not send ASTRA_TRIAL.md until Claude's first response is preserved. Give the same candidate package to every participant. The public questions are visible to all; this packet does not contain a secret independent holdout.

Suggested instruction:

> Read START_HERE.md in candidate.zip. Complete Phase A for BP-SHOP, BP-GAME and BP-BATCH, using the common response template. Do not build applications yet. Preserve inherited requirements and exercise delegated design freedom with explicit reasons. Answer all challenge and continuation IDs. State gaps rather than inventing unsupported facts. Return three submissions and concise successor handoffs. No prior conversation is needed.

Prefer separate fresh sessions per application when measuring transfer. If one session handles all three, record that condition. Astra's included trial is author-exposed and non-blind; disclose that in any comparison.

## Review dimensions

For each response mark pass / fail / unresolved with a quote and explanation:

1. Purpose: beneficiary, use context and useful outcome are preserved.
2. Authority: inherited choices distinguished from human requirements; assumptions remain labeled.
3. Semantics: all four behavioral fields are concrete and consistent.
4. Freedom: at least two useful choices with reasons, tradeoffs, validation and variation policy.
5. Preservation: continuation does not silently break identity, stock, timing, ownership or snapshot meaning.
6. Evidence honesty: predictions, executed checks and human acceptance distinguished.
7. Handoff: successor can locate settled choices, dependencies, freedoms and open questions.

Review every mandatory S/G/B acceptance ID for a responsibility and evidence status. Missing mapping is unresolved, not a pass. Do not rank by prose length or node count. A critical semantic failure blocks the affected app's interpretation result even if other dimensions are strong.

## Expected distinctions

- Shop: stock example gives 3/1/2; same key changed intent conflicts; second deliberate purchase gets a new key; lost reply retains identity/reservation; atomicity needs a real state boundary; typed node rejects numeric text before pre.
- Game: different catch-up caps can differ; E2 pins five/60Hz; pause discards elapsed pause time; collision tie policy is a declared choice; oracle agreement does not prove enjoyment; renderer cannot alter state.
- Batch: leading zeros accepted; whitespace/out-of-range rejected with located diagnostics; duplicates reject all; quoted newline does not increment logical record count; old output is preserved and labeled old; partial acceptance needs an explicit new meaning contract.

A fluent restatement is insufficient. Check whether the chosen decisions and continuation actually preserve these relationships. Challenge any unspecified boundary with a concrete counterexample, then preserve both original and repaired responses.

## Next phase

After comparing Phase A, select one implementation task and issue the same bounded change against the same kit. Collect exact source, dependency identities, first failures, repair log, checker output, launch instructions and human observations. Public tests plus self-written tests do not establish independent conformance. Commission fresh cases from a reviewer who did not author the implementation before making broader claims.

The current package validates no mental-state claim about a model. It can reveal behavioral agreement, misunderstanding, specification gaps and whether recorded reasons support continuation.
