# app/mcp_adapters/pl_investor.py
from __future__ import annotations
import os, re, math, json, pathlib
from typing import List, Optional
import pandas as pd
import numpy as np
import yaml

# ========= Config paths =========
CFG_MCP = os.getenv("MCP_CONFIG", "config/mcp_config.yaml")
CFG_DERIVE = os.getenv("DERIVATIONS", "config/derivations.yaml")
PARQUET_DEFAULT = "data/local/pl.parquet"

# ========= Helpers: parsing / normalize =========
PCT_COLS   = ["pnl_pct", "equity_pl_pct", "bond_pl_pct"]
FUND_COLS  = ["aum_DCDS","aum_DCDE","aum_DCBF","aum_DCIP"]
AUM_COLS   = ["current_aum", "aum_equity", "aum_bond"] + FUND_COLS + ["pnl_abs"]
ID_COL     = "investor_id"

def _safe_load_yaml(path: str, fallback: dict | None = None) -> dict:
    fallback = fallback or {}
    try:
        if os.path.exists(path):
            with open(path, "r") as f:
                data = yaml.safe_load(f)
                return data if isinstance(data, dict) else fallback
    except Exception:
        pass
    return fallback

def _to_float(x):
    if x is None or (isinstance(x, float) and math.isnan(x)): return None
    if isinstance(x, (int, float, np.integer, np.floating)): return float(x)
    s = str(x).strip()
    if s == "" or s.lower() in ["n/a","na","none","null","-"]: return None
    # VN numbers: "." thousands, "," decimal
    s = s.replace(" ", "").replace(".", "").replace(",", ".")
    s = re.sub(r"[^0-9\.\-]", "", s)
    try:
        return float(s) if s not in ["", "-", ".", "-."] else None
    except Exception:
        return None

def _pct(x):
    if x is None or (isinstance(x, float) and math.isnan(x)): return None
    s = str(x).strip().lower()
    if s in ["","n/a","na","none","null","-"]: return None
    if "%" in s:
        v = _to_float(s.replace("%",""))
        return None if v is None else v/100.0
    return _to_float(s)

def _scale(series: pd.Series) -> pd.Series:
    if series is None or len(series) == 0:
        return pd.Series([], dtype=float)
    s = pd.to_numeric(series, errors="coerce")
    lo, hi = s.min(), s.max()
    if pd.isna(lo) or pd.isna(hi) or hi == lo:
        return pd.Series([0.5]*len(s), index=s.index)
    return (s - lo) / (hi - lo)

def _share(num, den):
    try:
        num = float(num) if num is not None else 0.0
        den = float(den) if den is not None and den != 0 else None
        return num / den if den else None
    except Exception:
        return None

# ========= Helper: read Excel/CSV/TSV safely =========
def _read_tabular(path: str) -> pd.DataFrame:
    p = pathlib.Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Not found: {path}")
    ext = p.suffix.lower()
    if ext == ".xlsx":
        try:
            return pd.read_excel(path, engine="openpyxl")
        except Exception as e:
            raise RuntimeError(f"Không đọc được .xlsx (có thể file không chuẩn): {e}")
    elif ext == ".xls":
        try:
            return pd.read_excel(path)
        except Exception as e:
            raise RuntimeError("File .xls cũ — vui lòng Save As .xlsx hoặc .csv. " + str(e))
    elif ext == ".csv":
        return pd.read_csv(path)
    elif ext in [".tsv",".txt"]:
        return pd.read_csv(path, sep="\t")
    else:
        try:
            return pd.read_excel(path)
        except Exception:
            try:
                return pd.read_csv(path)
            except Exception as e:
                raise RuntimeError(f"Không nhận diện được định dạng {path}. Lỗi: {e}")

# ========= Age logic (Age>89 or blank => missing; 5-year band; YAML override) =========
AGE_BINS_DEFAULT = list(range(0, 90, 5))  # 0..85; 90 là biên phải (không gán)
def _age_bins_from_cfg() -> list[int] | None:
    cfg = _safe_load_yaml(CFG_DERIVE, {})
    bins = (cfg.get("age_bins") or {}).get("edges")
    if isinstance(bins, list) and all(isinstance(x, int) for x in bins) and len(bins) >= 2:
        return bins
    return None

def _age_label_from_edges(age: int, edges: list[int]) -> str | None:
    for i in range(len(edges)-1):
        lo, hi = edges[i], edges[i+1]
        if age >= lo and age < hi:
            return f"{lo}-{hi-1}"
    return None

def _parse_age(x) -> int | None:
    """Return age or None. Rule: blank/n-a => None; age <=0 or >89 => None (no guessing)."""
    if x is None or (isinstance(x,float) and math.isnan(x)): return None
    s = str(x).strip()
    if s=="" or s.lower() in ["n/a","na","none","null","-"]: return None
    m = re.search(r"(\d{1,3})", s)
    if not m: return None
    age = int(m.group(1))
    if age<=0 or age>89: return None
    return age

def _derive_age_columns(df: pd.DataFrame) -> pd.DataFrame:
    # 1) age_year
    age_year = None
    for c in ["Age","age","Tuổi","tuoi","age_year"]:
        if c in df.columns:
            age_year = df[c].map(_parse_age)
            break
    if age_year is None:
        if "age_band" in df.columns:
            age_year = df["age_band"].map(_parse_age)
        else:
            age_year = pd.Series([None]*len(df))
    df["age_year"] = age_year
    # 2) age_band theo bins (YAML override -> default 5-year)
    edges = _age_bins_from_cfg() or AGE_BINS_DEFAULT + [90]
    df["age_band"] = df["age_year"].map(lambda v: _age_label_from_edges(int(v), edges) if v is not None and not pd.isna(v) else None)
    return df

# ========= Gender logic (FemaleeMaleale => F; n/a/blank => None) =========
def _gender_norm(g):
    if g is None or (isinstance(g,float) and math.isnan(g)): return None
    s = str(g).strip().lower()
    if s in ["","n/a","na","none","null","-"]: return None
    if s == "femaleemaleale": return "F"
    if "female" in s or s in ["f","nu","nữ"]: return "F"
    if "male" in s or s in ["m","nam"]: return "M"
    return None

# ========= Channel mapping (from derivations.yaml) =========
DEFAULT_DERIVE = {
    "channel_mapping": {
        "DCVFM": ["dcvfm","dragonx","direct"],
        "Digital": ["digital","da digital"],
        "Partnership Distribution": ["bank","pd","partnership"]
    },
    "defaults": {"channel_group": "DCVFM"}
}
def _derive_channel_group(df: pd.DataFrame) -> pd.DataFrame:
    cfg = _safe_load_yaml(CFG_DERIVE, DEFAULT_DERIVE)
    mapping = cfg.get("channel_mapping", {})
    default_channel = cfg.get("defaults", {}).get("channel_group","DCVFM")
    def norm(x): return str(x).strip().lower() if x is not None else ""
    def to_group(row):
        keys=[norm(row.get("Partner")),norm(row.get("Sale Code")),norm(row.get("sale_code")),norm(row.get("partner")),norm(row.get("channel"))]
        token_str=" ".join([k for k in keys if k])
        for group,tokens in mapping.items():
            for t in tokens:
                if t in token_str: return group
        return default_channel
    df["channel_group"]=df.apply(to_group,axis=1)
    if "partner" not in df.columns and "Partner" in df.columns:
        df = df.rename(columns={"Partner":"partner"})
    df["partner_clean"]=df.get("partner").astype(str).str.strip() if "partner" in df else None
    return df

# ========= Equity/Bond + current AUM + shares =========
def _derive_equity_bond(df: pd.DataFrame) -> pd.DataFrame:
    dcds,dcde, dcbf,dcip = df.get("aum_DCDS"),df.get("aum_DCDE"),df.get("aum_DCBF"),df.get("aum_DCIP")
    df["aum_equity"]=(dcds.fillna(0) if dcds is not None else 0)+(dcde.fillna(0) if dcde is not None else 0)
    df["aum_bond"]  =(dcbf.fillna(0) if dcbf is not None else 0)+(dcip.fillna(0) if dcip is not None else 0)
    if "current_aum" not in df.columns:
        has_funds=[c for c in FUND_COLS if c in df.columns]
        if has_funds:
            df["current_aum"]=df[has_funds].sum(axis=1)
        else:
            df["current_aum"]=df["aum_equity"]+df["aum_bond"]
    with np.errstate(divide='ignore', invalid='ignore'):
        df["equity_share"]=(df["aum_equity"]/df["current_aum"]).replace([np.inf,-np.inf],np.nan)
        df["bond_share"]  =(df["aum_bond"]/df["current_aum"]).replace([np.inf,-np.inf],np.nan)
    return df

# ========= Holding, tiers, risk, pnl, diversification, salutation, persona =========
def _derive_holding_class(df: pd.DataFrame) -> pd.DataFrame:
    cands=[c for c in df.columns if re.search(r"max\s*holding|holding\s*day", c, re.I)]
    col=cands[0] if cands else None
    if col:
        days = pd.to_numeric(df[col].map(_to_float), errors="coerce")
    else:
        days = pd.Series([np.nan]*len(df))
    df["holding_days"]=days
    df["holding_class"]=pd.cut(df["holding_days"].fillna(-1),
                               bins=[-1,90,365,10_000],
                               labels=["Short-term","Medium-term","Long-term"])
    return df

def _derive_aum_tier(df: pd.DataFrame) -> pd.DataFrame:
    df["aum_tier"]=pd.cut(pd.to_numeric(df["current_aum"], errors="coerce").fillna(-1),
                          bins=[-1,1e8,1e9,1e13],
                          labels=["Small","Medium","Large"])
    return df

def _derive_risk_appetite(df: pd.DataFrame) -> pd.DataFrame:
    share=pd.to_numeric(df.get("equity_share"), errors="coerce")
    df["risk_appetite"]=pd.cut(share.fillna(-1),
                               bins=[-1,0.3,0.7,1.01],
                               labels=["Conservative","Balanced","Aggressive"])
    pnl_scaled=_scale(pd.to_numeric(df.get("pnl_pct"), errors="coerce")) if "pnl_pct" in df else 0.5
    share_scaled=_scale(share)
    df["risk_score"]=0.75*share_scaled + 0.25*(pnl_scaled if isinstance(pnl_scaled, pd.Series) else 0.5)
    return df

def _derive_pnl_band(df: pd.DataFrame) -> pd.DataFrame:
    # Nếu không có cột pnl_pct thì gán None cho toàn bộ và thoát
    if "pnl_pct" not in df.columns:
        df["pnl_band"] = pd.Series([None] * len(df))
        return df

    # Ép kiểu an toàn về Series
    s = pd.to_numeric(df["pnl_pct"], errors="coerce")
    df["pnl_band"] = pd.cut(
        s.fillna(-9_999),
        bins=[-9_999, -0.10, -0.02, 0.05, 9_999],
        labels=["loss_deep", "loss_mild", "flat", "gain"]
    )
    return df


def _hhi_shares(row: pd.Series, fund_cols: List[str]) -> Optional[float]:
    total=row.get("current_aum")
    if total is None or pd.isna(total) or total==0: return None
    s=0.0
    for c in fund_cols:
        v=row.get(c)
        if v is None or pd.isna(v): continue
        s+=(float(v)/float(total))**2
    return s

def _top_fund(row: pd.Series, fund_cols: List[str]) -> Optional[str]:
    best,name=-1.0,None
    for c in fund_cols:
        v=row.get(c)
        if v is None or pd.isna(v): continue
        if v>best: best,name=v,c
    return name.replace("aum_","").upper() if name else None

def _derive_diversification(df: pd.DataFrame) -> pd.DataFrame:
    df["hhi_funds"]=df.apply(lambda r: _hhi_shares(r,[c for c in FUND_COLS if c in df.columns]),axis=1)
    df["top_fund"]=df.apply(lambda r: _top_fund(r,[c for c in FUND_COLS if c in df.columns]),axis=1)
    return df

def _derive_salutation(df: pd.DataFrame) -> pd.DataFrame:
    """Big company tone: M->Anh, F->Chị, None/other->Quý khách hàng"""
    def sal(g):
        if g=="M": return "Anh"
        if g=="F": return "Chị"
        return "Quý khách hàng"
    df["salutation_primary"]=df.get("gender").map(sal)
    df["salutation_alt"]=None
    return df

def _derive_persona(df: pd.DataFrame) -> pd.DataFrame:
    def name_pick(row):
        for c in ["Full Name","Customer Name","CustomerName","Name","name","full_name"]:
            if c in df.columns and pd.notna(row.get(c)): return str(row.get(c)).strip()
        return None
    df["name"]=df.apply(name_pick,axis=1)
    def persona(row):
        g=row.get("gender") or "NA"
        a=row.get("age_band") or "NA"
        r=row.get("risk_appetite") or "NA"
        p=row.get("pnl_band") or "NA"
        return f"{g}-{a}-{r}-{p}"
    df["persona"]=df.apply(persona,axis=1)
    return df

# ========= Public: load & feature-engineer (PHẦN 1) =========
def load_pl(xlsx_path: str, parquet_out: str = PARQUET_DEFAULT) -> dict:
    """
    Đọc PL (.xlsx/.xls/.csv/.tsv), chuẩn hoá, FE lõi, lưu parquet (chưa tone profile).
    """
    if not os.path.exists(xlsx_path):
        return {"ok": False, "error": f"Not found: {xlsx_path}"}

    # 1) read
    df = _read_tabular(xlsx_path)

    # 2) rename flexible
    col_map = {
        # ID + Demographic + Partner/Channel + Name
        "InvestorID": "investor_id", "Investor Id": "investor_id", "Investor ID": "investor_id",
        "gender": "gender", "Gender": "gender",
        "Age Group": "age_band", "Age": "Age",
        "Partner": "partner", "Sale Code": "sale_code", "Channel": "channel",
        "Full Name": "Full Name", "Customer Name": "Customer Name", "CustomerName": "CustomerName",
        "Name": "Name", "name": "name", "full_name": "full_name",
        # AUM tổng & theo asset/quỹ
        "Current AUM": "current_aum",
        "AUM Equity": "aum_equity", "AUM Euity": "aum_equity", "AUM Bond": "aum_bond",
        "AUM DCDS": "aum_DCDS", "AUM DCDE": "aum_DCDE", "AUM DCBF": "aum_DCBF", "AUM DCIP": "aum_DCIP",
        # Lãi lỗ
        "Total P/L": "pnl_abs", "Total Port P/L": "pnl_pct",
        "Equity PL %": "equity_pl_pct", "Bond PL %": "bond_pl_pct",
        # Holding
        "Max Holding": "Max Holding", "Max Holding Day": "Max Holding", "Holding Days": "Max Holding",
    }
    use_cols = {k:v for k,v in col_map.items() if k in df.columns}
    df = df.rename(columns=use_cols)

    # 3) normalize core
    if "gender" in df: df["gender"] = df["gender"].map(_gender_norm)      # may return None
    for c in PCT_COLS:
        if c in df: df[c] = df[c].map(_pct)
    for c in set(AUM_COLS + ["pnl_abs"]):
        if c in df: df[c] = df[c].map(_to_float)

    # 4) age columns (year + 5-year band or YAML override)
    df = _derive_age_columns(df)

    # 5) guard: investor_id
    if ID_COL not in df.columns:
        return {"ok": False, "error": f"Missing required column: {ID_COL}"}
    df = df[df[ID_COL].notna()].copy()

    # 6) feature engineering lõi
    df = _derive_equity_bond(df)
    df = _derive_channel_group(df)
    df = _derive_holding_class(df)
    df = _derive_aum_tier(df)
    df = _derive_risk_appetite(df)
    df = _derive_pnl_band(df)
    df = _derive_diversification(df)
    df = _derive_salutation(df)
    df = _derive_persona(df)
    df = _derive_tone_profile(df)


    # 7) save parquet
    os.makedirs(os.path.dirname(parquet_out), exist_ok=True)
    df.to_parquet(parquet_out, index=False)

    return {"ok": True, "rows": int(len(df)), "parquet": parquet_out, "columns": list(df.columns)}

# ------- HOTFIX: -------
def _derive_tone_profile(df: pd.DataFrame) -> pd.DataFrame:
    for col in ["tone_label","tone_characteristics","tone_priority_words","tone_voice"]:
        if col not in df.columns:
            df[col] = None
    return df
# -----------------------------------------------


# ========= CLI quick test =========
if __name__ == "__main__":
    cfg = _safe_load_yaml(CFG_MCP, {})
    xlsx_path = cfg.get("storage", {}).get("local", {}).get("pl_excel", "data/local/pl.xlsx")
    res = load_pl(xlsx_path, PARQUET_DEFAULT)
    print("[load_pl]", json.dumps(res, ensure_ascii=False, indent=2))

# ========= Tone framework (Age × P&L × Holding × Gender) =========
def _derive_tone_profile(df: pd.DataFrame) -> pd.DataFrame:
    """
    Áp dụng Tone Adjustment Framework:
    - Age band
    - PnL band
    - Holding class
    - Gender
    => sinh ra tone_label, tone_characteristics, tone_priority_words, tone_voice
    """

    def tone_age(age_band: str):
        if age_band is None: return None
        try:
            lo = int(age_band.split("-")[0])
        except Exception:
            return None
        if lo < 25:   return ("Năng động, thách thức", ["cơ hội","tận dụng","đột phá","tăng trưởng đột biến"], "Nhanh, tự tin, nhiệt huyết")
        if lo < 36:   return ("Cân bằng rủi ro & cơ hội", ["xây dựng","tích lũy","dài hạn","quỹ hưu trí"], "Chắc chắn, định hướng")
        if lo < 46:   return ("Thận trọng vừa phải", ["ổn định","đa dạng","quản lý rủi ro","bảo vệ tài sản"], "Chậm rãi, đáng tin cậy")
        if lo < 56:   return ("Rất thận trọng", ["an toàn","bảo toàn","thu nhập đều","nguồn hưu trí"], "Nhẹ nhàng, trấn an")
        return ("Cực kỳ thận trọng", ["bảo vệ","thu nhập ổn định","không rủi ro","lãi suất cố định"], "Rất chậm, ấm áp")

    def tone_pnl(band: str):
        if band=="gain":       return ("Tự hào", ["chúc mừng","tiếp tục","tận dụng","đỉnh cao"], "Hào hứng, tích cực")
        if band=="flat":       return ("Thận trọng", ["ổn định","bảo vệ","cân nhắc","đánh giá"], "Cân nhắc, thận trọng")
        if band=="loss_mild":  return ("Trấn an", ["tạm thời","chu kỳ","phục hồi","kiên nhẫn"], "Bình tĩnh, chắc chắn")
        if band=="loss_deep":  return ("Trấn an mạnh", ["hiểu được","đừng lo lắng","dài hạn","lịch sử chứng minh"], "Rất trấn an, chậm rãi")
        return None

    def tone_holding(hclass: str):
        if hclass=="Short-term":  return ("Khuyến khích", ["bắt đầu","kiên nhẫn","đầu tư đều đặn","quá trình"], "Định hướng, khuyến khích")
        if hclass=="Medium-term": return ("Khẳng định", ["đang đi đúng hướng","tiến bộ","tiếp tục","đồng hành"], "Tự tin, khẳng định")
        if hclass=="Long-term":   return ("Tự hào", ["thành công","chứng minh","hiệu quả","tiếp tục phát huy"], "Tự hào, động viên")
        return None

    def tone_gender(g: str):
        if g=="M": return ("Logic, số liệu", ["số liệu","phân tích","kết quả","hiệu quả"], "Rõ ràng, mạch lạc")
        if g=="F": return ("Nhẹ nhàng, an toàn", ["cảm thấy","an tâm","chắc chắn","bảo vệ"], "Ấm áp, thấu hiểu")
        return None

    tone_labels, tone_chars, tone_words, tone_voices = [], [], [], []

    for _, row in df.iterrows():
        labels, chars, words, voices = [], [], [], []

        res = tone_age(row.get("age_band"))
        if res: labels.append("Age"); chars.append(res[0]); words.extend(res[1]); voices.append(res[2])

        res = tone_pnl(row.get("pnl_band"))
        if res: labels.append("PnL"); chars.append(res[0]); words.extend(res[1]); voices.append(res[2])

        res = tone_holding(row.get("holding_class"))
        if res: labels.append("Holding"); chars.append(res[0]); words.extend(res[1]); voices.append(res[2])

        res = tone_gender(row.get("gender"))
        if res: labels.append("Gender"); chars.append(res[0]); words.extend(res[1]); voices.append(res[2])

        tone_labels.append("+".join(labels) if labels else None)
        tone_chars.append("; ".join(chars) if chars else None)
        tone_words.append(", ".join(sorted(set(words))) if words else None)
        tone_voices.append("; ".join(voices) if voices else None)

    df["tone_label"]=tone_labels
    df["tone_characteristics"]=tone_chars
    df["tone_priority_words"]=tone_words
    df["tone_voice"]=tone_voices
    return df

# ========= API: filter, top score, persona =========
def filter_investors(
    parquet_path: str = PARQUET_DEFAULT,
    min_aum: float | None = None,
    pnl_min: float | None = None,
    pnl_max: float | None = None,
    channel: str | None = None,
    top_n: int = 20
) -> dict:
    """Lọc investor theo điều kiện đơn giản."""
    if not os.path.exists(parquet_path):
        return {"ok": False, "error": f"Not found: {parquet_path}"}
    df = pd.read_parquet(parquet_path)
    q = df
    if channel and "channel_group" in q.columns:
        q = q[q["channel_group"] == channel]
    if min_aum is not None and "current_aum" in q.columns:
        q = q[q["current_aum"] >= min_aum]
    if pnl_min is not None and "pnl_pct" in q.columns:
        q = q[q["pnl_pct"] >= pnl_min]
    if pnl_max is not None and "pnl_pct" in q.columns:
        q = q[q["pnl_pct"] <= pnl_max]
    if "current_aum" in q.columns:
        q = q.sort_values("current_aum", ascending=False)
    cols = [c for c in [
        "investor_id","name","gender","age_band","channel_group",
        "pnl_pct","pnl_abs","current_aum","equity_aum","bond_aum",
        "aum_DCDS","aum_DCDE","aum_DCBF","aum_DCIP",
        "persona","tone_label"
    ] if c in q.columns]
    q = q.head(top_n)
    return {"ok": True, "items": q[cols].to_dict(orient="records")}

def top_bizscore(
    parquet_path: str = PARQUET_DEFAULT,
    top_n: int = 20,
    channel: str | None = None
) -> dict:
    """BizScore v1: 0.6*scale(pnl_pct) + 0.4*scale(current_aum)."""
    if not os.path.exists(parquet_path):
        return {"ok": False, "error": f"Not found: {parquet_path}"}
    df = pd.read_parquet(parquet_path).copy()
    if df.empty: return {"ok": True, "items": []}
    if channel and "channel_group" in df.columns:
        df = df[df["channel_group"] == channel]
    df["_pnl_s"] = _scale(df["pnl_pct"]) if "pnl_pct" in df.columns else 0.5
    df["_aum_s"] = _scale(df["current_aum"]) if "current_aum" in df.columns else 0.5
    df["bizscore"] = 0.6*df["_pnl_s"] + 0.4*df["_aum_s"]
    cols = [c for c in [
        "investor_id","name","gender","age_band","channel_group",
        "pnl_pct","current_aum","equity_aum","bond_aum","bizscore","tone_label"
    ] if c in df.columns]
    out = df.sort_values("bizscore", ascending=False).head(top_n)
    return {"ok": True, "items": out[cols].to_dict(orient="records")}

def get_persona(investor_id: str, parquet_path: str = PARQUET_DEFAULT) -> dict:
    """Trả về persona + tone profile cho 1 investor."""
    if not os.path.exists(parquet_path):
        return {"ok": False, "error": f"Not found: {parquet_path}"}
    df = pd.read_parquet(parquet_path)
    row = df[df["investor_id"]==investor_id]
    if row.empty: return {"ok": False, "error": f"Investor {investor_id} not found"}
    return {"ok": True, "persona": row.iloc[0].to_dict()}
