# app/mcp_adapters/reports.py
from __future__ import annotations
import os, sys, json, argparse, datetime as dt
from pathlib import Path
from typing import List, Dict, Any, Optional

import polars as pl

# Optional deps
try:
    import fitz  # PyMuPDF
except Exception:
    fitz = None
try:
    import camelot  # camelot-py
except Exception:
    camelot = None

def _list_pdfs(folder: Optional[str], glob_pat: Optional[str]) -> List[Path]:
    if glob_pat:
        return [Path(p) for p in sorted(Path().glob(glob_pat))]
    if folder:
        root = Path(folder)
        return sorted([p for p in root.rglob("*.pdf")])
    raise ValueError("Provide either --folder or --glob")

def _extract_text_pymupdf(pdf_path: Path, max_pages: int = 0) -> Dict[str, Any]:
    if not fitz:
        raise RuntimeError("PyMuPDF not installed")

    doc = fitz.open(pdf_path)
    pages = min(len(doc), max_pages) if max_pages and max_pages > 0 else len(doc)
    texts: List[str] = []
    for i in range(pages):
        try:
            page = doc.load_page(i)
            texts.append(page.get_text("text"))
        except Exception:
            continue
    meta = doc.metadata or {}
    doc.close()
    return {"text": "\n".join(texts).strip(), "pages": pages, "meta": meta}

def _extract_tables_camelot(pdf_path: Path, max_pages: int = 0) -> List[Dict[str, Any]]:
    if not camelot:
        return []
    try:
        pages = "all" if not max_pages or max_pages <= 0 else ",".join(str(i) for i in range(1, max_pages + 1))
        tables = camelot.read_pdf(str(pdf_path), pages=pages, flavor="lattice")
        out: List[Dict[str, Any]] = []
        for t in tables:
            out.append({"page": t.page, "data": t.df.values.tolist()})
        return out
    except Exception:
        return []

def _process_pdf(pdf_path: Path, tags: List[str], max_pages: int = 0, with_tables: bool = False) -> Dict[str, Any]:
    tex = _extract_text_pymupdf(pdf_path, max_pages=max_pages)
    tables_json = _extract_tables_camelot(pdf_path, max_pages=max_pages) if with_tables else []
    return {
        "file_path": str(pdf_path),
        "file_name": pdf_path.name,
        "dir_name": str(pdf_path.parent),
        "pages": tex["pages"],
        "text": tex["text"],
        "meta": json.dumps(tex.get("meta") or {}),
        "tables": json.dumps(tables_json),
        "tags": json.dumps(tags or []),
        "fetched_at": dt.datetime.utcnow().isoformat(),
    }

def write_parquet(rows: List[Dict[str, Any]], out_path: str) -> str:
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    pl.DataFrame(rows).write_parquet(out_path)
    return out_path

def main():
    p = argparse.ArgumentParser(description="Reports MCP: build parquet from a folder/glob of PDFs")
    src = p.add_mutually_exclusive_group(required=True)
    src.add_argument("--folder", help="Folder contains PDFs (recursive)")
    src.add_argument("--glob", help='Glob pattern, e.g., "data/external/reports/*.pdf"')
    p.add_argument("--out", default="data/external/reports/reports.parquet", help="Output parquet path")
    p.add_argument("--tags", nargs="*", default=[], help="Attach tags to each record")
    p.add_argument("--max-pages", type=int, default=0, help="Limit pages per file; 0 = all")
    p.add_argument("--tables", action="store_true", help="Extract tables using camelot if available")

    args = p.parse_args()

    pdfs = _list_pdfs(args.folder, args.glob)
    if not pdfs:
        print("[WARN] No PDF files found.", file=sys.stderr)
        sys.exit(0)

    rows: List[Dict[str, Any]] = []
    for pth in pdfs:
        try:
            row = _process_pdf(pth, tags=args.tags, max_pages=args.max_pages, with_tables=args.tables)
            rows.append(row)
        except Exception as e:
            print(f"[ERR] {pth}: {e}", file=sys.stderr)

    if not rows:
        print("[WARN] No rows extracted.", file=sys.stderr)
        sys.exit(0)

    outp = write_parquet(rows, args.out)
    print(json.dumps({"ok": True, "out": outp, "files": len(rows)}, ensure_ascii=False))

if __name__ == "__main__":
    main()
