# Add the parent directory to Python path
import sys
import os
# Update the system path to include the parent directory
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


# Import necessary modules and classes
from typing import TypedDict, Annotated, List
from langgraph.graph import StateGraph, START, END
from langgraph.types import interrupt
from langgraph.checkpoint.memory import MemorySaver
from pydantic_ai.messages import ModelMessage
from agents.Agent_PL_Investors_Huggingface import FullInvestorData, pl_investors_agent
from agents.Agent_Reports_Huggingface import MonthlyReport_agent
from agents.Depricated_Agent_Salescripts_Huggingface import salescripts_agent, run_agent as run_salescripts_agent

# Define state schema
class AgentState(TypedDict):
    Latest_user_message: str
    InvestorData: List[FullInvestorData]
    Content_Message: str
    Sales_Scripts: str

# 1st node
async def PL_investors_agent_run(state: AgentState, writer):
    writer(
        "Getting the investor data...\n"
    )
    result = await pl_investors_agent.run(state["Latest_user_message"])
    writer("### The retrieved investor data: \n")
    print(result.output)
    return {"InvestorData": result.output}

# 2nd node
async def MonthlyReport_agent_run(state: AgentState, writer):
    # Get the latest message and deserialize it
    prompt = f"""
    Please write Vietnamese content for the Investor with the following info, addressing the investor specifically by Name and pronounce: {state["InvestorData"]}
    """
    result = await MonthlyReport_agent.run(prompt)
    print("The message is: ", result.output)
    return {"Content_Message": result.output}

# 3rd node
async def Salescripts_agent_run(state: AgentState, writer):
    # Get the latest message and deserialize it
    prompt = f"""
    Viết kịch bản bán hàng cá nhân hoá theo dữ liệu nhà đầu tư {state["InvestorData"]} kết hợp với nội dung monthly: {state["Content_Message"]}
    """
    result = await run_salescripts_agent(prompt)
    print("The message is: ", result.output)
    return {"Sales_Scripts": result.output}

# Build workflow
builder = StateGraph(AgentState)
builder.add_node("PL_investors_agent_run", PL_investors_agent_run)
builder.add_node("MonthlyReport_agent_run", MonthlyReport_agent_run)
builder.add_node("Salescripts_agent_run", Salescripts_agent_run)

builder.add_edge(START, "PL_investors_agent_run")
builder.add_edge("PL_investors_agent_run", "MonthlyReport_agent_run")
builder.add_edge("MonthlyReport_agent_run", "Salescripts_agent_run")
builder.add_edge("Salescripts_agent_run", END)

# Configure persistence
memory = MemorySaver()
graph = builder.compile(checkpointer=memory)

# Example usage
async def run_example():
    # Create initial state
    initial_state = {
        "Latest_user_message": "Viết cho tôi nội dung email cá nhân hóa khuyến khích đầu tư thêm vào quỹ DCDS cho nhà đầu tư có ID là 999C572293",
        "InvestorData": [],
        "Content_Message": [],
        "Sales_Scripts": ""
    }
    
    # Create config with thread_id for the checkpointer
    config = {"configurable": {"thread_id": "user_session_1"}}
    
    # Stream the execution with config
    final_state = None
    async for chunk in graph.astream(initial_state, config=config):
        print(f"Node: {list(chunk.keys())[0]}")
        print(f"Data: {chunk}")
        print("---")
        final_state = chunk
    
    # Print the final results
     # Print the final results
    if final_state:
        print("\n" + "="*50)
        print("FINAL RESULTS:")
        print("="*50)
        
        # Print InvestorData if available
        if "InvestorData" in final_state:
            print("INVESTOR DATA:")
            print("-" * 30)
            print(final_state["InvestorData"])
            print()
        
        # Print Content_Message if available
        if "Content_Message" in final_state:
            print("CONTENT MESSAGE:")
            print("-" * 30)
            print(final_state["Content_Message"])
        
        # Print Sales_Scripts if available
        if "Sales_Scripts" in final_state:
            print("SALES SCRIPTS:")
            print("-" * 30)
            print(final_state["Sales_Scripts"])
        
        print("="*50)

if __name__ == "__main__":
    import asyncio
    asyncio.run(run_example())