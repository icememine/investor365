# app/pipelines/salescript_chunker.py
from __future__ import annotations
import os, hashlib
from pathlib import Path
import polars as pl

SCRIPTS = "data/external/salescripts/salescripts.parquet"
OUT = "data/vector/salescript_chunks.parquet"
CHUNK_SIZE = 700
OVERLAP = 120

def sha1(s: str) -> str:
    return hashlib.sha1(s.encode("utf-8")).hexdigest()

def chunk_text(t: str, size=CHUNK_SIZE, overlap=OVERLAP):
    t = (t or "").strip()
    if not t: return []
    if len(t) <= size: return [t]
    out, i = [], 0
    while i < len(t):
        out.append(t[i:i+size])
        if i + size >= len(t): break
        i += size - overlap
    return out

def main():
    if not os.path.exists(SCRIPTS):
        raise SystemExit(f"Not found: {SCRIPTS}")
    df = pl.read_parquet(SCRIPTS)

    rows = []
    for r in df.iter_rows(named=True):
        doc_id = sha1(r["file_path"])
        chunks = chunk_text(r["text"])
        for idx,ch in enumerate(chunks):
            rows.append({
                "chunk_id": f"{doc_id}:{idx}",
                "doc_id": doc_id,
                "source": "salescript",
                "title": r["file_name"],
                "file_path": r["file_path"],
                "chunk_idx": idx,
                "text": ch,
                "fetched_at": r["fetched_at"],
            })
    if not rows:
        raise SystemExit("No chunks generated from salescripts.")
    Path(OUT).parent.mkdir(parents=True, exist_ok=True)
    pl.DataFrame(rows).write_parquet(OUT)
    print(f"[OK] chunks={len(rows)} -> {OUT}")

if __name__ == "__main__":
    main()
