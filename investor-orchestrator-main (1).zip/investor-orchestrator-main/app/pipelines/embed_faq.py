# app/pipelines/embed_faq.py
from __future__ import annotations
import os
from pathlib import Path
import numpy as np
import polars as pl
import faiss
from sentence_transformers import SentenceTransformer

INDEX  = "data/vector/faiss_faq/index.faiss"
PICKLE = "data/vector/faiss_faq/index.pkl"
CHUNKS = "data/vector/faq_chunks.parquet"
ID_MAP = "data/vector/faq_id_map.parquet"
MODEL  = "intfloat/multilingual-e5-base"

def main():
    if not os.path.exists(CHUNKS):
        raise SystemExit(f"Not found: {CHUNKS}")
    df = pl.read_parquet(CHUNKS)

    texts = ["passage: " + t for t in df["text"].to_list()]
    model = SentenceTransformer(MODEL)
    emb = model.encode(texts, batch_size=32, show_progress_bar=True, normalize_embeddings=True)
    emb = emb.astype("float32")

    dim = emb.shape[1]
    index = faiss.IndexFlatIP(dim)
    index.add(emb)

    Path(INDEX).parent.mkdir(parents=True, exist_ok=True)
    faiss.write_index(index, INDEX)

    df.select(["chunk_id","doc_id","source","title","chunk_idx","tags"]).write_parquet(ID_MAP)
    print(f"[OK] vectors={emb.shape[0]} dim={dim}")
    print(f"[OK] wrote {INDEX}")
    print(f"[OK] wrote {ID_MAP}")

if __name__ == "__main__":
    main()
