# app/pipelines/embed_pl_investor.py
from __future__ import annotations
import os, faiss, polars as pl
from pathlib import Path
from sentence_transformers import SentenceTransformer

INP    = "data/local/pl.parquet"                # parquet bạn đã tạo
CHUNKS = "data/vector/pl_investor_chunks.parquet"
ID_MAP = "data/vector/pl_investor_id_map.parquet"
INDEX  = "data/vector/faiss_pl_investor/index.faiss"
MODEL  = "intfloat/multilingual-e5-base"
PICKLE = "data/vector/faiss_pl_investor/index.pkl"

def row_to_text(r: dict) -> str:
    """Ghép các cột quan trọng thành 1 chuỗi text để embed"""
    cols = ["investor_id", "Full Name", "Current Portfolio",
            "current_aum", "risk_score", "pnl_band", "persona"]
    parts = []
    for c in cols:
        v = r.get(c)
        if v is not None and str(v).strip():
            parts.append(f"{c}: {v}")
    return " | ".join(parts)

def main():
    if not os.path.exists(INP):
        raise SystemExit(f"Not found: {INP}")
    df = pl.read_parquet(INP)
    rows = []
    texts = []
    for idx, r in enumerate(df.iter_rows(named=True)):
        txt = row_to_text(r)
        if not txt:
            continue
        rows.append({
            "chunk_id": f"plinv:{idx}",
            "doc_id": r.get("investor_id") or str(idx),
            "source": "pl_investor",
            "title": r.get("Full Name") or "",
            "chunk_idx": 0,
            "text": txt,
        })
        texts.append(txt)

    if not rows:
        raise SystemExit("No rows to embed.")

    # save chunks
    Path(CHUNKS).parent.mkdir(parents=True, exist_ok=True)
    pl.DataFrame(rows).write_parquet(CHUNKS)

    # embed
    model = SentenceTransformer(MODEL)
    vecs = model.encode(
        ["passage: "+t for t in texts],
        batch_size=64, show_progress_bar=True, normalize_embeddings=True
    ).astype("float32")

    ix = faiss.IndexFlatIP(vecs.shape[1])
    ix.add(vecs)

    faiss.write_index(ix, INDEX)
    pl.DataFrame(rows).select(
        ["chunk_id","doc_id","source","title","chunk_idx"]
    ).write_parquet(ID_MAP)

    print(f"[OK] embedded {len(rows)} rows -> {INDEX}")
    print(f"[OK] id_map -> {ID_MAP}")
    print(f"[OK] chunks -> {CHUNKS}")

if __name__ == "__main__":
    main()
