#!/usr/bin/env python3
"""
Script to convert raw FAISS index to LangChain-compatible format
"""
import os
import numpy as np
import polars as pl
import faiss
from sentence_transformers import SentenceTransformer
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import SentenceTransformerEmbeddings

# Configuration
INDEX_FILE = "data/vector/faiss_salescripts.index"
ID_MAP_FILE = "data/vector/salescript_id_map.parquet"
CHUNKS_FILE = "data/vector/salescript_chunks.parquet"
OUTPUT_DIR = "data/vector/faiss_salescripts"
MODEL_NAME = "intfloat/multilingual-e5-base"

def main():
    print("Converting raw FAISS index to LangChain format...")
    
    # Load the raw FAISS index
    print(f"Loading FAISS index from {INDEX_FILE}")
    faiss_index = faiss.read_index(INDEX_FILE)
    
    # Load metadata
    print(f"Loading metadata from {ID_MAP_FILE}")
    id_map_df = pl.read_parquet(ID_MAP_FILE)
    
    print(f"Loading chunks from {CHUNKS_FILE}")
    chunks_df = pl.read_parquet(CHUNKS_FILE)
    
    # Create embeddings model
    print(f"Loading embedding model: {MODEL_NAME}")
    embeddings_model = SentenceTransformerEmbeddings(model_name=MODEL_NAME)
    
    # Get all vectors from the FAISS index
    print("Extracting vectors from FAISS index...")
    vectors = faiss_index.reconstruct_n(0, faiss_index.ntotal)
    
    # Create documents for LangChain
    print("Creating documents for LangChain...")
    documents = []
    metadatas = []
    
    for i in range(len(chunks_df)):
        chunk_row = chunks_df.row(i, named=True)
        id_row = id_map_df.row(i, named=True)
        
        # Create document
        doc_text = chunk_row['text']
        documents.append(doc_text)
        
        # Create metadata
        metadata = {
            'chunk_id': id_row['chunk_id'],
            'doc_id': id_row['doc_id'],
            'source': id_row['source'],
            'title': id_row['title'],
            'file_path': id_row['file_path'],
            'chunk_idx': id_row['chunk_idx']
        }
        metadatas.append(metadata)
    
    # Create LangChain FAISS vector store
    print("Creating LangChain FAISS vector store...")
    vector_store = FAISS.from_embeddings(
        text_embeddings=list(zip(documents, vectors)),
        embedding=embeddings_model,
        metadatas=metadatas
    )
    
    # Save to directory
    print(f"Saving to {OUTPUT_DIR}")
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    vector_store.save_local(OUTPUT_DIR)
    
    print("✅ Conversion completed successfully!")
    print(f"✅ LangChain FAISS index saved to {OUTPUT_DIR}")

if __name__ == "__main__":
    main()
