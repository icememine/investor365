## QUỸ ĐẦU TƯ CHỨNG KHOÁN NĂNG ĐỘNG DC (DCDS)

<!-- image -->

Mục tiêu đầu tư của Quỹ DCDS tìm kiếm lợi nhuận dài hạn từ tăng trưởng vốn gốc và thu nhập thông qua việc đầu tư vào danh mục cân bằng và đa dạng gồm các loại chứng khoán vốn, trái phiếu chuyển đổi, chứng khoán nợ trên thị trường Việt Nam.

## THÔNG TIN CHUNG

| Ngày bắt đầu hoạt động   | 20/5/2004                                            |
|--------------------------|------------------------------------------------------|
| Tổng NAV                 | 2.788,8 tỷ VNĐ                                       |
| NAV/CCQ                  | 79.331,90 VNĐ                                        |
| Ngân hàng giám sát       | Standard Chartered Vietnam                           |
| Kiếm toán bởi            | PwCVietnam                                           |
| Đại lý phân phối         | Xem tại trang chủ dragoncapital.com.vn               |
| Phí quản lý              | Tối đa 2%/NAV/năm                                    |
| Tỷ lệ chi phí 12 tháng   | 2,1%                                                 |
| Kỳgiao dịch              | Hằng ngày ( ngày T)                                  |
| Đầutư tối thiểu từ       | 100.000 đồng                                         |
| Phí đăng ký              | Miễn phí                                             |
| Phí bán CCQ              | <364 ngày : 1,5% 365 - 729 ngày : 0,5% >730 ngày: 0% |

## KẾT QUẢ HOẠT ĐỘNG

|          | NAV/CCQ(đ ô ng )   | 1 tháng (%)   | 3 tháng (%)   | So với đầu năm (%)   | 12 tháng (%)   | Kể từ khi thành lập 20/05/2004(%)   |
|----------|--------------------|---------------|---------------|----------------------|----------------|-------------------------------------|
| DCDS     | 79.331,90          | -2,7          | -2,6          | -2,6                 | 4,0            | 977,3                               |
| VN-Index | 1.306,86           | 0,1           | 3,2           | 3,2                  | 1,8            | 399,6                               |

̀

<!-- image -->

## PHÂN BỔ TÀI SẢN THEO NGÀNH (%)

## 10 KHOẢN ĐẦU TƯ LỚN

| CỔ PHIẾU   | NHÓMNGÀNH       | %NAV   |
|------------|-----------------|--------|
| CTG        | Ngân hàng       | 7,4    |
| TCB        | Ngân hàng       | 7,0    |
| MWG        | Bán lẻ          | 6,6    |
| HPG        | Kim loại        | 4,8    |
| FPT        | Công nghệ       | 4,7    |
| STB        | Ngân hàng       | 4,4    |
| VIC        | Conglomerate    | 4,0    |
| VHM        | BĐS khu dân c ư | 3,6    |
| MBB        | Ngân hàng       | 2,4    |
| FRT        | Bán lẻ          | 2,1    |
| TỔNGCỘNG   | TỔNGCỘNG        | 47,1   |

<!-- image -->

## ĐÁNH GIÁ HOẠT ĐỘNG TRONG THÁNG

Thị trường chứng khoán Việt Nam trong tháng 3 tương đối trầm lắng khi chỉ số VN -Index chỉ tăng nhẹ 0,1 % so với cuối tháng trước, đóng cửa tại mức 1.306,9 điểm . Thị trường tăng mạnh trong các phiên giao dịch đầu tháng và đạt đỉnh cao nhất kể từ tháng 05/ 2022, được hỗ trợ bởi dữ liệu vĩ mô tích cực và tâm lý lạc quan xoay quanh việc triển khai hệ thống giao dịch mới KRX. Tuy nhiên, đà tăng chững lại trong nửa cuối tháng do khối ngoại tiếp tục bán ròng, cùng với lo ngại trước chính sách áp thuế thương mại của Mỹ . Mặc dù trải qua nhiều biến động trong tháng 3, chỉ số VN-Index vẫn ghi nhận mức tăng trưởng tích cực 3,2 % tính từ đầu năm, trong đó nhóm cổ phiếu thuộc hệ sinh  thái Vingroup đóng góp hơn 50% vào đà tăng chung của thị trường . Mức tăng trưởng này vượt trội hơn so với các nước trong khu vực như Thái Lan (SET, -17,3 %), Indonesia (JCI ,-8,0 %) và Philippines (PCOMP, -5 ,3 %) .

Giá trị NAV/CCQ của DCDS giảm 2,7 % trong tháng, thấp hơn mức tăng nhẹ của thị trường do nhóm cổ phiếu Bán lẻ như FPT ( -13,8 %), FRT ( -9,8 %) tiếp tục chịu áp lực bán mạnh, ngoài ra một số cổ phiếu Ngân hàng như VIB ( -4,3 %), BID ( -5 ,4 %) cũng giảm trong  tháng  qua. Ở chiều ngược lại, với nhóm cổ phiếu thuộc hệ sinh  thái Vingroup ghi nhận mức tăng ấn tượng (VIC +40,8 % , VHM +24, 5% , VRE +10,1 %), Quỹ đã chủ động gia tăng tỷ trọng nắm giữ nhằm tận dụng cơ hội tăng trưởng mạnh từ nhóm này. Đối với tình hình vĩ mô, việc Mỹ công bố các biện pháp áp thuế mới đối với hàng hóa nhập khẩu từ các nước đã gây ra nhiều biến động đáng kể trên thị trường toàn cầu . Trong ngắn hạn, Quỹ đã chủ động nâng tỷ trọng tiền mặt lên mức cao (từ 2,4 % NAV tại cuối tháng 2 lên 17,9 % NAV tại cuối tháng 3 ) nhằm giảm rủi ro cho danh mục, đồng thời thực hiện cắt giảm và thoái vốn hoàn toàn khỏi một số cổ phiếu liên quan đến xuất khẩu, khu công nghiệp và các ngành có thể chịu ảnh hưởng nếu thuế suất cao được áp dụng . Về dài hạn, giai đoạn điều chỉnh này là cơ hội để Quỹ tái cơ cấu danh mục đầu tư, tập trung vào các cổ phiếu thuộc nhóm ngành có định giá hấp dẫn và tiềm năng tăng trưởng tốt như Ngân hàng, Bất động sản dân cư, Xây dựng &amp; Vật liệu, cũng như nhóm hưởng lợi từ đầu tư công.

## QUỸ ĐẦU TƯ CHỨNG KHOÁN NĂNG ĐỘNG DC (DCDS)

## KẾT QUẢ HOẠT ĐỘNG

| TĂNG TRƯỞNG TỪNGNĂM (%)   | Kểtừ đầunăm   | 2024   | 2023   | 2022   | 2021   | 2020   |
|---------------------------|---------------|--------|--------|--------|--------|--------|
| DCDS                      | -2,6          | 23,9   | 27,5   | -34,4  | 53,9   | 25,2   |
| VN-INDEX                  | 3,2           | 12,1   | 12,2   | -32,8  | 35,7   | 14,9   |

| TĂNG TRƯỞNG LŨY KẾ (%)   | 1 năm   | 3 năm   | 5năm   |
|--------------------------|---------|---------|--------|
| DCDS                     | 4,0     | 2,3     | 166,5  |

## ĐẶC TRƯNG DANH MỤC

| Chỉ số cơ bản                            | DCDS   | VN-Index   |
|------------------------------------------|--------|------------|
| P/E(phương pháp chỉ số)                  | 12,2   | 13,0       |
| P/B(phương phápchỉ số)                   | 1,7    | 1,7        |
| Tỷ suất sinh lời trên vốn chủ sở hữu (%) | 14,6   | 13,4       |
| Tỷ suất sinh lời cổ tức (%)              | 1,4    | 1,8        |
| Số lượng cổ phiếu                        | 52,0   | 392        |
| Hệ số rủi ro                             | DCDS   | VN-Index   |
| Hệ số Beta                               | 1,0    | 1,0        |
| Độbiến động bình quânnăm (%)             | 21,9   | 19,1       |
| Hệ số Sharpe                             | -0,1   | -0,3       |

## HỖ TRỢ

## DISCLAIMER

Tài liệu này cũng như bất kỳ điều gì có trong tài liệu này sẽ không phải là cơ sở của bất kỳ hợp đồng cam kết nào. Thông tin trong tài liệu này chỉ dành cho mục đích thông tin và có thể được cập nhật, sửa đổi và không có tuyên bố hoặc bảo đảm (rõ ràng hay ngụ ý), và không có trách nhiệm pháp lý nào được chấp nhận bởi Dragon Capital hoặc bất kỳ cá nhân nào khác, liên quan đến tài liệu này. Bất kỳ khoản đầu tư nào cũng phải được thực hiện trên cơ sở các tài liệu chào bán có liên quan. Hiệu quả đầu tư trong quá khứ không nhất thiết phải là chỉ dẫn cho tương lai. Nên nghiên cứu thận trọng tài liệu này Nếu bạn còn nghi ngờ về bất kỳ thông tin nào trong tài liệu này, bạn nên xin ý kiến chuyên gia độc lập .

## GIAO DỊCH

| Ngày giao dịch (T Day)              | Thứ 2 đến thứ6 ( ngày làm việc)    |
|-------------------------------------|------------------------------------|
| Hạn chót đặt lệnh & Chuyển tiền mua | Trước 14:30 các ngày làm việc      |
| Ngày giao dịch & Nhận kết quả       | 01 ngày làm việc sau ngày đặt lệnh |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->