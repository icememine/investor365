from __future__ import annotations
import os, hashlib
from pathlib import Path
import polars as pl

INP = "data/external/handbook/handbook.parquet"   # output từ adapter handbook
OUT = "data/vector/handbook_chunks.parquet"

CHUNK_SIZE = 700
OVERLAP = 120

def sha1(s: str) -> str:
    return hashlib.sha1(s.encode("utf-8")).hexdigest()

def chunks(text: str, size=CHUNK_SIZE, ov=OVERLAP):
    text = (text or "").strip()
    if not text:
        return []
    if len(text) <= size:
        return [text]
    out, i = [], 0
    while i < len(text):
        out.append(text[i:i+size])
        if i+size >= len(text):
            
            break
        i += size - ov
    return out

def main():
    if not os.path.exists(INP):
        raise SystemExit(f"Not found: {INP}")
    df = pl.read_parquet(INP).with_columns(pl.col("text").fill_null("").cast(pl.Utf8))
    rows = []
    for r in df.iter_rows(named=True):
        doc = sha1(r.get("file_path") or "handbook")
        for idx, ch in enumerate(chunks(r["text"])):
            rows.append({
                "chunk_id": f"{doc}:{idx}",
                "doc_id": doc,
                "source": "handbook",
                "title": r.get("file_name") or "handbook",
                "file_path": r.get("file_path") or "",
                "chunk_idx": idx,
                "text": ch,
            })
    if not rows:
        raise SystemExit("No chunks generated from handbook.")
    Path(OUT).parent.mkdir(parents=True, exist_ok=True)
    pl.DataFrame(rows).write_parquet(OUT)
    print(f"[OK] chunks={len(rows)} -> {OUT}")

if __name__ == "__main__":
    main()
