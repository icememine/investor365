# app/pipelines/embed_salescripts.py
from __future__ import annotations
import os, numpy as np, polars as pl, faiss
from pathlib import Path
from sentence_transformers import SentenceTransformer

CHUNKS = "data/vector/salescript_chunks.parquet"
ID_MAP = "data/vector/salescript_id_map.parquet"
INDEX  = "data/vector/faiss_salescripts/index.faiss"
MODEL  = "intfloat/multilingual-e5-base"
PICKLE = "data/vector/faiss_salescripts/index.pkl"

def main():
    if not os.path.exists(CHUNKS):
        raise SystemExit(f"Not found: {CHUNKS}")
    df = pl.read_parquet(CHUNKS)
    texts = ["passage: " + t for t in df["text"].to_list()]
    model = SentenceTransformer(MODEL)
    emb = model.encode(texts, batch_size=32, show_progress_bar=True, normalize_embeddings=True).astype("float32")

    dim = emb.shape[1]
    index = faiss.IndexFlatIP(dim)
    index.add(emb)

    Path(INDEX).parent.mkdir(parents=True, exist_ok=True)
    faiss.write_index(index, INDEX)
    
    df.select(["chunk_id","doc_id","source","title","file_path","chunk_idx","fetched_at"]).write_parquet(ID_MAP)
    print(f"[OK] vectors={emb.shape[0]} dim={dim}")
    print(f"[OK] wrote {INDEX}, {ID_MAP}")

if __name__ == "__main__":
    main()
